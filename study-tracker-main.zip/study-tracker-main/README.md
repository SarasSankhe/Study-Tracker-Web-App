# Study Tracker

Study Tracker is a local full-stack learning tracker. The existing HTML, CSS and JavaScript dashboards are served by an Express application. Prisma stores application data in SQLite; sessions and uploaded files are stored locally. Python powers document text extraction and the internal TF-IDF similarity review.

## Requirements

- Node.js 24.x (the audited environment used Node 24.19.0) and npm.
- Python 3.10 or newer with the packages in `backend/python/plagiarism/requirements.txt` installed.
- Windows PowerShell instructions are shown below; equivalent `cp`/`export` commands work on macOS and Linux.

## Install and run

1. Open a terminal in the repository and enter `backend`.
2. Create a local environment file and set a private session secret:

   ```powershell
   Copy-Item .env.example .env
   node -e "console.log(require('node:crypto').randomBytes(48).toString('hex'))"
   ```

   Put the generated value in `SESSION_SECRET` in `.env`. Do not commit `.env`.

3. Install the exact locked Node dependency tree and generate Prisma Client:

   ```powershell
   npm ci
   npm run db:generate
   ```

4. Apply migrations to the configured SQLite database:

   ```powershell
   npm run db:deploy
   npm run db:validate
   ```

5. Install Python requirements with the same interpreter configured by `PLAGIARISM_PYTHON`. Since `.env` is loaded by the app and test runner rather than by PowerShell itself, read the executable from the file and invoke it like this:

   ```powershell
   $python = node -e "require('dotenv').config(); process.stdout.write(process.env.PLAGIARISM_PYTHON || 'python')"
   & $python -m pip install -r python/plagiarism/requirements.txt
   ```

   If using the `python` fallback, ensure it names the same interpreter you will set in `.env`.

6. Start the application from `backend`:

   ```powershell
   npm start
   ```

   Open [http://localhost:3000](http://localhost:3000). The health endpoint is `/api/health`.

## Tests and checks

Keep the application running in one terminal for the API integration suites. In a second terminal, run from `backend`:

```powershell
npm run db:validate
npm exec prisma migrate status
npm run test:integration
npm run test:plagiarism
npm run test:plagiarism:python
```

The API integration scripts create uniquely named test accounts and clean their generated records. The Python unit suite runs without the API server. Never reset or delete the development database to run tests.

## Features

- Separate student and teacher accounts, role-gated APIs, and SQLite-backed sessions.
- Teacher assignments with selected or all-student recipients, submissions, grades and feedback.
- Teacher-assigned study tasks, private student timer records, personal tasks and study-time tracking.
- Teacher analytics and an internal document similarity review for supported text, DOCX and text-based PDF submissions.

Similarity values are signals for teacher review, not a finding of misconduct. Scanned PDFs and image files do not provide OCR text extraction. Unsupported, corrupt, empty and password-protected documents are reported as such.

## Local data and prototype limitations

SQLite data lives at the path configured by `DATABASE_URL` (the default is `backend/prisma/dev.db`); session data is in `backend/prisma/sessions.db`; uploads are stored under `backend/uploads`. These are local development files and are excluded from version control. Back them up before manual database maintenance.

Teacher self-registration is currently available through the application. This prototype has no email verification, password reset, or managed multi-user deployment. For production, teacher account provisioning, deployment security, backups, and file storage need an explicit operational design.

## Repository map

```text
index.html, style.css, app.js, role-app.js   Existing dashboard UI
backend/src/                                 Express server and API routes
backend/prisma/schema.prisma                 Prisma data model
backend/prisma/migrations/                   SQLite migrations
backend/tests/                               API integration and Python runner
backend/python/plagiarism/                   Analyzer, extraction, and unit tests
backend/uploads/                             Local submission files (ignored)
```
