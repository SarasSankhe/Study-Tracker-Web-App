# Study Tracker Demo Guide

Use a development database only. The demo creates real local records; use names prefixed with `DEMO` and leave genuine accounts and records untouched. Do not promise a particular plagiarism percentage: it is computed from the actual submitted documents.

## Start-up

Follow the installation steps in `README.md`, then start the backend from `backend` with `npm start`. Confirm `http://localhost:3000/api/health` returns `{"status":"ok"}`. Register one teacher and two students through the UI using demo-only email addresses that you control. No demo passwords are stored in this guide.

## Suggested walkthrough

1. Sign in as the teacher. Create an assignment with a deadline, select both demo students (or all registered students), and publish it.
2. Create a teacher-assigned study task. Demonstrate a selected-student audience, expected duration and deadline; publish it.
3. Sign in as Student A. Show the published work in the dashboard/planner, create a personal task, start and pause the teacher-assigned task timer, then submit a distinct text-based PDF, DOCX or TXT file for the assignment.
4. Sign out and sign in as Student B. Confirm the same all-student assignment is visible, the selected task follows its recipient selection, and Student A's personal task, submission, grade and timer details are not visible. Submit a different document.
5. Sign back in as the teacher. Open the assignment submissions and show that each file belongs to the right student. Record marks and feedback for both; inspect teacher task monitoring and analytics.
6. Sign in separately as each student to show only their own grade and feedback. Resume or complete the teacher task as allowed, and show that elapsed time is retained after a refresh.
7. If demonstrating plagiarism review, analyze the assignment only after both students have submitted. Explain that the tool extracts text from supported formats and presents similarity for human review; it does not decide plagiarism. Use actual displayed results.

## Cleanup

Keep the demo data if it is useful. If it must be removed, first make a SQLite backup and delete only the specifically identified `DEMO` accounts and their dependent demo records through a reviewed transaction. Do not reset the database or remove unrelated user data. Integration tests clean up their own generated fixtures and should not be used as a database-cleaning procedure.
