require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const api = require('./routes/api');
const studyTasks = require('./routes/studyTasks');
const plagiarism = require('./routes/plagiarism');

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.includes('replace-this')) throw new Error('Set a unique SESSION_SECRET in backend/.env before starting');
const app = express();
app.disable('x-powered-by');
// The existing dashboard uses inline presentation attributes and handlers.
// Keep Helmet's other protections while avoiding a CSP that disables the UI.
app.use(helmet({ contentSecurityPolicy: false }));
app.use(morgan('dev'));
app.use(express.json({ limit: '1mb' }));
app.use(session({ store: new SQLiteStore({ db: 'sessions.db', dir: path.resolve('prisma') }), secret: process.env.SESSION_SECRET, resave: false, saveUninitialized: false, cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 8 } }));
const frontendRoot = path.resolve(__dirname, '../..');
app.get('/', (_req,res)=>res.sendFile(path.join(frontendRoot,'index.html')));
for (const file of ['app.js','role-app.js','style.css']) app.get(`/${file}`, (_req,res)=>res.sendFile(path.join(frontendRoot,file)));
app.use('/assets', express.static(path.join(frontendRoot,'assets')));
app.get('/api/health', (_req,res)=>res.json({status:'ok'}));
app.use('/api', api);
app.use('/api', studyTasks);
app.use('/api', plagiarism);
app.use((err,_req,res,_next)=>{
  if(err.status && err.status < 500) return res.status(err.status).json({error:err.message});
  if(err.name==='ZodError') return res.status(400).json({error:'Invalid request data',details:err.issues.map(i=>({path:i.path,message:i.message}))});
  if(err.code==='P2002') return res.status(409).json({error:'A record with that value already exists'});
  if(err.code==='P2025') return res.status(404).json({error:'Record not found'});
  if(err.name==='MulterError') return res.status(400).json({error:err.code==='LIMIT_FILE_SIZE'?'File exceeds the upload limit':'File upload failed'});
  console.error(err);
  res.status(500).json({error:'Internal server error'});
});
module.exports = app;
