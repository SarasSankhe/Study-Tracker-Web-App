const express = require('express');
const { z } = require('zod');
const prisma = require('../config/prisma');
const { requireAuth, allowRoles } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();
const wrap = asyncHandler;
const taskInput = z.object({
  title: z.string().trim().min(1).max(200),
  description: z.string().max(5000).default(''),
  dueAt: z.string().datetime().nullable().optional(),
  durationMinutes: z.number().int().min(0).max(480).nullable().optional(),
  audience: z.enum(['ALL', 'SELECTED']).default('ALL'),
  studentIds: z.array(z.string()).default([]),
  published: z.boolean().optional()
});

class RouteError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function secondsBetween(start, end) {
  return Math.max(0, Math.floor((end.getTime() - start.getTime()) / 1000));
}

async function studentIdsFor(audience, suppliedIds, db = prisma) {
  const ids = audience === 'ALL'
    ? (await db.user.findMany({ where: { role: 'STUDENT' }, select: { id: true } })).map(student => student.id)
    : [...new Set(suppliedIds)];
  if (!ids.length) throw new RouteError(400, audience === 'ALL' ? 'There are no registered students to assign this task to' : 'Select at least one student');
  if (audience === 'SELECTED') {
    const found = await db.user.count({ where: { id: { in: ids }, role: 'STUDENT' } });
    if (found !== ids.length) throw new RouteError(400, 'Every selected recipient must be a registered student');
  }
  return ids;
}

async function pauseStaleTimers(where) {
  const cutoff = new Date(Date.now() - 45_000);
  const running = await prisma.studyTaskAssignment.findMany({
    where: { ...where, status: 'RUNNING' },
    select: { taskId: true, studentId: true }
  });
  for (const key of running) {
    await prisma.$transaction(async tx => {
      const assignment = await tx.studyTaskAssignment.findUnique({
        where: { taskId_studentId: key },
        select: { status: true }
      });
      if (assignment?.status !== 'RUNNING') return;
      const active = await tx.studyTimeSession.findFirst({
        where: { taskAssignmentTaskId: key.taskId, taskAssignmentStudentId: key.studentId, endedAt: null },
        orderBy: { startedAt: 'desc' }
      });
      if (!active) {
        await tx.studyTaskAssignment.updateMany({ where: { ...key, status: 'RUNNING' }, data: { status: 'PAUSED' } });
        return;
      }
      const lastSeen = active.heartbeatAt || active.startedAt;
      if (lastSeen > cutoff) return;
      const claimed = await tx.studyTaskAssignment.updateMany({ where: { ...key, status: 'RUNNING' }, data: { status: 'PAUSED' } });
      if (!claimed.count) return;
      await tx.studyTimeSession.updateMany({
        where: { id: active.id, endedAt: null },
        data: { pausedAt: lastSeen, endedAt: lastSeen, duration: secondsBetween(active.startedAt, lastSeen) }
      });
    });
  }
}

async function sessionsFor(assignments) {
  if (!assignments.length) return new Map();
  const pairs = assignments.map(({ taskId, studentId }) => ({ taskAssignmentTaskId: taskId, taskAssignmentStudentId: studentId }));
  const sessions = await prisma.studyTimeSession.findMany({
    where: { OR: pairs },
    orderBy: { startedAt: 'asc' }
  });
  const grouped = new Map();
  for (const session of sessions) {
    const key = `${session.taskAssignmentTaskId}:${session.taskAssignmentStudentId}`;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(session);
  }
  return grouped;
}

function progressView(assignment, sessions = []) {
  const activeSession = sessions.find(session => !session.endedAt) || null;
  const storedSeconds = sessions.reduce((sum, session) => sum + (session.duration || 0), 0);
  const activeSeconds = activeSession ? secondsBetween(activeSession.startedAt, new Date()) : 0;
  return { ...assignment, sessions, activeSession, totalSeconds: storedSeconds + activeSeconds };
}

async function studentAssignment(taskId, studentId) {
  return prisma.studyTaskAssignment.findFirst({
    where: { taskId, studentId, task: { type: 'TEACHER_ASSIGNED', published: true } },
    include: { task: true }
  });
}

async function transitionTimer(taskId, studentId, action) {
  return prisma.$transaction(async tx => {
    const assignment = await tx.studyTaskAssignment.findUnique({ where: { taskId_studentId: { taskId, studentId } } });
    if (!assignment) throw new RouteError(404, 'This task is not assigned to you');
    const now = new Date();

    if (action === 'start' || action === 'resume') {
      const expected = action === 'start' ? 'NOT_STARTED' : 'PAUSED';
      if (assignment.status !== expected) throw new RouteError(409, action === 'start' ? 'This task has already been started' : 'This task is not paused');
      const active = await tx.studyTimeSession.findFirst({
        where: { taskAssignmentTaskId: taskId, taskAssignmentStudentId: studentId, endedAt: null }
      });
      if (active) throw new RouteError(409, 'A timer is already running for this task');
      const changed = await tx.studyTaskAssignment.updateMany({
        where: { taskId, studentId, status: expected },
        data: { status: 'RUNNING', startedAt: assignment.startedAt || now, completed: false, completedAt: null }
      });
      if (!changed.count) throw new RouteError(409, 'Task status changed; refresh and try again');
      await tx.studyTimeSession.create({
        data: {
          studentId, taskId, taskAssignmentTaskId: taskId, taskAssignmentStudentId: studentId,
          startedAt: now, heartbeatAt: now
        }
      });
    } else if (action === 'pause') {
      if (assignment.status !== 'RUNNING') throw new RouteError(409, 'This task does not have a running timer');
      const active = await tx.studyTimeSession.findFirst({
        where: { taskAssignmentTaskId: taskId, taskAssignmentStudentId: studentId, endedAt: null },
        orderBy: { startedAt: 'desc' }
      });
      if (!active) throw new RouteError(409, 'No running timer was found for this task');
      const changed = await tx.studyTaskAssignment.updateMany({
        where: { taskId, studentId, status: 'RUNNING' }, data: { status: 'PAUSED' }
      });
      if (!changed.count) throw new RouteError(409, 'Task status changed; refresh and try again');
      await tx.studyTimeSession.update({
        where: { id: active.id },
        data: { pausedAt: now, endedAt: now, duration: secondsBetween(active.startedAt, now) }
      });
    } else if (action === 'complete') {
      if (assignment.status === 'COMPLETED') return assignment;
      if (assignment.status === 'RUNNING') {
        const active = await tx.studyTimeSession.findFirst({
          where: { taskAssignmentTaskId: taskId, taskAssignmentStudentId: studentId, endedAt: null },
          orderBy: { startedAt: 'desc' }
        });
        if (active) await tx.studyTimeSession.update({
          where: { id: active.id },
          data: { endedAt: now, duration: secondsBetween(active.startedAt, now) }
        });
      }
      return tx.studyTaskAssignment.update({
        where: { taskId_studentId: { taskId, studentId } },
        data: { status: 'COMPLETED', completed: true, completedAt: now }
      });
    }

    return tx.studyTaskAssignment.findUnique({ where: { taskId_studentId: { taskId, studentId } } });
  });
}

router.use(requireAuth);

router.get('/study-tasks', wrap(async (req, res) => {
  if (req.user.role === 'STUDENT') {
    await pauseStaleTimers({ studentId: req.user.id, task: { type: 'TEACHER_ASSIGNED', published: true } });
    const assignments = await prisma.studyTaskAssignment.findMany({
      where: { studentId: req.user.id, task: { type: 'TEACHER_ASSIGNED', published: true } },
      include: { task: { include: { createdBy: { select: { id: true, name: true } } } } },
      orderBy: { task: { createdAt: 'desc' } }
    });
    const grouped = await sessionsFor(assignments);
    return res.json(assignments.map(assignment => progressView(assignment, grouped.get(`${assignment.taskId}:${assignment.studentId}`) || [])));
  }
  if (req.user.role !== 'TEACHER') return res.sendStatus(403);

  await pauseStaleTimers({ task: { createdById: req.user.id, type: 'TEACHER_ASSIGNED' } });
  const tasks = await prisma.studyTask.findMany({
    where: { createdById: req.user.id, type: 'TEACHER_ASSIGNED' },
    include: { assignments: { include: { student: { select: { id: true, name: true, email: true } } } } },
    orderBy: { createdAt: 'desc' }
  });
  const assignmentRows = tasks.flatMap(task => task.assignments);
  const grouped = await sessionsFor(assignmentRows);
  return res.json(tasks.map(task => ({
    ...task,
    assignments: task.assignments.map(assignment => progressView(assignment, grouped.get(`${assignment.taskId}:${assignment.studentId}`) || []))
  })));
}));

router.post('/study-tasks', allowRoles('TEACHER'), wrap(async (req, res) => {
  const data = taskInput.parse(req.body);
  const ids = await studentIdsFor(data.audience, data.studentIds);
  const task = await prisma.studyTask.create({
    data: {
      title: data.title, description: data.description || '', type: 'TEACHER_ASSIGNED',
      createdById: req.user.id, deadline: data.dueAt ? new Date(data.dueAt) : null,
      durationMinutes: data.durationMinutes ?? 0, published: data.published ?? false,
      assignments: { create: ids.map(studentId => ({ studentId })) }
    },
    include: { assignments: true }
  });
  res.status(201).json(task);
}));

router.patch('/study-tasks/:taskId', allowRoles('TEACHER'), wrap(async (req, res) => {
  const data = taskInput.partial().parse(req.body);
  const task = await prisma.studyTask.findFirst({ where: { id: req.params.taskId, createdById: req.user.id, type: 'TEACHER_ASSIGNED' } });
  if (!task) return res.sendStatus(404);

  const wantsRecipients = data.audience !== undefined || data.studentIds !== undefined;
  let ids;
  if (wantsRecipients) ids = await studentIdsFor(data.audience || 'SELECTED', data.studentIds || []);
  try {
    const updated = await prisma.$transaction(async tx => {
      if (ids) {
        const current = await tx.studyTaskAssignment.findMany({ where: { taskId: task.id } });
        const keep = new Set(ids);
        const removed = current.filter(row => !keep.has(row.studentId));
        for (const row of removed) {
          const hasSession = await tx.studyTimeSession.count({ where: { taskAssignmentTaskId: task.id, taskAssignmentStudentId: row.studentId } });
          if (row.status !== 'NOT_STARTED' || hasSession) throw new RouteError(409, 'Students with started tasks or recorded time cannot be removed');
        }
        if (removed.length) await tx.studyTaskAssignment.deleteMany({ where: { taskId: task.id, studentId: { in: removed.map(row => row.studentId) } } });
        const currentIds = new Set(current.map(row => row.studentId));
        const additions = ids.filter(id => !currentIds.has(id));
        if (additions.length) await tx.studyTaskAssignment.createMany({ data: additions.map(studentId => ({ taskId: task.id, studentId })) });
      }
      return tx.studyTask.update({
        where: { id: task.id },
        data: {
          ...(data.title !== undefined ? { title: data.title } : {}),
          ...(data.description !== undefined ? { description: data.description } : {}),
          ...(data.dueAt !== undefined ? { deadline: data.dueAt ? new Date(data.dueAt) : null } : {}),
          ...(data.durationMinutes !== undefined ? { durationMinutes: data.durationMinutes ?? 0 } : {})
        },
        include: { assignments: true }
      });
    });
    return res.json(updated);
  } catch (error) {
    if (error instanceof RouteError) return res.status(error.status).json({ error: error.message });
    throw error;
  }
}));

router.delete('/study-tasks/:taskId', allowRoles('TEACHER'), wrap(async (req, res) => {
  const task = await prisma.studyTask.findFirst({ where: { id: req.params.taskId, createdById: req.user.id, type: 'TEACHER_ASSIGNED' } });
  if (!task) return res.sendStatus(404);
  await prisma.studyTask.delete({ where: { id: task.id } });
  return res.sendStatus(204);
}));

router.post('/study-tasks/:taskId/publish', allowRoles('TEACHER'), wrap(async (req, res) => {
  const result = await prisma.studyTask.updateMany({
    where: { id: req.params.taskId, createdById: req.user.id, type: 'TEACHER_ASSIGNED' },
    data: { published: true }
  });
  return result.count ? res.json({ published: true }) : res.sendStatus(404);
}));

router.get('/study-tasks/:taskId/students/:studentId/sessions', allowRoles('TEACHER'), wrap(async (req, res) => {
  const assignment = await prisma.studyTaskAssignment.findFirst({
    where: { taskId: req.params.taskId, studentId: req.params.studentId, task: { createdById: req.user.id, type: 'TEACHER_ASSIGNED' } },
    include: { student: { select: { id: true, name: true } }, task: { select: { id: true, title: true } } }
  });
  if (!assignment) return res.sendStatus(404);
  const sessions = await prisma.studyTimeSession.findMany({
    where: { taskAssignmentTaskId: assignment.taskId, taskAssignmentStudentId: assignment.studentId },
    orderBy: { startedAt: 'asc' }
  });
  const progress = progressView(assignment, sessions);
  return res.json({ student: assignment.student, task: assignment.task, status: assignment.status, completedAt: assignment.completedAt, totalSeconds: progress.totalSeconds, sessions });
}));

router.post('/study-tasks/:taskId/:action', allowRoles('STUDENT'), wrap(async (req, res) => {
  const { taskId, action } = req.params;
  if (!['start', 'pause', 'resume', 'complete', 'heartbeat'].includes(action)) return res.sendStatus(404);
  const assignment = await studentAssignment(taskId, req.user.id);
  if (!assignment) return res.status(404).json({ error: 'This published task is not assigned to you' });

  if (action === 'heartbeat') {
    if (assignment.status !== 'RUNNING') return res.status(409).json({ error: 'This task does not have a running timer' });
    const now = new Date();
    const updated = await prisma.studyTimeSession.updateMany({
      where: { taskAssignmentTaskId: taskId, taskAssignmentStudentId: req.user.id, endedAt: null },
      data: { heartbeatAt: now }
    });
    if (!updated.count) return res.status(409).json({ error: 'No running timer was found for this task' });
    return res.json({ heartbeatAt: now });
  }

  try {
    const progress = await transitionTimer(taskId, req.user.id, action);
    const sessions = await prisma.studyTimeSession.findMany({
      where: { taskAssignmentTaskId: taskId, taskAssignmentStudentId: req.user.id },
      orderBy: { startedAt: 'asc' }
    });
    return res.json(progressView(progress, sessions));
  } catch (error) {
    if (error instanceof RouteError) return res.status(error.status).json({ error: error.message });
    throw error;
  }
}));

module.exports = router;
