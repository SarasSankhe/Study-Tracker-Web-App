const express = require('express');
const { spawn } = require('node:child_process');
const path = require('node:path');
const { z } = require('zod');
const prisma = require('../config/prisma');
const { requireAuth, allowRoles } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();
const wrap = asyncHandler;
const uploadDir = path.resolve(process.env.UPLOAD_DIR || path.resolve(__dirname, '../../uploads'));
const analyzerScript = path.resolve(__dirname, '../../python/plagiarism/analyzer.py');
const submissionIdSchema = z.string().regex(/^[A-Za-z0-9_-]{1,64}$/);
const assignmentIdSchema = z.string().regex(/^[A-Za-z0-9_-]{1,64}$/);
const reviewSchema = z.object({ reviewStatus: z.enum(['NOT_REVIEWED', 'REVIEWED', 'DISMISSED']) });
const MAX_ASSIGNMENT_SUBMISSIONS = 200;

function runAnalyzer(payload) {
  return new Promise((resolve, reject) => {
    const python = process.env.PLAGIARISM_PYTHON || (process.platform === 'win32' ? 'python' : 'python3');
    const child = spawn(python, ['-u', analyzerScript], {
      cwd: path.dirname(analyzerScript),
      windowsHide: true,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: {
        PATH: process.env.PATH || '',
        SYSTEMROOT: process.env.SYSTEMROOT || '',
        WINDIR: process.env.WINDIR || '',
        PYTHONIOENCODING: 'utf-8',
        PYTHONUTF8: '1'
      }
    });
    let stdout = '', stderr = '', settled = false, timedOut = false, overflow = false;
    const maxOutput = 12 * 1024 * 1024;
    const timeout = setTimeout(() => { timedOut = true; child.kill(); }, 120_000);
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      error ? reject(error) : resolve(value);
    };
    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', chunk => {
      stdout += chunk;
      if (Buffer.byteLength(stdout, 'utf8') > maxOutput) { overflow = true; child.kill(); }
    });
    child.stderr.on('data', chunk => { if (stderr.length < 24_000) stderr += chunk; });
    child.on('error', error => {
      if (['ENOENT', 'EACCES', 'UNKNOWN'].includes(error.code)) {
        const unavailable = new Error('Python was not found (' + python + '). Install Python 3 and run npm run plagiarism:install in the backend folder, or set PLAGIARISM_PYTHON.');
        unavailable.code = 'PLAGIARISM_PYTHON_UNAVAILABLE';
        return finish(unavailable);
      }
      finish(new Error(`Could not start the plagiarism analyzer: ${error.message}`));
    });
    child.on('close', code => {
      if (timedOut) { const error = new Error('Plagiarism analysis exceeded the 120 second limit.'); error.code = 'PLAGIARISM_TIMEOUT'; return finish(error); }
      if (overflow) { const error = new Error('Plagiarism analyzer output exceeded the configured limit.'); error.code = 'PLAGIARISM_OUTPUT_LIMIT'; return finish(error); }
      if (code !== 0) {
        const missing = stderr.match(/No module named ['\"](sklearn|docx|pypdf)['\"]/);
        const error = new Error(missing ? 'Python dependency "' + missing[1] + '" is missing. Run npm run plagiarism:install in the backend folder.' : 'Python document analysis failed. Verify the Python dependencies and try again.');
        error.code = missing ? 'PLAGIARISM_DEPENDENCY_MISSING' : 'PLAGIARISM_ANALYSIS_FAILED';
        return finish(error);
      }
      try { finish(null, JSON.parse(stdout)); }
      catch (_) { const error = new Error('Python analyzer returned invalid JSON.'); error.code = 'PLAGIARISM_INVALID_OUTPUT'; finish(error); }
    });
    child.stdin.on('error', () => {});
    child.stdin.end(JSON.stringify(payload));
  });
}

async function runAnalyzerForResponse(payload, res) {
  try { return await runAnalyzer(payload); }
  catch (error) {
    const unavailable = error.code === 'PLAGIARISM_PYTHON_UNAVAILABLE' || error.code === 'PLAGIARISM_DEPENDENCY_MISSING';
    const timeout = error.code === 'PLAGIARISM_TIMEOUT';
    const limit = error.code === 'PLAGIARISM_OUTPUT_LIMIT';
    const status = unavailable ? 503 : timeout ? 504 : limit ? 413 : 502;
    res.status(status).json({ error: error.message });
    return null;
  }
}

function filePathFor(submission) {
  if (!submission.storedName || path.basename(submission.storedName) !== submission.storedName) return null;
  const candidate = path.resolve(uploadDir, submission.storedName);
  const relative = path.relative(uploadDir, candidate);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) return null;
  return candidate;
}

function analyzerDocuments(submissions) {
  return submissions.map(submission => ({
    submissionId: submission.id,
    studentId: submission.studentId,
    fileName: submission.fileName,
    path: filePathFor(submission) || ''
  }));
}

function publicResult(result) {
  const stale = result.analysis && result.firstSubmission && result.secondSubmission &&
    new Date(result.analysis.analyzedAt) < new Date(Math.max(new Date(result.firstSubmission.submittedAt), new Date(result.secondSubmission.submittedAt)));
  let sharedTerms = [];
  try { sharedTerms = JSON.parse(result.sharedTerms || '[]'); } catch (_) {}
  return {
    id: result.id,
    assignmentId: result.assignmentId,
    percentage: result.percentage,
    analyzedAt: result.analyzedAt,
    reviewStatus: result.reviewStatus,
    sharedTerms,
    stale: !!stale,
    firstStudent: { id: result.firstStudent.id, name: result.firstStudent.name },
    secondStudent: { id: result.secondStudent.id, name: result.secondStudent.name },
    firstSubmission: result.firstSubmission ? { id: result.firstSubmission.id, fileName: result.firstSubmission.fileName, submittedAt: result.firstSubmission.submittedAt, sizeBytes: result.firstSubmission.sizeBytes } : null,
    secondSubmission: result.secondSubmission ? { id: result.secondSubmission.id, fileName: result.secondSubmission.fileName, submittedAt: result.secondSubmission.submittedAt, sizeBytes: result.secondSubmission.sizeBytes } : null
  };
}

async function ownedAssignment(assignmentId, teacherId) {
  const parsed = assignmentIdSchema.safeParse(assignmentId);
  if (!parsed.success) return null;
  return prisma.assignment.findFirst({ where: { id: parsed.data, teacherId } });
}

router.use(requireAuth, allowRoles('TEACHER'));

router.post('/assignments/:assignmentId/plagiarism/analyze', wrap(async (req, res) => {
  const assignment = await ownedAssignment(req.params.assignmentId, req.user.id);
  if (!assignment) return res.sendStatus(404);
  const submissions = await prisma.submission.findMany({
    where: { assignmentId: assignment.id },
    include: { student: { select: { id: true, name: true } } },
    orderBy: [{ submittedAt: 'desc' }, { id: 'asc' }]
  });
  if (!submissions.length) return res.status(422).json({ error: 'No student submissions are available for this assignment.' });
  if (submissions.length > MAX_ASSIGNMENT_SUBMISSIONS) return res.status(413).json({ error: `An assignment can have at most ${MAX_ASSIGNMENT_SUBMISSIONS} submissions per analysis.` });
  const analysis = await runAnalyzerForResponse({ uploadRoot: uploadDir, documents: analyzerDocuments(submissions) }, res);
  if (!analysis) return;
  const bySubmission = new Map(submissions.map(submission => [submission.id, submission]));
  const excluded = analysis.documents.filter(item => item.status !== 'ANALYZED').map(item => {
    const submission = bySubmission.get(item.submissionId);
    return { submissionId: item.submissionId, fileName: submission?.fileName || 'Unknown file', studentName: submission?.student.name || 'Student', status: item.status, reason: item.reason || 'Document could not be analyzed.' };
  });
  const analyzedAt = new Date();
  const saved = await prisma.$transaction(async tx => {
    const run = await tx.similarityAnalysis.create({ data: {
      assignmentId: assignment.id,
      analyzedAt,
      eligibleSubmissionCount: analysis.eligibleSubmissionCount,
      excludedSubmissions: JSON.stringify(excluded)
    } });
    const results = [];
    for (const comparison of analysis.comparisons) {
      const firstSubmission = bySubmission.get(comparison.firstSubmissionId);
      const secondSubmission = bySubmission.get(comparison.secondSubmissionId);
      if (!firstSubmission || !secondSubmission || firstSubmission.studentId === secondSubmission.studentId) continue;
      let first = firstSubmission, second = secondSubmission;
      if (first.studentId.localeCompare(second.studentId) > 0) [first, second] = [second, first];
      const compound = { assignmentId: assignment.id, firstStudentId: first.studentId, secondStudentId: second.studentId };
      const previous = await tx.similarityResult.findUnique({ where: { assignmentId_firstStudentId_secondStudentId: compound } });
      const unchanged = previous && previous.firstSubmissionId === first.id && previous.secondSubmissionId === second.id &&
        new Date(previous.analyzedAt) >= new Date(Math.max(new Date(first.submittedAt), new Date(second.submittedAt)));
      results.push(await tx.similarityResult.upsert({
        where: { assignmentId_firstStudentId_secondStudentId: compound },
        create: {
          ...compound, analysisId: run.id, firstSubmissionId: first.id, secondSubmissionId: second.id,
          percentage: comparison.percentage, sharedTerms: JSON.stringify(comparison.sharedTerms || []), analyzedAt,
          reviewStatus: 'NOT_REVIEWED'
        },
        update: {
          analysisId: run.id, firstSubmissionId: first.id, secondSubmissionId: second.id,
          percentage: comparison.percentage, sharedTerms: JSON.stringify(comparison.sharedTerms || []), analyzedAt,
          reviewStatus: unchanged ? previous.reviewStatus : 'NOT_REVIEWED'
        }
      }));
    }
    return { run, results };
  });
  const resultIds = saved.results.map(result => result.id);
  const fullResults = resultIds.length ? await prisma.similarityResult.findMany({
    where: { id: { in: resultIds } },
    include: { firstStudent: true, secondStudent: true, firstSubmission: true, secondSubmission: true, analysis: true },
    orderBy: { percentage: 'desc' }
  }) : [];
  res.json({
    assignment: { id: assignment.id, title: assignment.title },
    analysis: { id: saved.run.id, analyzedAt: saved.run.analyzedAt, eligibleSubmissionCount: saved.run.eligibleSubmissionCount, status: saved.run.eligibleSubmissionCount < 2 ? 'INSUFFICIENT_SUBMISSIONS' : 'COMPLETED' },
    excluded,
    results: fullResults.map(publicResult),
    message: saved.run.eligibleSubmissionCount < 2 ? 'At least two submissions with extractable text are needed to compare students.' : null
  });
}));

router.get('/assignments/:assignmentId/plagiarism/results', wrap(async (req, res) => {
  const assignment = await ownedAssignment(req.params.assignmentId, req.user.id);
  if (!assignment) return res.sendStatus(404);
  const run = await prisma.similarityAnalysis.findFirst({ where: { assignmentId: assignment.id }, orderBy: { analyzedAt: 'desc' } });
  if (!run) return res.json({ assignment: { id: assignment.id, title: assignment.title }, analysis: null, excluded: [], results: [] });
  let excluded = [];
  try { excluded = JSON.parse(run.excludedSubmissions || '[]'); } catch (_) {}
  const results = await prisma.similarityResult.findMany({
    where: { analysisId: run.id },
    include: { firstStudent: true, secondStudent: true, firstSubmission: true, secondSubmission: true, analysis: true },
    orderBy: { percentage: 'desc' }
  });
  res.json({
    assignment: { id: assignment.id, title: assignment.title },
    analysis: { id: run.id, analyzedAt: run.analyzedAt, eligibleSubmissionCount: run.eligibleSubmissionCount, status: run.eligibleSubmissionCount < 2 ? 'INSUFFICIENT_SUBMISSIONS' : 'COMPLETED' },
    excluded, results: results.map(publicResult)
  });
}));

router.get('/plagiarism/results/:resultId', wrap(async (req, res) => {
  const parsed = submissionIdSchema.safeParse(req.params.resultId);
  if (!parsed.success) return res.sendStatus(400);
  const result = await prisma.similarityResult.findUnique({
    where: { id: parsed.data },
    include: { assignment: true, firstStudent: true, secondStudent: true, firstSubmission: true, secondSubmission: true, analysis: true }
  });
  if (!result || result.assignment.teacherId !== req.user.id) return res.sendStatus(404);
  const resultView = publicResult(result);
  if (resultView.stale) return res.status(409).json({ error: 'A submission changed after this analysis. Analyze the assignment again before reviewing this comparison.' });
  const documents = await runAnalyzerForResponse({ uploadRoot: uploadDir, documents: analyzerDocuments([result.firstSubmission, result.secondSubmission]), includeText: true }, res);
  if (!documents) return;
  const failed = documents.documents.find(item => item.status !== 'ANALYZED');
  if (failed) return res.status(409).json({ error: `Could not reopen comparison file: ${failed.reason || failed.status}.` });
  const textById = new Map(documents.documents.map(item => [item.submissionId, item.text]));
  res.json({
    ...resultView,
    assignmentTitle: result.assignment.title,
    sharedTerms: resultView.sharedTerms,
    firstDocument: { ...resultView.firstSubmission, studentName: result.firstStudent.name, text: textById.get(result.firstSubmission.id) },
    secondDocument: { ...resultView.secondSubmission, studentName: result.secondStudent.name, text: textById.get(result.secondSubmission.id) }
  });
}));

router.patch('/plagiarism/results/:resultId/review', wrap(async (req, res) => {
  const parsedId = submissionIdSchema.safeParse(req.params.resultId);
  if (!parsedId.success) return res.sendStatus(400);
  const data = reviewSchema.parse(req.body);
  const result = await prisma.similarityResult.findFirst({
    where: { id: parsedId.data, assignment: { teacherId: req.user.id } },
    include: { firstStudent: true, secondStudent: true, firstSubmission: true, secondSubmission: true, analysis: true }
  });
  if (!result) return res.sendStatus(404);
  if (publicResult(result).stale) return res.status(409).json({ error: 'A submission changed after this analysis. Analyze the assignment again before reviewing this comparison.' });
  const updated = await prisma.similarityResult.update({ where: { id: result.id }, data: { reviewStatus: data.reviewStatus }, include: { firstStudent: true, secondStudent: true, firstSubmission: true, secondSubmission: true, analysis: true } });
  res.json(publicResult(updated));
}));

module.exports = router;
