const express = require('express');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { z } = require('zod');
const prisma = require('../config/prisma');
const { requireAuth, allowRoles } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();
const wrap = asyncHandler;
const valid = (schema, data) => schema.parse(data);
const userSafe = ({ id, name, email, role, createdAt }) => ({ id, name, email, role, createdAt });
const accountSchema = z.object({ name: z.string().trim().min(1).max(100), email: z.string().trim().email().transform(v => v.toLowerCase()), password: z.string().min(8).max(128), role: z.enum(['STUDENT', 'TEACHER']) });
const assignmentSchema = z.object({ title: z.string().trim().min(1).max(200), subject: z.string().trim().min(1).max(100).optional(), description: z.string().max(5000).optional(), instructions: z.string().max(5000).optional(), dueAt: z.string().datetime().nullable().optional(), published: z.boolean().optional(), studentIds: z.array(z.string()).optional() });
const uploadDir = path.resolve(process.env.UPLOAD_DIR || 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({ destination: uploadDir, filename: (_req, file, cb) => cb(null, `${Date.now()}-${require('crypto').randomUUID()}${path.extname(file.originalname).toLowerCase()}`) });
const uploadLimit = Math.min(Number(process.env.MAX_UPLOAD_BYTES) || 900 * 1024, 900 * 1024);
const upload = multer({ storage, limits: { fileSize: uploadLimit }, fileFilter: (_req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase();
  cb(null, ['.pdf','.doc','.docx','.txt','.png','.jpg','.jpeg'].includes(ext));
} });

router.post('/auth/register', wrap(async (req, res) => {
  const data = valid(accountSchema, req.body);
  const exists = await prisma.user.findUnique({ where: { email: data.email } });
  if (exists) return res.status(409).json({ error: 'Email is already registered' });
  const user = await prisma.user.create({ data: { name: data.name, email: data.email, role: data.role, passwordHash: await bcrypt.hash(data.password, 12) } });
  req.session.user = userSafe(user);
  res.status(201).json({ user: userSafe(user) });
}));
router.post('/auth/login', wrap(async (req, res) => {
  const data = z.object({ email: z.string().email().transform(v => v.toLowerCase()), password: z.string().min(1), role: z.enum(['STUDENT','TEACHER']).optional() }).parse(req.body);
  const user = await prisma.user.findUnique({ where: { email: data.email } });
  if (!user || (data.role && data.role !== user.role) || !(await bcrypt.compare(data.password, user.passwordHash))) return res.status(401).json({ error: 'Invalid email or password' });
  req.session.user = userSafe(user);
  res.json({ user: req.session.user });
}));
router.post('/auth/logout', requireAuth, (req, res) => req.session.destroy(err => err ? res.status(500).json({ error: 'Could not log out' }) : res.json({ ok: true })));
router.get('/auth/me', requireAuth, wrap(async (req, res) => res.json({ user: userSafe(await prisma.user.findUniqueOrThrow({ where: { id: req.user.id } })) })));

router.use(requireAuth);
router.get('/students', allowRoles('TEACHER'), wrap(async (_req, res) => res.json(await prisma.user.findMany({ where: { role: 'STUDENT' }, select: { id: true, name: true, email: true, createdAt: true }, orderBy: { name: 'asc' } }))));
router.get('/students/:id', wrap(async (req, res) => {
  if (req.user.role !== 'TEACHER' && req.user.id !== req.params.id) return res.sendStatus(403);
  const user = await prisma.user.findFirst({ where: { id: req.params.id, role: 'STUDENT' }, select: { id:true,name:true,email:true,role:true,createdAt:true } });
  return user ? res.json(user) : res.sendStatus(404);
}));
router.get('/teachers/:id', wrap(async (req, res) => {
  if (req.user.role !== 'TEACHER' && req.user.id !== req.params.id) return res.sendStatus(403);
  const user = await prisma.user.findFirst({ where: { id: req.params.id, role: 'TEACHER' }, select: { id:true,name:true,email:true,role:true,createdAt:true } });
  return user ? res.json(user) : res.sendStatus(404);
}));

router.post('/classes', allowRoles('TEACHER'), wrap(async (req,res) => {
  const d = z.object({ name:z.string().trim().min(1), studentIds:z.array(z.string()).default([]) }).parse(req.body);
  const students = await prisma.user.findMany({ where:{ id:{in:d.studentIds},role:'STUDENT' },select:{id:true} });
  if(students.length !== new Set(d.studentIds).size) return res.status(400).json({error:'All class members must be students'});
  res.status(201).json(await prisma.class.create({data:{name:d.name,teacherId:req.user.id,students:{create:students.map(s=>({studentId:s.id}))}},include:{students:true}}));
}));
router.get('/classes', wrap(async (req,res)=>res.json(await prisma.class.findMany({where:req.user.role==='TEACHER'?{teacherId:req.user.id}:{students:{some:{studentId:req.user.id}}},include:{students:{include:{student:{select:{id:true,name:true,email:true}}}}}}))));

router.post('/assignments', allowRoles('TEACHER'), wrap(async(req,res)=>{
  const d=valid(assignmentSchema,req.body); const ids=[...new Set(d.studentIds||[])];
  if(ids.length){const students=await prisma.user.findMany({where:{id:{in:ids},role:'STUDENT'},select:{id:true}});if(students.length!==ids.length)return res.status(400).json({error:'Recipients must be students'});}
  const assignment=await prisma.assignment.create({data:{title:d.title,subject:d.subject||'General',description:d.description||'',instructions:d.instructions||'',dueAt:d.dueAt?new Date(d.dueAt):null,published:d.published||false,teacherId:req.user.id,recipients:{create:ids.map(studentId=>({studentId}))}},include:{recipients:true}});
  res.status(201).json(assignment);
}));
router.get('/assignments', wrap(async(req,res)=>res.json(await prisma.assignment.findMany({where:req.user.role==='TEACHER'?{teacherId:req.user.id}:{published:true,recipients:{some:{studentId:req.user.id}}},include:{recipients:true,submissions:req.user.role==='TEACHER'?{include:{student:{select:{id:true,name:true,email:true}},grade:true}}:{where:{studentId:req.user.id},include:{grade:true}}},orderBy:{createdAt:'desc'}}))));
router.get('/assignments/:id', wrap(async(req,res)=>{const a=await prisma.assignment.findUnique({where:{id:req.params.id},include:{recipients:true,submissions:{include:{student:{select:{id:true,name:true}},grade:true}}}});if(!a)return res.sendStatus(404);const allowed=req.user.role==='TEACHER'?a.teacherId===req.user.id:a.published&&a.recipients.some(x=>x.studentId===req.user.id);return allowed?res.json(a):res.sendStatus(403);}));
router.patch('/assignments/:id', allowRoles('TEACHER'), wrap(async(req,res)=>{const a=await prisma.assignment.findFirst({where:{id:req.params.id,teacherId:req.user.id}});if(!a)return res.sendStatus(404);const d=valid(assignmentSchema.partial().omit({studentIds:true}),req.body);res.json(await prisma.assignment.update({where:{id:a.id},data:{...d,dueAt:d.dueAt===undefined?undefined:d.dueAt?new Date(d.dueAt):null}}));}));
router.delete('/assignments/:id', allowRoles('TEACHER'), wrap(async(req,res)=>{const a=await prisma.assignment.findFirst({where:{id:req.params.id,teacherId:req.user.id}});if(!a)return res.sendStatus(404);await prisma.assignment.delete({where:{id:a.id}});res.sendStatus(204);}));
router.post('/assignments/:id/publish', allowRoles('TEACHER'), wrap(async(req,res)=>{const a=await prisma.assignment.updateMany({where:{id:req.params.id,teacherId:req.user.id},data:{published:true}});return a.count?res.json({published:true}):res.sendStatus(404);}));
router.put('/assignments/:id/recipients', allowRoles('TEACHER'), wrap(async(req,res)=>{const d=z.object({studentIds:z.array(z.string())}).parse(req.body);const a=await prisma.assignment.findFirst({where:{id:req.params.id,teacherId:req.user.id}});if(!a)return res.sendStatus(404);const ids=[...new Set(d.studentIds)];const students=await prisma.user.findMany({where:{id:{in:ids},role:'STUDENT'},select:{id:true}});if(students.length!==ids.length)return res.status(400).json({error:'Recipients must be students'});await prisma.$transaction([prisma.assignmentRecipient.deleteMany({where:{assignmentId:a.id}}),prisma.assignmentRecipient.createMany({data:ids.map(studentId=>({assignmentId:a.id,studentId}))})]);res.json({studentIds:ids});}));

router.post('/assignments/:id/submissions', allowRoles('STUDENT'), upload.single('file'), wrap(async(req,res)=>{
  if(!req.file)return res.status(400).json({error:'Upload a supported file (PDF, Office, text, or image)'});
  const a=await prisma.assignment.findFirst({where:{id:req.params.id,published:true,recipients:{some:{studentId:req.user.id}}}});if(!a){fs.unlink(req.file.path,()=>{});return res.sendStatus(404);}
  const previous=await prisma.submission.findUnique({where:{assignmentId_studentId:{assignmentId:a.id,studentId:req.user.id}}});
  const data={fileName:path.basename(req.file.originalname),storedName:req.file.filename,mimeType:req.file.mimetype,sizeBytes:req.file.size,submittedAt:new Date(),reviewStatus:'NOT_REVIEWED'};
  if(previous)fs.unlink(path.join(uploadDir,previous.storedName),()=>{});
  res.status(previous?200:201).json(await prisma.submission.upsert({where:{assignmentId_studentId:{assignmentId:a.id,studentId:req.user.id}},create:{...data,assignmentId:a.id,studentId:req.user.id},update:data}));
}));
router.get('/submissions', wrap(async(req,res)=>res.json(await prisma.submission.findMany({where:req.user.role==='STUDENT'?{studentId:req.user.id}:{assignment:{teacherId:req.user.id}},include:{assignment:true,student:{select:{id:true,name:true,email:true}},grade:true},orderBy:{submittedAt:'desc'}}))));
router.get('/submissions/:id/download', wrap(async(req,res)=>{const s=await prisma.submission.findUnique({where:{id:req.params.id},include:{assignment:true}});if(!s)return res.sendStatus(404);if(req.user.id!==s.studentId&&(req.user.role!=='TEACHER'||s.assignment.teacherId!==req.user.id))return res.sendStatus(403);return res.download(path.join(uploadDir,s.storedName),s.fileName);}));
router.put('/submissions/:id/grade', allowRoles('TEACHER'), wrap(async(req,res)=>{const d=z.object({marks:z.number().min(0).max(1000).nullable().optional(),feedback:z.string().max(5000).optional()}).parse(req.body);if(d.marks==null&&!d.feedback?.trim())return res.status(400).json({error:'Enter marks or feedback before saving'});const s=await prisma.submission.findFirst({where:{id:req.params.id,assignment:{teacherId:req.user.id}}});if(!s)return res.sendStatus(404);const grade=await prisma.grade.upsert({where:{submissionId:s.id},create:{submissionId:s.id,teacherId:req.user.id,marks:d.marks??null,feedback:d.feedback||''},update:{teacherId:req.user.id,marks:d.marks??null,feedback:d.feedback||''}});await prisma.submission.update({where:{id:s.id},data:{reviewStatus:'REVIEWED'}});res.json(grade);}));
router.get('/submissions/:id/feedback', wrap(async(req,res)=>{const s=await prisma.submission.findUnique({where:{id:req.params.id},include:{assignment:true,grade:true}});if(!s)return res.sendStatus(404);if(req.user.id!==s.studentId&&(req.user.role!=='TEACHER'||s.assignment.teacherId!==req.user.id))return res.sendStatus(403);res.json({grade:s.grade,reviewStatus:s.reviewStatus});}));
router.patch('/submissions/:id/review-status', allowRoles('TEACHER'), wrap(async(req,res)=>{const d=z.object({reviewStatus:z.enum(['NOT_REVIEWED','IN_REVIEW','REVIEWED'])}).parse(req.body);const s=await prisma.submission.findFirst({where:{id:req.params.id,assignment:{teacherId:req.user.id}}});if(!s)return res.sendStatus(404);res.json(await prisma.submission.update({where:{id:s.id},data:{reviewStatus:d.reviewStatus}}));}));

router.post('/tasks', wrap(async(req,res)=>{const d=z.object({id:z.string().optional(),title:z.string().trim().min(1).max(200),description:z.string().max(5000).optional(),category:z.string().max(60).optional(),priority:z.string().max(20).optional(),scheduledTime:z.string().max(20).optional(),durationMinutes:z.number().int().min(1).max(480).optional(),notes:z.string().max(5000).optional(),type:z.enum(['PERSONAL','TEACHER_ASSIGNED']),deadline:z.string().datetime().nullable().optional(),studentIds:z.array(z.string()).optional()}).parse(req.body);if(d.type==='PERSONAL'&&req.user.role!=='STUDENT'||d.type==='TEACHER_ASSIGNED'&&req.user.role!=='TEACHER')return res.sendStatus(403);const ids=d.type==='PERSONAL'?[req.user.id]:[...new Set(d.studentIds||[])];if(!ids.length)return res.status(400).json({error:'Assign the task to at least one student'});const students=await prisma.user.findMany({where:{id:{in:ids},role:'STUDENT'},select:{id:true}});if(students.length!==ids.length)return res.status(400).json({error:'Assignees must be students'});res.status(201).json(await prisma.studyTask.create({data:{...(d.id?{id:d.id}:{}),title:d.title,description:d.description||'',category:d.category||'Study',priority:d.priority||'medium',scheduledTime:d.scheduledTime||'',durationMinutes:d.durationMinutes||60,notes:d.notes||'',type:d.type,createdById:req.user.id,deadline:d.deadline?new Date(d.deadline):null,assignments:{create:ids.map(studentId=>({studentId}))}},include:{assignments:true}}));}));
router.get('/tasks', wrap(async(req,res)=>{const type=req.query.type==='PERSONAL'?'PERSONAL':undefined;res.json(await prisma.studyTaskAssignment.findMany({where:req.user.role==='STUDENT'?{studentId:req.user.id,...(type?{task:{type}}:{})}:{task:{createdById:req.user.id,...(type?{type}:{})}},include:{task:true,student:{select:{id:true,name:true}}},orderBy:{task:{createdAt:'desc'}}}));}));
router.patch('/tasks/:taskId', allowRoles('STUDENT'), wrap(async(req,res)=>{const d=z.object({title:z.string().trim().min(1).max(200),description:z.string().max(5000).optional(),category:z.string().max(60).optional(),priority:z.string().max(20).optional(),scheduledTime:z.string().max(20).optional(),durationMinutes:z.number().int().min(1).max(480).optional(),notes:z.string().max(5000).optional(),deadline:z.string().datetime().nullable().optional()}).parse(req.body);const task=await prisma.studyTask.findFirst({where:{id:req.params.taskId,type:'PERSONAL',createdById:req.user.id}});if(!task)return res.sendStatus(404);res.json(await prisma.studyTask.update({where:{id:task.id},data:{...d,description:d.description||'',deadline:d.deadline?new Date(d.deadline):null}}));}));
router.delete('/tasks/:taskId', allowRoles('STUDENT'), wrap(async(req,res)=>{const task=await prisma.studyTask.findFirst({where:{id:req.params.taskId,type:'PERSONAL',createdById:req.user.id}});if(!task)return res.sendStatus(404);await prisma.studyTask.delete({where:{id:task.id}});res.sendStatus(204);}));
router.delete('/personal-tasks', allowRoles('STUDENT'), wrap(async(req,res)=>{const result=await prisma.studyTask.deleteMany({where:{type:'PERSONAL',createdById:req.user.id}});res.json({deleted:result.count});}));
router.patch('/tasks/:taskId/status', allowRoles('STUDENT'), wrap(async(req,res)=>{const d=z.object({completed:z.boolean()}).parse(req.body);const own=await prisma.studyTaskAssignment.findFirst({where:{taskId:req.params.taskId,studentId:req.user.id,task:{type:'PERSONAL'}}});if(!own)return res.sendStatus(404);res.json(await prisma.studyTaskAssignment.update({where:{taskId_studentId:{taskId:req.params.taskId,studentId:req.user.id}},data:{completed:d.completed,completedAt:d.completed?new Date():null}}));}));
router.post('/study-sessions', allowRoles('STUDENT'), wrap(async(req,res)=>{const d=z.object({id:z.string().optional(),taskId:z.string().nullable().optional(),startedAt:z.string().datetime().optional(),pausedAt:z.string().datetime().nullable().optional(),endedAt:z.string().datetime().nullable().optional(),duration:z.number().int().min(0).default(0)}).parse(req.body);if(d.taskId){const own=await prisma.studyTaskAssignment.findUnique({where:{taskId_studentId:{taskId:d.taskId,studentId:req.user.id}},include:{task:true}});if(!own)return res.status(403).json({error:'Task is not assigned to this student'});if(own.task.type==='TEACHER_ASSIGNED')return res.status(403).json({error:'Teacher-assigned task time must use the server timer'});}const data={studentId:req.user.id,taskId:d.taskId||null,startedAt:d.startedAt?new Date(d.startedAt):new Date(),pausedAt:d.pausedAt?new Date(d.pausedAt):null,endedAt:d.endedAt?new Date(d.endedAt):null,duration:d.duration};res.status(201).json(d.id?await prisma.studyTimeSession.upsert({where:{id:d.id},create:{...data,id:d.id},update:{}}):await prisma.studyTimeSession.create({data}));}));
router.get('/study-sessions', allowRoles('STUDENT'), wrap(async(req,res)=>res.json(await prisma.studyTimeSession.findMany({where:{studentId:req.user.id,OR:[{taskId:null},{task:{type:'PERSONAL'}}]},include:{task:true},orderBy:{startedAt:'desc'}}))));
router.delete('/study-sessions', allowRoles('STUDENT'), wrap(async(req,res)=>{const result=await prisma.studyTimeSession.deleteMany({where:{studentId:req.user.id,OR:[{taskId:null},{task:{type:'PERSONAL'}}]}});res.json({deleted:result.count});}));

router.get('/analytics/assignments', allowRoles('TEACHER'), wrap(async(req,res)=>{const assignments=await prisma.assignment.findMany({where:{teacherId:req.user.id},include:{_count:{select:{recipients:true,submissions:true}}}});res.json(assignments.map(a=>({id:a.id,title:a.title,published:a.published,recipients:a._count.recipients,submissions:a._count.submissions})));}));
router.get('/analytics/submissions', allowRoles('TEACHER'), wrap(async(req,res)=>{const [total,pending,reviewed]=await Promise.all([prisma.submission.count({where:{assignment:{teacherId:req.user.id}}}),prisma.submission.count({where:{assignment:{teacherId:req.user.id},reviewStatus:'NOT_REVIEWED'}}),prisma.submission.count({where:{assignment:{teacherId:req.user.id},reviewStatus:'REVIEWED'}})]);res.json({total,pending,reviewed});}));
router.get('/analytics/progress/:studentId', allowRoles('TEACHER'), wrap(async(req,res)=>{const student=await prisma.user.findFirst({where:{id:req.params.studentId,role:'STUDENT',recipients:{some:{assignment:{teacherId:req.user.id}}}},select:{id:true,name:true}});if(!student)return res.sendStatus(404);const [assigned,submissions,completedTasks,studySeconds]=await Promise.all([prisma.assignmentRecipient.count({where:{studentId:student.id,assignment:{teacherId:req.user.id}}}),prisma.submission.count({where:{studentId:student.id,assignment:{teacherId:req.user.id}}}),prisma.studyTaskAssignment.count({where:{studentId:student.id,completed:true,task:{createdById:req.user.id,type:'TEACHER_ASSIGNED'}}}),prisma.studyTimeSession.aggregate({where:{studentId:student.id,task:{createdById:req.user.id,type:'TEACHER_ASSIGNED'}},_sum:{duration:true}})]);res.json({student,assignments:{assigned,submitted:submissions},completedTasks,studySeconds:studySeconds._sum.duration||0});}));
router.get('/announcements', wrap(async(req,res)=>res.json(await prisma.announcement.findMany({where:req.user.role==='TEACHER'?{teacherId:req.user.id}:{teacher:{taughtClasses:{some:{students:{some:{studentId:req.user.id}}}}}},include:{teacher:{select:{id:true,name:true}}},orderBy:{createdAt:'desc'}}))));
router.post('/announcements', allowRoles('TEACHER'), wrap(async(req,res)=>{const d=z.object({title:z.string().trim().min(1).max(200),message:z.string().trim().min(1).max(5000)}).parse(req.body);res.status(201).json(await prisma.announcement.create({data:{...d,teacherId:req.user.id}}));}));

module.exports = router;
