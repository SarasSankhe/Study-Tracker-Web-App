require('dotenv').config();
const app = require('./app');
const prisma = require('./config/prisma');
const port = Number(process.env.PORT) || 3000;
prisma.$connect().then(()=>app.listen(port,()=>console.log(`Study Tracker API listening on http://localhost:${port}`))).catch(err=>{console.error('Database connection failed:',err.message);process.exit(1);});
