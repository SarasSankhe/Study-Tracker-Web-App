"""JSON stdin/stdout worker for TF-IDF internal document similarity."""

import json
import sys
import unicodedata
from pathlib import Path

from text_extractor import extract_document


def analyze(payload: dict) -> dict:
    upload_root = Path(payload["uploadRoot"])
    extracted = [extract_document(item, upload_root) for item in payload.get("documents", [])]
    eligible = [
        {**result, "studentId": item["studentId"]}
        for item, result in zip(payload.get("documents", []), extracted)
        if result["status"] == "ANALYZED"
    ]

    # Keep the vectorizer reference local and explicit for reliable term evidence.
    def similarities(docs):
        if len(docs) < 2:
            return []
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity
        import numpy as np
        texts = [unicodedata.normalize("NFKC", item["text"]).lower() for item in docs]
        word_vectorizer = TfidfVectorizer(ngram_range=(1, 2), stop_words="english", sublinear_tf=True, token_pattern=r"(?u)\b\w+\b")
        word_matrix = None
        try:
            word_matrix = word_vectorizer.fit_transform(texts)
        except ValueError:
            pass
        char_matrix = None
        try:
            char_matrix = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), sublinear_tf=True).fit_transform(texts)
        except ValueError:
            pass
        if word_matrix is None and char_matrix is None:
            return []
        word_scores = cosine_similarity(word_matrix) if word_matrix is not None else None
        char_scores = cosine_similarity(char_matrix) if char_matrix is not None else None
        names = word_vectorizer.get_feature_names_out() if word_matrix is not None else []
        comparisons = []
        for first in range(len(docs)):
            for second in range(first + 1, len(docs)):
                if docs[first]["studentId"] == docs[second]["studentId"]:
                    continue
                parts = []
                if word_scores is not None:
                    parts.append((0.75, float(word_scores[first, second])))
                if char_scores is not None:
                    parts.append((0.25 if word_scores is not None else 1.0, float(char_scores[first, second])))
                score = sum(weight * value for weight, value in parts) / sum(weight for weight, _ in parts)
                terms = []
                if word_matrix is not None:
                    left = word_matrix.getrow(first).toarray().ravel()
                    right = word_matrix.getrow(second).toarray().ravel()
                    shared = np.argsort(left * right)[::-1]
                    terms = [str(names[i]) for i in shared if left[i] > 0 and right[i] > 0][:8]
                comparisons.append({"firstSubmissionId": docs[first]["submissionId"], "secondSubmissionId": docs[second]["submissionId"], "percentage": round(max(0.0, min(1.0, score)) * 100, 2), "sharedTerms": terms})
        return sorted(comparisons, key=lambda item: item["percentage"], reverse=True)

    if not payload.get("includeText", False):
        extracted = [{key: value for key, value in item.items() if key != "text"} for item in extracted]
    return {"documents": extracted, "comparisons": similarities(eligible), "eligibleSubmissionCount": len(eligible)}


def main() -> None:
    try:
        # Fail the whole request clearly when the configured environment is incomplete.
        import docx  # noqa: F401
        import pypdf  # noqa: F401
        import sklearn  # noqa: F401
        payload = json.load(sys.stdin)
        result = analyze(payload)
        sys.stdout.write(json.dumps(result, ensure_ascii=False))
    except Exception as error:
        sys.stderr.write(f"Plagiarism analysis failed: {type(error).__name__}: {error}\n")
        raise SystemExit(2)


if __name__ == "__main__":
    main()
