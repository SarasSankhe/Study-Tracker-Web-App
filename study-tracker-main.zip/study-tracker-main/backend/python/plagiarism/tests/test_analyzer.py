import io
import sys
import tempfile
import unittest
from pathlib import Path

from docx import Document
from pypdf import PdfReader, PdfWriter

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from analyzer import analyze
from text_extractor import extract_document


def make_text_pdf(text: str) -> bytes:
    escaped = text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    stream = f"BT /F1 12 Tf 72 720 Td ({escaped}) Tj ET".encode("ascii")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length " + str(len(stream)).encode("ascii") + b" >>\nstream\n" + stream + b"\nendstream",
    ]
    output = bytearray(b"%PDF-1.4\n")
    offsets = [0]
    for index, obj in enumerate(objects, 1):
        offsets.append(len(output))
        output.extend(f"{index} 0 obj\n".encode("ascii") + obj + b"\nendobj\n")
    xref = len(output)
    output.extend(f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode("ascii"))
    for offset in offsets[1:]:
        output.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
    output.extend(f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode("ascii"))
    return bytes(output)


class PlagiarismAnalyzerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def write(self, filename: str, contents: bytes) -> dict:
        path = self.root / filename
        path.write_bytes(contents)
        return {"submissionId": filename, "studentId": filename, "fileName": filename, "path": str(path)}

    def test_identical_documents_are_near_one_hundred_percent(self):
        text = b"A careful study plan uses focused practice, spaced review, and clear notes for each topic."
        result = analyze({"uploadRoot": str(self.root), "documents": [self.write("a.txt", text), self.write("b.txt", text)]})
        self.assertEqual(len(result["comparisons"]), 1)
        self.assertGreaterEqual(result["comparisons"][0]["percentage"], 99)

    def test_different_documents_have_lower_similarity(self):
        first = b"Algebra studies equations variables polynomials matrices and mathematical proofs."
        second = b"Volcanic geology examines magma eruptions lava tectonic movement and mineral deposits."
        result = analyze({"uploadRoot": str(self.root), "documents": [self.write("a.txt", first), self.write("b.txt", second)]})
        self.assertLess(result["comparisons"][0]["percentage"], 50)

    def test_documents_from_same_student_are_not_compared(self):
        first = self.write("a.txt", b"Shared text about a specific research topic.")
        second = self.write("b.txt", b"Shared text about a specific research topic.")
        second["studentId"] = first["studentId"]
        result = analyze({"uploadRoot": str(self.root), "documents": [first, second]})
        self.assertEqual(result["comparisons"], [])

    def test_docx_extraction(self):
        path = self.root / "essay.docx"
        document = Document()
        document.add_paragraph("Docx text extraction is available.")
        document.save(path)
        result = extract_document({"submissionId": "docx", "fileName": path.name, "path": str(path)}, self.root)
        self.assertEqual(result["status"], "ANALYZED")
        self.assertIn("Docx text extraction", result["text"])

    def test_text_based_pdf_extraction(self):
        path = self.root / "essay.pdf"
        path.write_bytes(make_text_pdf("PDF text extraction is available."))
        result = extract_document({"submissionId": "pdf", "fileName": path.name, "path": str(path)}, self.root)
        self.assertEqual(result["status"], "ANALYZED")
        self.assertIn("PDF text extraction", result["text"])

    def test_empty_corrupt_encrypted_and_unsupported_files_report_status(self):
        empty = self.write("empty.txt", b"")
        corrupt = self.write("corrupt.docx", b"not a docx archive")
        image = self.write("scan.png", b"not an image"); image["fileName"] = "scan.png"
        legacy = self.write("legacy.doc", b"legacy Word format"); legacy["fileName"] = "legacy.doc"
        blank_pdf_path = self.root / "blank.pdf"
        blank_pdf_path.write_bytes(make_text_pdf(""))
        blank_pdf = {"submissionId": "blank-pdf", "fileName": blank_pdf_path.name, "path": str(blank_pdf_path)}
        encrypted_path = self.root / "encrypted.pdf"
        writer = PdfWriter()
        writer.add_page(PdfReader(io.BytesIO(make_text_pdf("secret"))).pages[0])
        writer.encrypt("test-password")
        with encrypted_path.open("wb") as output:
            writer.write(output)
        encrypted = {"submissionId": "encrypted", "fileName": encrypted_path.name, "path": str(encrypted_path)}
        self.assertEqual(extract_document(empty, self.root)["status"], "NO_EXTRACTABLE_TEXT")
        self.assertEqual(extract_document(corrupt, self.root)["status"], "CORRUPT_FILE")
        self.assertEqual(extract_document(image, self.root)["status"], "UNSUPPORTED_FORMAT")
        self.assertEqual(extract_document(legacy, self.root)["status"], "UNSUPPORTED_FORMAT")
        self.assertEqual(extract_document(blank_pdf, self.root)["status"], "NO_EXTRACTABLE_TEXT")
        self.assertEqual(extract_document(encrypted, self.root)["status"], "PASSWORD_PROTECTED")


if __name__ == "__main__":
    unittest.main()
