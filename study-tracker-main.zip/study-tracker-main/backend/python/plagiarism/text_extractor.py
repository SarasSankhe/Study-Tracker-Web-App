"""Extract supported text submission formats without exposing storage paths."""

from pathlib import Path
import re


SUPPORTED_EXTENSIONS = {".txt", ".pdf", ".docx"}


def _clean_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[\t\f\v ]+", " ", text)
    text = re.sub(r"\r\n?", "\n", text)
    return text.strip()


def extract_document(document: dict, upload_root: Path) -> dict:
    """Return an extraction result for one upload; never raise for file errors."""
    submission_id = str(document.get("submissionId", ""))
    filename = str(document.get("fileName", ""))
    extension = Path(filename).suffix.lower()
    base = upload_root.resolve()
    candidate = Path(str(document.get("path", ""))).resolve()

    result = {"submissionId": submission_id, "status": "", "reason": None, "text": ""}
    if extension not in SUPPORTED_EXTENSIONS:
        result.update(status="UNSUPPORTED_FORMAT", reason=f".{extension.lstrip('.') or 'unknown'} files are not supported for text extraction; images are not OCR-scanned.")
        return result
    if candidate == base or base not in candidate.parents:
        result.update(status="INVALID_FILE", reason="Stored file is outside the configured upload directory.")
        return result
    if not candidate.is_file():
        result.update(status="FILE_MISSING", reason="The stored submission file is missing.")
        return result

    try:
        if extension == ".txt":
            raw = candidate.read_bytes()
            try:
                text = raw.decode("utf-8-sig")
            except UnicodeDecodeError:
                text = raw.decode("cp1252")
        elif extension == ".docx":
            from docx import Document

            doc = Document(str(candidate))
            parts = [paragraph.text for paragraph in doc.paragraphs]
            for table in doc.tables:
                for row in table.rows:
                    parts.append(" ".join(cell.text for cell in row.cells))
            text = "\n".join(parts)
        else:
            from pypdf import PdfReader

            reader = PdfReader(str(candidate), strict=False)
            if reader.is_encrypted:
                result.update(status="PASSWORD_PROTECTED", reason="Password-protected PDFs cannot be analyzed.")
                return result
            text = "\n".join(page.extract_text() or "" for page in reader.pages)
    except Exception as error:  # file-specific issues should not abort the whole assignment
        result.update(status="CORRUPT_FILE", reason=f"Could not extract text ({type(error).__name__}).")
        return result

    text = _clean_text(text)
    if not text:
        result.update(status="NO_EXTRACTABLE_TEXT", reason="The document is empty or contains no extractable text.")
        return result
    result.update(status="ANALYZED", text=text)
    return result
