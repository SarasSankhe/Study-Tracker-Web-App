CREATE TABLE "SimilarityAnalysis" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "assignmentId" TEXT NOT NULL,
  "analyzedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "eligibleSubmissionCount" INTEGER NOT NULL DEFAULT 0,
  "excludedSubmissions" TEXT NOT NULL DEFAULT '[]',
  CONSTRAINT "SimilarityAnalysis_assignmentId_fkey" FOREIGN KEY ("assignmentId") REFERENCES "Assignment" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

ALTER TABLE "SimilarityResult" ADD COLUMN "analysisId" TEXT REFERENCES "SimilarityAnalysis" ("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "SimilarityResult" ADD COLUMN "firstSubmissionId" TEXT REFERENCES "Submission" ("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "SimilarityResult" ADD COLUMN "secondSubmissionId" TEXT REFERENCES "Submission" ("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "SimilarityResult" ADD COLUMN "sharedTerms" TEXT NOT NULL DEFAULT '[]';

CREATE UNIQUE INDEX "SimilarityResult_assignmentId_firstSubmissionId_secondSubmissionId_key"
ON "SimilarityResult"("assignmentId", "firstSubmissionId", "secondSubmissionId");
CREATE INDEX "SimilarityResult_analysisId_percentage_idx" ON "SimilarityResult"("analysisId", "percentage");
CREATE INDEX "SimilarityAnalysis_assignmentId_analyzedAt_idx" ON "SimilarityAnalysis"("assignmentId", "analyzedAt");

