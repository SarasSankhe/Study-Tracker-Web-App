-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Assignment" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "title" TEXT NOT NULL,
    "subject" TEXT NOT NULL DEFAULT 'General',
    "description" TEXT NOT NULL DEFAULT '',
    "instructions" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "dueAt" DATETIME,
    "published" BOOLEAN NOT NULL DEFAULT false,
    "teacherId" TEXT NOT NULL,
    CONSTRAINT "Assignment_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_Assignment" ("createdAt", "description", "dueAt", "id", "instructions", "published", "teacherId", "title") SELECT "createdAt", "description", "dueAt", "id", "instructions", "published", "teacherId", "title" FROM "Assignment";
DROP TABLE "Assignment";
ALTER TABLE "new_Assignment" RENAME TO "Assignment";
CREATE INDEX "Assignment_teacherId_published_idx" ON "Assignment"("teacherId", "published");
CREATE INDEX "Assignment_dueAt_idx" ON "Assignment"("dueAt");
CREATE TABLE "new_Grade" (
    "submissionId" TEXT NOT NULL PRIMARY KEY,
    "marks" REAL,
    "feedback" TEXT NOT NULL DEFAULT '',
    "teacherId" TEXT NOT NULL,
    "evaluatedAt" DATETIME NOT NULL,
    CONSTRAINT "Grade_submissionId_fkey" FOREIGN KEY ("submissionId") REFERENCES "Submission" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Grade_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_Grade" ("evaluatedAt", "feedback", "marks", "submissionId", "teacherId") SELECT "evaluatedAt", "feedback", "marks", "submissionId", "teacherId" FROM "Grade";
DROP TABLE "Grade";
ALTER TABLE "new_Grade" RENAME TO "Grade";
CREATE TABLE "new_StudyTask" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL DEFAULT '',
    "category" TEXT NOT NULL DEFAULT 'Study',
    "priority" TEXT NOT NULL DEFAULT 'medium',
    "scheduledTime" TEXT NOT NULL DEFAULT '',
    "durationMinutes" INTEGER NOT NULL DEFAULT 60,
    "notes" TEXT NOT NULL DEFAULT '',
    "createdById" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "deadline" DATETIME,
    CONSTRAINT "StudyTask_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_StudyTask" ("createdAt", "createdById", "deadline", "description", "id", "title", "type") SELECT "createdAt", "createdById", "deadline", "description", "id", "title", "type" FROM "StudyTask";
DROP TABLE "StudyTask";
ALTER TABLE "new_StudyTask" RENAME TO "StudyTask";
CREATE INDEX "StudyTask_createdById_type_idx" ON "StudyTask"("createdById", "type");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
