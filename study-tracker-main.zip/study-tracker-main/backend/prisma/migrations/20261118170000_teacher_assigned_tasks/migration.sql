ALTER TABLE "StudyTask" ADD COLUMN "published" BOOLEAN NOT NULL DEFAULT true;

ALTER TABLE "StudyTaskAssignment" ADD COLUMN "status" TEXT NOT NULL DEFAULT 'NOT_STARTED';
ALTER TABLE "StudyTaskAssignment" ADD COLUMN "startedAt" DATETIME;

UPDATE "StudyTaskAssignment"
SET "status" = CASE
  WHEN "completed" = 1 THEN 'COMPLETED'
  WHEN EXISTS (
    SELECT 1 FROM "StudyTimeSession" s
    WHERE s."taskId" = "StudyTaskAssignment"."taskId"
      AND s."studentId" = "StudyTaskAssignment"."studentId"
      AND s."endedAt" IS NULL
  ) THEN 'RUNNING'
  WHEN EXISTS (
    SELECT 1 FROM "StudyTimeSession" s
    WHERE s."taskId" = "StudyTaskAssignment"."taskId"
      AND s."studentId" = "StudyTaskAssignment"."studentId"
  ) THEN 'PAUSED'
  ELSE 'NOT_STARTED'
END;

UPDATE "StudyTaskAssignment"
SET "startedAt" = (
  SELECT MIN(s."startedAt") FROM "StudyTimeSession" s
  WHERE s."taskId" = "StudyTaskAssignment"."taskId"
    AND s."studentId" = "StudyTaskAssignment"."studentId"
);

CREATE TABLE "new_StudyTimeSession" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "studentId" TEXT NOT NULL,
  "taskId" TEXT,
  "taskAssignmentTaskId" TEXT,
  "taskAssignmentStudentId" TEXT,
  "startedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "heartbeatAt" DATETIME,
  "pausedAt" DATETIME,
  "endedAt" DATETIME,
  "duration" INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT "StudyTimeSession_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "StudyTimeSession_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES "StudyTask" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT "StudyTimeSession_assignment_fkey" FOREIGN KEY ("taskAssignmentTaskId", "taskAssignmentStudentId") REFERENCES "StudyTaskAssignment" ("taskId", "studentId") ON DELETE CASCADE ON UPDATE CASCADE
);

INSERT INTO "new_StudyTimeSession" (
  "id", "studentId", "taskId", "taskAssignmentTaskId", "taskAssignmentStudentId",
  "startedAt", "heartbeatAt", "pausedAt", "endedAt", "duration"
)
SELECT s."id", s."studentId", s."taskId",
  CASE WHEN t."type" = 'TEACHER_ASSIGNED' AND a."taskId" IS NOT NULL THEN s."taskId" ELSE NULL END,
  CASE WHEN t."type" = 'TEACHER_ASSIGNED' AND a."taskId" IS NOT NULL THEN s."studentId" ELSE NULL END,
  s."startedAt",
  CASE WHEN s."endedAt" IS NULL AND t."type" = 'TEACHER_ASSIGNED' AND a."taskId" IS NOT NULL THEN s."startedAt" ELSE NULL END,
  s."pausedAt", s."endedAt", s."duration"
FROM "StudyTimeSession" s
LEFT JOIN "StudyTask" t ON t."id" = s."taskId"
LEFT JOIN "StudyTaskAssignment" a ON a."taskId" = s."taskId" AND a."studentId" = s."studentId";

DROP TABLE "StudyTimeSession";
ALTER TABLE "new_StudyTimeSession" RENAME TO "StudyTimeSession";

CREATE INDEX "StudyTimeSession_studentId_startedAt_idx" ON "StudyTimeSession"("studentId", "startedAt");
CREATE INDEX "StudyTimeSession_taskAssignmentTaskId_taskAssignmentStudentId_idx" ON "StudyTimeSession"("taskAssignmentTaskId", "taskAssignmentStudentId");
