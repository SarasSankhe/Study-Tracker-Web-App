# Existing browser data

The current browser keys are `sf_academy_data` (academy assignments, submissions and student records), `sf_session` (the old demo login session), `sf_state` (legacy tracker state), and `sf_state_<encoded-student-id>` (per-student tracker state). Stage 3 now uses the API as the source for accounts, assignments, submissions, grades, personal tasks and timer sessions. The existing browser keys are left untouched. On first sign-in, personal tasks and timer sessions are imported only when the old `sf_session` email matches the new backend account email; this avoids moving one student's private data into another student's account.

Old `sf_academy_data` assignments, submissions, marks, student identities, and the unscoped legacy `sf_state` key are not imported automatically. Those demo identities have no passwords and need reviewed email/ID mapping before they can be safely connected to backend users. The old records remain available in LocalStorage for a later migration; do not clear them as part of this integration.

For a future shared-data import, export `sf_academy_data` as JSON, map identities to unique normalized emails, preserve original IDs in a separately reviewed mapping, then import assignments, recipients, submissions and grades in dependency order. Validate row counts and ownership before retiring any browser data. Never clear LocalStorage as part of an import.

Uploaded files are stored separately under `backend/uploads`; they are served only through the authenticated submission download endpoint. This backend intentionally has no similarity-analysis implementation.
