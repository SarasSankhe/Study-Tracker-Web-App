const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });
const { PrismaClient } = require('@prisma/client');
const base = process.env.API_URL || 'http://localhost:3000';
const stamp = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
const prisma = new PrismaClient();
const createdUserIds = new Set();
const createdSessionCookies = new Set();

async function request(path, { cookie, method = 'GET', json, form } = {}) {
  const headers = {};
  if (cookie) headers.cookie = cookie;
  if (json) headers['content-type'] = 'application/json';
  const response = await fetch(`${base}${path}`, { method, headers, body: form || (json ? JSON.stringify(json) : undefined) });
  const setCookie = response.headers.get('set-cookie');
  const nextCookie = setCookie ? setCookie.split(';')[0] : cookie;
  const type = response.headers.get('content-type') || '';
  const body = type.includes('application/json') ? await response.json() : await response.text();
  return { response, body, cookie: nextCookie };
}

async function register(role, index) {
  const { response, body, cookie } = await request('/api/auth/register', { method: 'POST', json: {
    name: `${role} ${index} ${stamp}`, email: `${role}-${index}-${stamp}@example.test`, password: 'StageThreePass123!', role
  } });
  assert.equal(response.status, 201, JSON.stringify(body));
  assert(!Object.hasOwn(body.user, 'passwordHash'));
  createdUserIds.add(body.user.id);
  if (cookie) createdSessionCookies.add(cookie);
  return { cookie, user: body.user };
}

async function cleanup() {
  try {
    for (const cookie of createdSessionCookies) {
      try {
        await request('/api/auth/logout', { cookie, method: 'POST' });
      } catch (error) {
        console.error('Failed to end an integration-test login session:', error.message);
        process.exitCode = 1;
      }
    }

    if (createdUserIds.size) {
      const userIds = [...createdUserIds];
      const submissions = await prisma.submission.findMany({
        where: { studentId: { in: userIds } },
        select: { storedName: true }
      });
      await prisma.$transaction(tx => tx.user.deleteMany({ where: { id: { in: userIds } } }));

      const uploadsDir = path.resolve(process.env.UPLOAD_DIR || path.resolve(__dirname, '..', 'uploads'));
      for (const { storedName } of submissions) {
        if (!storedName || path.basename(storedName) !== storedName) continue;
        const filePath = path.resolve(uploadsDir, storedName);
        if (filePath.startsWith(`${uploadsDir}${path.sep}`)) {
          await fs.rm(filePath, { force: true });
        }
      }
    }
  } catch (error) {
    console.error('Failed to clean integration-test records:', error);
    process.exitCode = 1;
  } finally {
    await prisma.$disconnect();
  }
}

(async () => {
  let result = await request('/api/health');
  assert.equal(result.response.status, 200);
  assert.equal(result.body.status, 'ok');

  const teacher = await register('TEACHER', 0);
  const studentA = await register('STUDENT', 1);
  const studentB = await register('STUDENT', 2);

  // Verify login works independently of the registration session.
  result = await request('/api/auth/login', { method: 'POST', json: { email: teacher.user.email, password: 'StageThreePass123!', role: 'TEACHER' } });
  assert.equal(result.response.status, 200);
  const teacherCookie = result.cookie;
  if (teacherCookie) createdSessionCookies.add(teacherCookie);
  for (const [account, role] of [[studentA, 'STUDENT'], [studentB, 'STUDENT']]) {
    const login = await request('/api/auth/login', { method: 'POST', json: { email: account.user.email, password: 'StageThreePass123!', role } });
    assert.equal(login.response.status, 200);
    account.cookie = login.cookie;
    if (login.cookie) createdSessionCookies.add(login.cookie);
  }
  result = await request('/api/students', { cookie: teacherCookie });
  assert.equal(result.response.status, 200);
  assert([studentA.user.id, studentB.user.id].every(id => result.body.some(student => student.id === id)));

  result = await request('/api/students', { cookie: studentA.cookie });
  assert.equal(result.response.status, 403, 'students must not access teacher student directory');
  result = await request('/api/tasks', { cookie: teacherCookie, method: 'POST', json: { title: 'wrong role', type: 'PERSONAL' } });
  assert.equal(result.response.status, 403, 'teachers must not create personal student tasks');

  const assignment = await request('/api/assignments', { cookie: teacherCookie, method: 'POST', json: {
    title: `Integration assignment ${stamp}`, subject: 'Math', description: 'Smoke test', instructions: 'Submit a text file',
    dueAt: new Date(Date.now() + 86400000).toISOString(), published: false, studentIds: [studentA.user.id, studentB.user.id]
  } });
  assert.equal(assignment.response.status, 201, JSON.stringify(assignment.body));
  for (const student of [studentA, studentB]) {
    const list = await request('/api/assignments', { cookie: student.cookie });
    assert(!list.body.some(item => item.id === assignment.body.id), 'draft assignment must remain hidden');
  }
  result = await request(`/api/assignments/${assignment.body.id}`, { cookie: teacherCookie, method: 'PATCH', json: { subject: 'Algebra II' } });
  assert.equal(result.response.status, 200);
  result = await request(`/api/assignments/${assignment.body.id}/recipients`, { cookie: teacherCookie, method: 'PUT', json: { studentIds: [studentA.user.id, studentB.user.id] } });
  assert.equal(result.response.status, 200);
  const removable = await request('/api/assignments', { cookie: teacherCookie, method: 'POST', json: { title: `Delete check ${stamp}`, subject: 'Test', studentIds: [studentA.user.id] } });
  assert.equal(removable.response.status, 201);
  result = await request(`/api/assignments/${removable.body.id}`, { cookie: teacherCookie, method: 'DELETE' });
  assert.equal(result.response.status, 204);
  result = await request(`/api/assignments/${assignment.body.id}/publish`, { cookie: teacherCookie, method: 'POST' });
  assert.equal(result.response.status, 200);
  for (const student of [studentA, studentB]) {
    const list = await request('/api/assignments', { cookie: student.cookie });
    assert(list.body.some(item => item.id === assignment.body.id), 'published assignment should be visible to both recipients');
  }
  const tooLarge = new FormData();
  tooLarge.append('file', new Blob([new Uint8Array(900 * 1024 + 1)], { type: 'text/plain' }), 'too-large.txt');
  result = await request(`/api/assignments/${assignment.body.id}/submissions`, { cookie: studentA.cookie, method: 'POST', form: tooLarge });
  assert.equal(result.response.status, 400, 'server must enforce the existing 900 KB upload limit');

  const submitted = [];
  for (const [student, filename, contents] of [[studentA, 'a.txt', 'submission one'], [studentB, 'b.txt', 'submission two']]) {
    const form = new FormData();
    form.append('file', new Blob([contents], { type: 'text/plain' }), filename);
    const submission = await request(`/api/assignments/${assignment.body.id}/submissions`, { cookie: student.cookie, method: 'POST', form });
    assert.equal(submission.response.status, 201, JSON.stringify(submission.body));
    submitted.push(submission.body);
  }
  const replacement = new FormData(); replacement.append('file', new Blob(['replacement submission'], { type: 'text/plain' }), 'replacement.txt');
  result = await request(`/api/assignments/${assignment.body.id}/submissions`, { cookie: studentA.cookie, method: 'POST', form: replacement });
  assert.equal(result.response.status, 200, 'resubmission should replace the existing upload');

  const queue = await request('/api/submissions', { cookie: teacherCookie });
  const matching = queue.body.filter(item => item.assignmentId === assignment.body.id);
  assert.equal(matching.length, 2);
  assert.notEqual(matching[0].id, matching[1].id);
  assert.notEqual(matching[0].studentId, matching[1].studentId);
  assert.notEqual(matching[0].storedName, matching[1].storedName);
  const downloaded = await request(`/api/submissions/${submitted[0].id}/download`, { cookie: teacherCookie });
  assert.equal(downloaded.response.status, 200);
  assert.match(downloaded.body, /replacement submission/);

  for (const [i, student] of [studentA, studentB].entries()) {
    const submission = submitted[i];
    const grade = await request(`/api/submissions/${submission.id}/grade`, { cookie: teacherCookie, method: 'PUT', json: { marks: 80 + i, feedback: `Private feedback ${i + 1}` } });
    assert.equal(grade.response.status, 200);
    const review = await request(`/api/submissions/${submission.id}/review-status`, { cookie: teacherCookie, method: 'PATCH', json: { reviewStatus: 'IN_REVIEW' } });
    assert.equal(review.response.status, 200);
    const feedback = await request(`/api/submissions/${submission.id}/feedback`, { cookie: student.cookie });
    assert.equal(feedback.response.status, 200);
    assert.equal(feedback.body.grade.feedback, `Private feedback ${i + 1}`);
    const own = await request('/api/submissions', { cookie: student.cookie });
    assert(own.body.every(item => item.studentId === student.user.id), 'student submission list must only include own records');
  }
  result = await request(`/api/submissions/${submitted[0].id}/feedback`, { cookie: studentB.cookie });
  assert.equal(result.response.status, 403, 'students must not read another student feedback');

  const allStudyTask = await request('/api/study-tasks', { cookie: teacherCookie, method: 'POST', json: {
    title: `All students study task ${stamp}`, description: 'Teacher-assigned work', audience: 'ALL', studentIds: [], durationMinutes: 45,
    dueAt: new Date(Date.now() + 86400000).toISOString(), published: true
  } });
  assert.equal(allStudyTask.response.status, 201, JSON.stringify(allStudyTask.body));
  const selectedStudyTask = await request('/api/study-tasks', { cookie: teacherCookie, method: 'POST', json: {
    title: `Selected study task ${stamp}`, description: 'Assigned to Student A only', audience: 'SELECTED', studentIds: [studentA.user.id], published: true
  } });
  assert.equal(selectedStudyTask.response.status, 201, JSON.stringify(selectedStudyTask.body));
  const draftStudyTask = await request('/api/study-tasks', { cookie: teacherCookie, method: 'POST', json: {
    title: `Draft study task ${stamp}`, audience: 'SELECTED', studentIds: [studentA.user.id], published: false
  } });
  assert.equal(draftStudyTask.response.status, 201);
  let studyTasksA = await request('/api/study-tasks', { cookie: studentA.cookie });
  let studyTasksB = await request('/api/study-tasks', { cookie: studentB.cookie });
  assert(studyTasksA.body.some(row => row.taskId === allStudyTask.body.id) && studyTasksB.body.some(row => row.taskId === allStudyTask.body.id), 'all-student task is assigned to both students');
  assert(studyTasksA.body.some(row => row.taskId === selectedStudyTask.body.id) && !studyTasksB.body.some(row => row.taskId === selectedStudyTask.body.id), 'selected task is visible only to its intended student');
  assert(!studyTasksA.body.some(row => row.taskId === draftStudyTask.body.id), 'draft teacher tasks remain hidden');
  const otherTeacher = await register('TEACHER', 3);
  const otherTeacherTasks = await request('/api/study-tasks', { cookie: otherTeacher.cookie });
  assert.equal(otherTeacherTasks.response.status, 200);
  assert.equal(otherTeacherTasks.body.length, 0, 'teachers only see tasks they own');
  result = await request(`/api/study-tasks/${allStudyTask.body.id}`, { cookie: otherTeacher.cookie, method: 'PATCH', json: { title: 'Unauthorized edit' } });
  assert.equal(result.response.status, 404, 'teachers cannot edit another teacher task');
  result = await request(`/api/study-tasks/${allStudyTask.body.id}`, { cookie: otherTeacher.cookie, method: 'DELETE' });
  assert.equal(result.response.status, 404, 'teachers cannot delete another teacher task');
  result = await request(`/api/study-tasks/${selectedStudyTask.body.id}`, { cookie: teacherCookie, method: 'PATCH', json: { title: `Edited selected task ${stamp}`, audience: 'SELECTED', studentIds: [studentA.user.id, studentA.user.id], durationMinutes: 30 } });
  assert.equal(result.response.status, 200, 'teacher can edit task metadata and recipients');
  assert.equal(result.body.assignments.length, 1, 'duplicate student ids do not create duplicate task copies');
  const disposableTask = await request('/api/study-tasks', { cookie: teacherCookie, method: 'POST', json: { title: `Delete study task ${stamp}`, audience: 'SELECTED', studentIds: [studentA.user.id] } });
  assert.equal(disposableTask.response.status, 201);
  result = await request(`/api/study-tasks/${disposableTask.body.id}`, { cookie: teacherCookie, method: 'DELETE' });
  assert.equal(result.response.status, 204, 'teacher can delete an owned study task');
  result = await request(`/api/study-tasks/${allStudyTask.body.id}/start`, { cookie: studentB.cookie, method: 'POST' });
  assert.equal(result.response.status, 200);
  await prisma.studyTimeSession.updateMany({
    where: { taskAssignmentTaskId: allStudyTask.body.id, taskAssignmentStudentId: studentB.user.id, endedAt: null },
    data: { startedAt: new Date(Date.now() - 70000), heartbeatAt: new Date(Date.now() - 60000) }
  });
  studyTasksB = await request('/api/study-tasks', { cookie: studentB.cookie });
  const recoveredTimer = studyTasksB.body.find(row => row.taskId === allStudyTask.body.id);
  assert.equal(recoveredTimer.status, 'PAUSED', 'stale running timer is safely paused after an interrupted client');
  assert.equal(recoveredTimer.sessions[0].duration, 10, 'interrupted session is capped at its last server heartbeat');
  result = await request(`/api/study-tasks/${allStudyTask.body.id}`, { cookie: teacherCookie, method: 'PATCH', json: { audience: 'SELECTED', studentIds: [studentA.user.id] } });
  assert.equal(result.response.status, 409, 'recipients with recorded task time cannot be removed');
  result = await request(`/api/study-tasks/${selectedStudyTask.body.id}/publish`, { cookie: teacherCookie, method: 'POST' });
  assert.equal(result.response.status, 200);
  result = await request(`/api/study-tasks/${selectedStudyTask.body.id}/start`, { cookie: studentB.cookie, method: 'POST' });
  assert.equal(result.response.status, 404, 'unassigned students cannot start a teacher task');
  result = await request(`/api/tasks/${selectedStudyTask.body.id}/status`, { cookie: studentA.cookie, method: 'PATCH', json: { completed: true } });
  assert.equal(result.response.status, 404, 'personal task status API cannot complete teacher tasks');
  result = await request('/api/study-sessions', { cookie: studentA.cookie, method: 'POST', json: { taskId: selectedStudyTask.body.id, duration: 3600 } });
  assert.equal(result.response.status, 403, 'client-supplied time cannot be added to teacher tasks');

  let timer = await request(`/api/study-tasks/${selectedStudyTask.body.id}/start`, { cookie: studentA.cookie, method: 'POST', json: { duration: 999999 } });
  assert.equal(timer.response.status, 200);
  assert.equal(timer.body.status, 'RUNNING');
  studyTasksA = await request('/api/study-tasks', { cookie: studentA.cookie });
  assert.equal(studyTasksA.body.find(row => row.taskId === selectedStudyTask.body.id).status, 'RUNNING', 'refresh reads persisted running timer state');
  result = await request(`/api/study-tasks/${selectedStudyTask.body.id}/start`, { cookie: studentA.cookie, method: 'POST' });
  assert.equal(result.response.status, 409, 'duplicate start does not create another running session');
  await new Promise(resolve => setTimeout(resolve, 1100));
  timer = await request(`/api/study-tasks/${selectedStudyTask.body.id}/pause`, { cookie: studentA.cookie, method: 'POST' });
  assert.equal(timer.response.status, 200);
  assert.equal(timer.body.status, 'PAUSED');
  assert(timer.body.sessions[0].duration >= 1, 'pause records elapsed server time');
  timer = await request(`/api/study-tasks/${selectedStudyTask.body.id}/resume`, { cookie: studentA.cookie, method: 'POST' });
  assert.equal(timer.response.status, 200);
  await new Promise(resolve => setTimeout(resolve, 1100));
  result = await request(`/api/study-tasks/${selectedStudyTask.body.id}/heartbeat`, { cookie: studentA.cookie, method: 'POST', json: { heartbeatAt: '2000-01-01T00:00:00.000Z' } });
  assert.equal(result.response.status, 200);
  assert(Date.now() - new Date(result.body.heartbeatAt).getTime() < 5000, 'heartbeat timestamp is generated by the server');
  timer = await request(`/api/study-tasks/${selectedStudyTask.body.id}/complete`, { cookie: studentA.cookie, method: 'POST' });
  assert.equal(timer.response.status, 200);
  assert.equal(timer.body.status, 'COMPLETED');
  assert(timer.body.totalSeconds >= 2 && timer.body.sessions.length === 2, 'resume creates a second saved session and accumulates time');
  const monitor = await request('/api/study-tasks', { cookie: teacherCookie });
  const monitoredTask = monitor.body.find(task => task.id === selectedStudyTask.body.id);
  assert(monitoredTask && monitoredTask.assignments[0].status === 'COMPLETED' && monitoredTask.assignments[0].totalSeconds >= 2, 'teacher sees completed status and recorded time');
  const inspected = await request(`/api/study-tasks/${selectedStudyTask.body.id}/students/${studentA.user.id}/sessions`, { cookie: teacherCookie });
  assert.equal(inspected.response.status, 200);
  assert.equal(inspected.body.sessions.length, 2);
  assert(inspected.body.sessions.every(row => row.taskAssignmentTaskId === selectedStudyTask.body.id && row.taskAssignmentStudentId === studentA.user.id));
  const forbiddenInspect = await request(`/api/study-tasks/${selectedStudyTask.body.id}/students/${studentA.user.id}/sessions`, { cookie: studentB.cookie });
  assert.equal(forbiddenInspect.response.status, 403, 'students cannot inspect another student timer records');

  const personalA = await request('/api/tasks', { cookie: studentA.cookie, method: 'POST', json: { title: `Private task A ${stamp}`, type: 'PERSONAL' } });
  const personalB = await request('/api/tasks', { cookie: studentB.cookie, method: 'POST', json: { title: `Private task B ${stamp}`, type: 'PERSONAL' } });
  assert.equal(personalA.response.status, 201);
  assert.equal(personalB.response.status, 201);
  const tasksA = await request('/api/tasks?type=PERSONAL', { cookie: studentA.cookie });
  const tasksB = await request('/api/tasks?type=PERSONAL', { cookie: studentB.cookie });
  assert(tasksA.body.some(row => row.task.id === personalA.body.id));
  assert(!tasksA.body.some(row => row.task.id === personalB.body.id));
  assert(tasksB.body.some(row => row.task.id === personalB.body.id));
  assert(!tasksB.body.some(row => row.task.id === personalA.body.id));
  result = await request(`/api/tasks/${personalA.body.id}`, { cookie: studentA.cookie, method: 'PATCH', json: { title: `Updated private task ${stamp}` } });
  assert.equal(result.response.status, 200);
  result = await request(`/api/tasks/${personalB.body.id}`, { cookie: studentA.cookie, method: 'DELETE' });
  assert.equal(result.response.status, 404, 'a student must not edit another student task');
  result = await request(`/api/tasks/${personalA.body.id}/status`, { cookie: studentA.cookie, method: 'PATCH', json: { completed: true } });
  assert.equal(result.response.status, 200);
  const completedTasks = await request('/api/tasks?type=PERSONAL', { cookie: studentA.cookie });
  assert(completedTasks.body.find(row => row.task.id === personalA.body.id).completed);

  for (const [student, task] of [[studentA, personalA.body], [studentB, personalB.body]]) {
    const session = await request('/api/study-sessions', { cookie: student.cookie, method: 'POST', json: { taskId: task.id, duration: 25, endedAt: new Date().toISOString() } });
    assert.equal(session.response.status, 201, JSON.stringify(session.body));
  }
  const sessionsA = await request('/api/study-sessions', { cookie: studentA.cookie });
  const sessionsB = await request('/api/study-sessions', { cookie: studentB.cookie });
  assert(sessionsA.body.every(row => row.studentId === studentA.user.id));
  assert(sessionsB.body.every(row => row.studentId === studentB.user.id));
  assert(sessionsA.body.every(row => row.task?.type === 'PERSONAL'), 'personal timer history excludes teacher-assigned sessions');
  result = await request(`/api/analytics/progress/${studentA.user.id}`, { cookie: teacherCookie });
  assert.equal(result.response.status, 200);
  assert(result.body.studySeconds >= 2 && result.body.studySeconds < 25, 'teacher analytics exclude private personal timer time');
  result = await request('/api/personal-tasks', { cookie: studentA.cookie, method: 'DELETE' });
  assert.equal(result.response.status, 200);
  result = await request('/api/study-sessions', { cookie: studentA.cookie, method: 'DELETE' });
  assert.equal(result.response.status, 200);
  assert.equal((await request('/api/tasks?type=PERSONAL', { cookie: studentA.cookie })).body.length, 0);
  assert.equal((await request('/api/study-sessions', { cookie: studentA.cookie })).body.length, 0);
  studyTasksA = await request('/api/study-tasks', { cookie: studentA.cookie });
  assert.equal(studyTasksA.body.find(row => row.taskId === selectedStudyTask.body.id).status, 'COMPLETED', 'personal cleanup preserves teacher-task progress');

  const page = await request('/');
  assert.equal(page.response.status, 200);
  assert.match(page.body, /role-app\.js/);

  console.log('PASS Stage 3 assignment/submission workflows and Stage 4 task distribution, publication, server timers, resume, privacy, monitoring and personal-task isolation');
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(cleanup);
