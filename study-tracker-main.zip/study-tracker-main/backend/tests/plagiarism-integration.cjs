const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const base = process.env.API_URL || 'http://localhost:3000';
const stamp = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
const userIds = new Set();
const cookies = new Set();

async function request(route, { cookie, method = 'GET', json, file } = {}) {
  const headers = cookie ? { cookie } : {};
  let body;
  if (file) { body = new FormData(); body.append('file', new Blob([file.contents], { type: file.type }), file.name); }
  else if (json) { headers['content-type'] = 'application/json'; body = JSON.stringify(json); }
  const response = await fetch(`${base}${route}`, { method, headers, body });
  const setCookie = response.headers.get('set-cookie');
  const nextCookie = setCookie ? setCookie.split(';')[0] : cookie;
  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json() : await response.text();
  return { response, data, cookie: nextCookie };
}

async function register(role, index) {
  const result = await request('/api/auth/register', { method: 'POST', json: {
    name: `Plagiarism ${role} ${index} ${stamp}`, email: `plag-${role}-${index}-${stamp}@example.test`, password: 'PlagiarismTest123!', role
  } });
  assert.equal(result.response.status, 201, JSON.stringify(result.data));
  userIds.add(result.data.user.id);
  if (result.cookie) cookies.add(result.cookie);
  return { user: result.data.user, cookie: result.cookie };
}

async function submit(assignmentId, student, name, contents, type = 'text/plain') {
  const result = await request(`/api/assignments/${assignmentId}/submissions`, { cookie: student.cookie, method: 'POST', file: { name, contents, type } });
  assert([200, 201].includes(result.response.status), JSON.stringify(result.data));
  return result.data;
}

async function cleanup() {
  try {
    for (const cookie of cookies) await request('/api/auth/logout', { cookie, method: 'POST' }).catch(() => {});
    if (userIds.size) {
      const ids = [...userIds];
      const rows = await prisma.submission.findMany({ where: { studentId: { in: ids } }, select: { storedName: true } });
      await prisma.user.deleteMany({ where: { id: { in: ids } } });
      const uploads = path.resolve(process.env.UPLOAD_DIR || path.resolve(__dirname, '..', 'uploads'));
      for (const row of rows) {
        if (!row.storedName || path.basename(row.storedName) !== row.storedName) continue;
        const target = path.resolve(uploads, row.storedName);
        if (target.startsWith(`${uploads}${path.sep}`)) await fs.rm(target, { force: true });
      }
    }
  } finally { await prisma.$disconnect(); }
}

async function main() {
  const teacher = await register('TEACHER', 1);
  const otherTeacher = await register('TEACHER', 2);
  const students = [await register('STUDENT', 1), await register('STUDENT', 2), await register('STUDENT', 3)];
  const createAssignment = async title => {
    const result = await request('/api/assignments', { cookie: teacher.cookie, method: 'POST', json: {
      title: `${title} ${stamp}`, subject: 'Test', published: true, studentIds: students.map(student => student.user.id)
    } });
    assert.equal(result.response.status, 201, JSON.stringify(result.data));
    return result.data;
  };
  const firstAssignment = await createAssignment('Plagiarism comparison');
  const secondAssignment = await createAssignment('Separate assignment');
  const repeatedText = 'Focused study uses spaced practice, careful feedback, organized notes, and repeated review of the same subject.';
  await submit(firstAssignment.id, students[0], 'first-old.txt', 'Older version that must be replaced.');
  const currentFirst = await submit(firstAssignment.id, students[0], 'first.txt', repeatedText);
  const second = await submit(firstAssignment.id, students[1], 'second.txt', repeatedText);
  const third = await submit(firstAssignment.id, students[2], 'third.txt', 'Geology describes volcanic magma, igneous rocks, tectonic plates, and mineral formation beneath the ocean floor.');
  await submit(secondAssignment.id, students[0], 'other-a.txt', 'Another assignment discusses botanical taxonomy and forest ecology.');
  await submit(secondAssignment.id, students[1], 'other-b.txt', 'Another assignment discusses botanical taxonomy and forest ecology.');
  await submit(secondAssignment.id, students[2], 'scan.png', Buffer.from('not OCR analyzed'), 'image/png');

  const denied = await request(`/api/assignments/${firstAssignment.id}/plagiarism/analyze`, { cookie: students[0].cookie, method: 'POST' });
  assert.equal(denied.response.status, 403, 'students cannot initiate analyses');
  const otherTeacherDenied = await request(`/api/assignments/${firstAssignment.id}/plagiarism/analyze`, { cookie: otherTeacher.cookie, method: 'POST' });
  assert.equal(otherTeacherDenied.response.status, 404, 'a teacher cannot analyze another teacher\'s assignment');

  const firstRun = await request(`/api/assignments/${firstAssignment.id}/plagiarism/analyze`, { cookie: teacher.cookie, method: 'POST' });
  assert.equal(firstRun.response.status, 200, JSON.stringify(firstRun.data));
  assert.equal(firstRun.data.results.length, 3, 'three different students yield three unique pairs');
  const identical = firstRun.data.results.find(result => new Set([result.firstSubmission.id, result.secondSubmission.id]).has(currentFirst.id) && new Set([result.firstSubmission.id, result.secondSubmission.id]).has(second.id));
  assert(identical && identical.percentage >= 99, 'identical text yields very high similarity');
  assert(firstRun.data.results.every(result => result.firstStudent.id !== result.secondStudent.id));
  assert(firstRun.data.results.every(result => result.assignmentId === firstAssignment.id));
  assert.notEqual(currentFirst.id, second.id);
  assert.equal(await prisma.submission.count({ where: { assignmentId: firstAssignment.id } }), 3, 'resubmission replaces the student\'s current submission');
  assert.equal(await prisma.similarityAnalysis.count({ where: { id: firstRun.data.analysis.id } }), 1, 'analysis report is persisted');
  assert.equal(await prisma.similarityResult.count({ where: { analysisId: firstRun.data.analysis.id } }), 3, 'pair results are persisted in SQLite');

  const otherRun = await request(`/api/assignments/${secondAssignment.id}/plagiarism/analyze`, { cookie: teacher.cookie, method: 'POST' });
  assert.equal(otherRun.response.status, 200, JSON.stringify(otherRun.data));
  assert.equal(otherRun.data.results.length, 1, 'only the pair from the selected assignment is compared');
  assert.equal(otherRun.data.excluded.length, 1);
  assert.equal(otherRun.data.excluded[0].status, 'UNSUPPORTED_FORMAT');

  const retrieved = await request(`/api/assignments/${firstAssignment.id}/plagiarism/results`, { cookie: teacher.cookie });
  assert.equal(retrieved.response.status, 200);
  assert.equal(retrieved.data.results.length, 3);
  const detail = await request(`/api/plagiarism/results/${identical.id}`, { cookie: teacher.cookie });
  assert.equal(detail.response.status, 200, JSON.stringify(detail.data));
  assert(detail.data.firstDocument.text && detail.data.secondDocument.text);
  assert(!JSON.stringify(detail.data).includes('storedName'));
  assert(!JSON.stringify(detail.data).includes('uploads'));
  const studentRead = await request(`/api/assignments/${firstAssignment.id}/plagiarism/results`, { cookie: students[0].cookie });
  assert.equal(studentRead.response.status, 403);
  const foreignReview = await request(`/api/plagiarism/results/${identical.id}/review`, { cookie: otherTeacher.cookie, method: 'PATCH', json: { reviewStatus: 'DISMISSED' } });
  assert.equal(foreignReview.response.status, 404);
  const review = await request(`/api/plagiarism/results/${identical.id}/review`, { cookie: teacher.cookie, method: 'PATCH', json: { reviewStatus: 'REVIEWED' } });
  assert.equal(review.response.status, 200);
  assert.equal(review.data.reviewStatus, 'REVIEWED');
  const dismiss = await request(`/api/plagiarism/results/${identical.id}/review`, { cookie: teacher.cookie, method: 'PATCH', json: { reviewStatus: 'DISMISSED' } });
  assert.equal(dismiss.response.status, 200);
  assert.equal(dismiss.data.reviewStatus, 'DISMISSED');
}

main().then(async () => { await cleanup(); console.log('PASS plagiarism API, TF-IDF comparisons, assignment and student isolation, persisted results, unsupported-file reporting, details, review actions, and cleanup'); })
  .catch(async error => { console.error(error); process.exitCode = 1; await cleanup(); });
