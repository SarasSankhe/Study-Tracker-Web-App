const { spawnSync } = require('node:child_process');
const path = require('node:path');
const dotenv = require('dotenv');

const backendRoot = path.resolve(__dirname, '..');
dotenv.config({ path: path.join(backendRoot, '.env') });

const python = process.env.PLAGIARISM_PYTHON || (process.platform === 'win32' ? 'python' : 'python3');
const result = spawnSync(
  python,
  ['-m', 'unittest', 'discover', '-s', 'python/plagiarism/tests', '-v'],
  { cwd: backendRoot, stdio: 'inherit', shell: process.platform === 'win32' },
);

if (result.error) {
  console.error(`Could not start Python test runner (${python}): ${result.error.message}`);
  process.exit(1);
}

process.exit(result.status ?? 1);
