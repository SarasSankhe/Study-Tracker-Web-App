/* Study Tracker role workspace. Shared data and identity are backed by the API. */
(() => {
  const MAX_FILE_BYTES = 900 * 1024; // Existing 900 KB file limit
  let chosenRole = null;
  let currentUser = null;
  let authMode = 'register';
  let submissionBusy = false;
  let dashboardNavBusy = false;
  let assignedTaskHeartbeat = null;
  let assignedTaskClock = null;
  let heartbeatWarningShown = false;

  const $ = (s, root = document) => root.querySelector(s);
  const esc = value => String(value || '').replace(/[&<>'"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[c]));
  const uid = prefix => `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
  const dateLabel = value => value ? new Date(`${value}T00:00:00`).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' }) : 'No due date';
  const now = () => new Date().toISOString();
  const today = () => new Date().toISOString().slice(0, 10);
  const formatSeconds = value => { const seconds = Math.max(0, Math.floor(Number(value) || 0)); const h = Math.floor(seconds / 3600); const m = Math.floor((seconds % 3600) / 60); const s = seconds % 60; return h ? `${h}h ${m}m` : m ? `${m}m ${s}s` : `${s}s`; };
  const formatDateTime = value => value ? new Date(value).toLocaleString('en-IN', { day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' }) : '—';
  const localDateTimeParts = value => {
    if (!value) return { date: '', time: '' };
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return { date: '', time: '' };
    return { date: `${parsed.getFullYear()}-${String(parsed.getMonth()+1).padStart(2,'0')}-${String(parsed.getDate()).padStart(2,'0')}`, time: `${String(parsed.getHours()).padStart(2,'0')}:${String(parsed.getMinutes()).padStart(2,'0')}` };
  };
  const pickerDateTimeToISO = (date, time) => {
    if (!date && !time) return '';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time)) return null;
    const parsed = new Date(`${date}T${time}:00`);
    if (Number.isNaN(parsed.getTime())) return null;
    const parts = localDateTimeParts(parsed.toISOString());
    if (parts.date !== date || parts.time !== time) return null;
    return parsed.toISOString();
  };
  function studentPickerMarkup(id, students) {
    const options = students.map(student => `<label class="student-picker-option"><input type="checkbox" value="${esc(student.id)}"><span><strong>${esc(student.name)}</strong><small>${esc(student.email)}</small></span></label>`).join('');
    return `<div class="student-picker" id="${id}"><div class="student-picker-toolbar"><span data-selected-count aria-live="polite">0 selected</span><div><button class="btn-ghost" type="button" data-select-all>Select All</button><button class="btn-ghost" type="button" data-clear-selection>Clear Selection</button></div></div><div class="student-picker-list">${options || '<p class="teacher-field-note">No students are registered yet.</p>'}</div></div>`;
  }
  function bindStudentPicker(id) {
    const picker = $(`#${id}`); if (!picker) return;
    const boxes = () => $$('input[type="checkbox"]', picker);
    const updateCount = () => { picker.querySelector('[data-selected-count]').textContent = `${boxes().filter(box => box.checked).length} selected`; };
    picker.addEventListener('change', updateCount);
    picker.querySelector('[data-select-all]').onclick = () => { boxes().forEach(box => { box.checked = true; }); updateCount(); };
    picker.querySelector('[data-clear-selection]').onclick = () => { boxes().forEach(box => { box.checked = false; }); updateCount(); };
    picker.getSelectedIds = () => boxes().filter(box => box.checked).map(box => box.value);
    picker.setSelectedIds = ids => { const selected = new Set(ids); boxes().forEach(box => { box.checked = selected.has(box.value); }); updateCount(); };
    updateCount();
  }
  const selectedStudentIds = id => $(`#${id}`)?.getSelectedIds?.() || [];
  const setSelectedStudentIds = (id, ids) => $(`#${id}`)?.setSelectedIds?.(ids);
  function session() { return currentUser; }
  async function api(path, options = {}) {
    const response = await fetch(`/api${path}`, { credentials: 'same-origin', ...options, headers: { ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }), ...(options.headers || {}) } });
    if (response.status === 204) return null;
    const body = await response.json().catch(() => ({}));
    if (!response.ok) {
      if (response.status === 401 && currentUser) { currentUser = null; showAuth('Your session expired. Please sign in again.'); }
      throw new Error(body.error || `Request failed (${response.status})`);
    }
    return body;
  }
  window.studyTrackerApi = api;
  function showError(message) {
    let node = $('#app-message');
    if (!node) { node = document.createElement('p'); node.id = 'app-message'; node.setAttribute('role', 'alert'); node.className = 'auth-note'; $('#auth-screen')?.querySelector('.auth-card')?.append(node); }
    if (node) node.textContent = message;
  }
  async function loadWorkspace() {
    const [assignments, submissions, students] = await Promise.all([
      api('/assignments'), api('/submissions'), session().role === 'TEACHER' ? api('/students') : Promise.resolve([])
    ]);
    const mappedAssignments = assignments.map(a => ({ ...a, ...localDateTimeParts(a.dueAt), status: a.published ? 'active' : 'draft', audience: a.recipients?.length === students.length && students.length ? 'all' : 'selected', studentIds: (a.recipients || []).map(r => r.studentId) }));
    const mappedSubmissions = submissions.map(s => ({ ...s, studentName: s.student?.name || '', grade: s.grade?.marks ?? '', feedback: s.grade?.feedback || '', reviewStatus: s.reviewStatus === 'REVIEWED' ? 'Reviewed' : s.reviewStatus === 'IN_REVIEW' ? 'Under Review' : 'Not Reviewed', version: 1 }));
    return { assignments: mappedAssignments, submissions: mappedSubmissions, students };
  }
  function assignmentStatus(a) {
    if (a.status === 'draft') return 'Draft';
    if (a.dueDate && a.dueDate < today()) return 'Overdue';
    return 'Active';
  }
  function assignmentAudience(a) { return a.audience === 'selected' || (!a.audience && Array.isArray(a.studentIds) && a.studentIds.length) ? 'selected' : 'all'; }
  function isAssignmentForStudent(a, studentId) { return assignmentAudience(a) === 'all' || (Array.isArray(a.studentIds) && a.studentIds.includes(studentId)); }
  function studentAssignments(db, studentId) { return db.assignments.filter(a => a.status === 'active' && isAssignmentForStudent(a, studentId)); }
  function assignedStudents(db, assignment) { return db.students.filter(student => isAssignmentForStudent(assignment, student.id)); }
  function getSubmission(db, assignmentId, studentId) { return db.submissions.filter(s => s.assignmentId === assignmentId && s.studentId === studentId).sort((a,b) => String(b.submittedAt || '').localeCompare(String(a.submittedAt || '')))[0]; }

  async function login(role) {
    const name = $('#login-name').value.trim(); const email = $('#login-email').value.trim().toLowerCase(); const password = $('#login-password').value;
    if (!email || !password || (authMode === 'register' && !name)) return;
    const submit = $('#login-form button[type="submit"]'); submit.disabled = true; submit.textContent = 'Connecting…';
    try {
      const { user } = await api(authMode === 'register' ? '/auth/register' : '/auth/login', { method: 'POST', body: JSON.stringify({ ...(authMode === 'register' ? { name } : {}), email, password, role: role.toUpperCase() }) });
      currentUser = user; showError(''); await activate(user);
    } catch (error) { showError(error.message || 'Could not connect to the Study Tracker server.'); }
    finally { submit.disabled = false; submit.textContent = authMode === 'register' ? 'Create account' : 'Sign in'; }
  }

  function showAuth(message = '') {
    stopAssignedTaskTimers();
    $('#auth-screen').hidden = false; $('#teacher-shell').hidden = true;
    $('#sidebar').style.display = 'none'; $('.mobile-header').style.display = 'none'; $('#main-content').style.display = 'none'; $('#goal-note-container').style.display = 'none';
    $('#login-form').hidden = true; $('.role-choices').hidden = false; chosenRole = null;
    if (message) showError(message);
  }
  async function showStudent(user) {
    $('#auth-screen').hidden = true; $('#teacher-shell').hidden = true;
    $('#sidebar').style.display = ''; $('.mobile-header').style.display = ''; $('#main-content').style.display = ''; $('#goal-note-container').style.display = '';
    ensureStudentAssignments();
    ensureStudentStudyTasks();
    const footer = $('.sidebar-footer');
    if (!$('#student-logout')) footer.insertAdjacentHTML('beforeend', `<button class="sidebar-action-btn" id="student-logout"><span class="teacher-nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M10 17l5-5-5-5M15 12H3"/><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6"/></svg></span> Logout</button>`);
    $('#student-logout').onclick = logout;
    const title = $('.mobile-title'); if (title) title.textContent = `📚 ${user.name}`;
    await window.activateStudentTracker?.(user.id, user.email);
    if (dashboardNavBusy) return;
    window.goToPage('dashboard');
    await renderStudentAssignments();
  }
  async function showTeacher(user) {
    $('#auth-screen').hidden = true; $('#teacher-shell').hidden = false;
    $('#sidebar').style.display = 'none'; $('.mobile-header').style.display = 'none'; $('#main-content').style.display = 'none'; $('#goal-note-container').style.display = 'none';
    $('#teacher-shell').innerHTML = `<div class="teacher-layout"><aside class="teacher-sidebar"><div class="sidebar-logo teacher-sidebar-logo"><div class="logo-glow">📚</div><div class="teacher-brand-copy"><span class="logo-text">Study<span class="logo-accent">Tracker</span></span><small>Teacher workspace</small></div></div><nav class="teacher-nav" aria-label="Teacher navigation">
      <button data-view="dashboard"><span class="teacher-nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="3" y="3" width="8" height="8" rx="1"/><rect x="13" y="3" width="8" height="5" rx="1"/><rect x="13" y="10" width="8" height="11" rx="1"/><rect x="3" y="13" width="8" height="8" rx="1"/></svg></span><span>Dashboard</span></button><button data-view="assignments"><span class="teacher-nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 4H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-3"/><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M8 11h8M8 15h8M8 19h5"/></svg></span><span>Assignments</span></button><button data-view="study-tasks"><span class="teacher-nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 6h11M9 12h11M9 18h11"/><path d="m3 6 1 1 2-2M3 12l1 1 2-2M3 18l1 1 2-2"/></svg></span><span>Study Tasks</span></button><button data-view="submissions"><span class="teacher-nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 16V4m0 0L7 9m5-5 5 5"/><path d="M5 13v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6"/></svg></span><span>Submissions</span></button><button data-view="students"><span class="teacher-nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg></span><span>Students</span></button><button data-view="analytics"><span class="teacher-nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-5 5"/></svg></span><span>Analytics</span></button><button data-view="plagiarism"><span class="teacher-nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-3"/><path d="M14 3h7v7M21 3 11 13"/><path d="M7 8h4M7 12h2"/></svg></span><span>Plagiarism</span></button><button data-view="settings"><span class="teacher-nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3"/><path d="M19 13.5a7 7 0 0 0 0-3l2-1.5-2-3.5-2.3.8a7 7 0 0 0-2.6-1.5L14 2h-4l-.3 2.8a7 7 0 0 0-2.6 1.5L4.8 5.5l-2 3.5L4.7 10.5a7 7 0 0 0 0 3l-1.9 1.5 2 3.5 2.3-.8a7 7 0 0 0 2.6 1.5L10 22h4l.3-2.8a7 7 0 0 0 2.6-1.5l2.3.8 2-3.5z"/></svg></span><span>Settings</span></button>
    </nav><div class="teacher-sidebar-footer"><button id="teacher-logout"><span><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M10 17l5-5-5-5M15 12H3"/><path d="M12 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-6"/></svg></span> Logout</button></div></aside><main class="teacher-content" id="teacher-content"></main></div>`;
    $$('.teacher-nav button[data-view]').forEach(button => button.onclick = () => renderTeacher(button.dataset.view));
    $('#teacher-logout').onclick = logout; await renderTeacher('dashboard');
  }
  function $$(s, root = document) { return [...root.querySelectorAll(s)]; }
  async function activate(user) { currentUser = user || null; if (user?.role === 'TEACHER' || user?.role === 'teacher') await showTeacher(user); else if (user?.role === 'STUDENT' || user?.role === 'student') await showStudent(user); else showAuth(); }
  async function logout() { stopAssignedTaskTimers(); try { await api('/auth/logout', { method: 'POST' }); } catch (_) {} currentUser = null; $('#login-password').value = ''; showAuth(); }

  function ensureStudentAssignments() {
    if ($('#page-assignments')) return;
    const nav = $('.sidebar-nav') || $('.sidebar nav');
    const timerBtn = $('#nav-timer');
    timerBtn?.insertAdjacentHTML('beforebegin', `<button class="nav-btn" data-page="assignments" id="nav-assignments"><span class="nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 4H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-3"/><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M8 11h8M8 15h8M8 19h5"/></svg></span><span class="nav-label">Assignments</span></button>`);
    $('#main-content').insertAdjacentHTML('beforeend', `<section class="page" id="page-assignments"><div class="page-header"><div><h1 class="page-title">📥 Assignments</h1><p class="page-sub">Work assigned by your teacher</p></div></div><div class="section-card glass"><div id="student-assignment-list" class="student-assignment-list"></div></div></section>`);
    $('#nav-assignments').onclick = () => { window.goToPage('assignments'); renderStudentAssignments(); };
    const originalGo = window.goToPage;
    window.goToPage = page => { if (page === 'assignments') renderStudentAssignments(); return originalGo(page); };
  }
  let studentTaskNavWrapped = false;
  function ensureStudentStudyTasks() {
    const mount = $('#teacher-study-task-list');
    if (mount) mount.closest('.teacher-study-tasks')?.remove();
    if (!studentTaskNavWrapped && typeof window.goToPage === 'function') {
      const originalGo = window.goToPage;
      window.goToPage = page => {
        const result = originalGo(page);
        if (page === 'dashboard') {
          renderStudentStudyTasks();
          window.refreshStudentTaskStats?.().catch(error => window.showToast?.(error.message || 'Could not refresh dashboard task totals.', 'error'));
        }
        return result;
      };
      studentTaskNavWrapped = true;
    }
  }
  function stopAssignedTaskTimers() {
    if (assignedTaskHeartbeat) clearInterval(assignedTaskHeartbeat);
    if (assignedTaskClock) clearInterval(assignedTaskClock);
    assignedTaskHeartbeat = null; assignedTaskClock = null;
  }
  function renderStudentStudyTasks() {
    if (session()?.role !== 'STUDENT') return;
    const mount = $('#teacher-study-task-list'); if (!mount) return;
    mount.innerHTML = '<div class="empty-teacher">Loading assigned tasks…</div>';
    loadStudentStudyTasks().catch(error => { if (mount.isConnected) mount.innerHTML = `<div class="empty-teacher" role="alert">${esc(error.message || 'Could not load teacher-assigned tasks. Check your connection and retry.')}</div><button class="btn-outline" id="retry-teacher-study-tasks">Retry</button>`; $('#retry-teacher-study-tasks')?.addEventListener('click', renderStudentStudyTasks); });
  }
  window.refreshStudentStudyTaskPanel = renderStudentStudyTasks;
  async function loadStudentStudyTasks() {
    const mount = $('#teacher-study-task-list'); if (!mount) return;
    const rows = await api('/study-tasks');
    if (!mount.isConnected || session()?.role !== 'STUDENT') return;
    const activeRows = rows.filter(row => (row.status || (row.completed ? 'COMPLETED' : 'NOT_STARTED')) !== 'COMPLETED');
    const routineEmpty = $('#today-routine-empty');
    if (activeRows.length && routineEmpty) routineEmpty.style.display = 'none';
    if (!activeRows.length) { mount.innerHTML = rows.length ? '' : '<div class="empty-teacher">No published study tasks have been assigned to you.</div>'; stopAssignedTaskTimers(); return; }
    mount.innerHTML = activeRows.map(row => {
      const task = row.task; const status = row.status || (row.completed ? 'COMPLETED' : 'NOT_STARTED');
      const overdue = task.deadline && new Date(task.deadline) < new Date() && status !== 'COMPLETED';
      const action = status === 'RUNNING' ? 'pause' : status === 'PAUSED' ? 'resume' : status === 'NOT_STARTED' ? 'start' : '';
      const actionLabel = action === 'pause' ? 'Pause' : action === 'resume' ? 'Resume timer' : action === 'start' ? 'Start timer' : '';
      return `<article class="teacher-study-task-card ${status === 'RUNNING' ? 'is-running' : ''}" data-study-task="${task.id}"><div class="teacher-study-task-card-head"><div><span class="planner-source-badge teacher">Teacher Assigned</span><span class="teacher-task-status ${status.toLowerCase()}">${status.replace('_',' ')}</span>${overdue ? '<span class="status overdue">Overdue</span>' : ''}<h3>${esc(task.title)}</h3></div><span class="teacher-study-task-time" data-study-elapsed data-total-seconds="${row.totalSeconds || 0}" data-running-since="${row.activeSession?.startedAt || ''}">${formatSeconds(row.totalSeconds)}</span></div><p>${esc(task.description || 'No description provided.')}</p><div class="teacher-study-task-meta"><span>Due ${formatDateTime(task.deadline)}</span><span>${task.durationMinutes > 0 ? `Expected ${task.durationMinutes} min` : 'No expected duration'}</span><span>Assigned by ${esc(task.createdBy?.name || 'Teacher')}</span></div><div class="teacher-study-task-actions">${action ? `<button class="btn-primary" data-study-action="${action}" data-task-id="${task.id}">${actionLabel}</button>` : ''}<button class="btn-outline" data-study-action="complete" data-task-id="${task.id}">Complete task</button><span class="teacher-task-time-label">Recorded study time</span></div></article>`;
    }).join('');
    mount.querySelectorAll('[data-study-action]').forEach(button => button.addEventListener('click', () => runStudentStudyTaskAction(button)));
    stopAssignedTaskTimers();
    const active = activeRows.filter(row => row.status === 'RUNNING');
    if (active.length) {
      assignedTaskHeartbeat = setInterval(async () => {
        try { await Promise.all(active.map(row => api(`/study-tasks/${encodeURIComponent(row.taskId)}/heartbeat`, { method: 'POST' }))); heartbeatWarningShown = false; }
        catch (error) { if (!heartbeatWarningShown) { window.showToast?.(error.message || 'Timer heartbeat failed. Refresh to restore the task state.', 'error'); heartbeatWarningShown = true; } }
      }, 15000);
      assignedTaskClock = setInterval(() => document.querySelectorAll('[data-study-elapsed]').forEach(node => {
        const started = node.dataset.runningSince;
        const seconds = Number(node.dataset.totalSeconds) + (started ? Math.max(0, Math.floor((Date.now() - new Date(started).getTime()) / 1000)) : 0);
        node.textContent = formatSeconds(seconds);
      }), 1000);
    }
  }
  async function runStudentStudyTaskAction(button) {
    const taskId = button.dataset.taskId; const action = button.dataset.studyAction;
    if (button.disabled) return;
    if (action === 'complete' && !confirm('Mark this teacher-assigned task as completed?')) return;
    button.disabled = true; const oldLabel = button.textContent; button.textContent = action === 'complete' ? 'Saving…' : 'Updating timer…';
    try { await api(`/study-tasks/${encodeURIComponent(taskId)}/${action}`, { method: 'POST' }); window.dispatchEvent(new Event('student-study-tasks-updated')); await renderStudentStudyTasks(); }
    catch (error) { button.disabled = false; button.textContent = oldLabel; window.showToast?.(error.message || 'Could not update this task.', 'error'); }
  }
  function renderStudentAssignments() {
    const user = session(); if (!user || user.role !== 'STUDENT') return showAuth();
    const mount = $('#student-assignment-list'); if (!mount) return;
    mount.innerHTML = '<div class="empty-teacher">Loading assignments…</div>';
    loadStudentAssignments().catch(error => { if (mount.isConnected) mount.innerHTML = `<div class="empty-teacher">${esc(error.message || 'Could not load assignments. Check your connection and try again.')}</div>`; });
  }
  async function loadStudentAssignments() {
    const db = await loadWorkspace(); const list = db.assignments; const mount = $('#student-assignment-list');
    if (!mount) return;
    if (!list.length) { mount.innerHTML = `<div class="empty-teacher">No assignments yet. Your teacher’s published work will appear here.</div>`; return; }
    mount.innerHTML = list.map(a => {
      const sub = db.submissions.find(s => s.assignmentId === a.id); const overdue = a.dueDate && a.dueDate < today() && !sub;
      return `<article class="student-assignment glass"><span class="status ${overdue ? 'overdue' : sub ? 'complete' : ''}">${sub ? (sub.reviewStatus || 'Submitted') : overdue ? 'Overdue' : 'Pending'}</span><h3>${esc(a.title)}</h3><p>${esc(a.subject || 'General')} · Due ${dateLabel(a.dueDate)}</p><p>${esc(a.description)}</p>${a.instructions ? `<p><strong>Instructions:</strong> ${esc(a.instructions)}</p>` : ''}<div class="assignment-actions">${sub ? `<span class="status complete">Submitted ${new Date(sub.submittedAt).toLocaleString('en-IN')}</span>${sub.feedback ? `<span>Feedback: ${esc(sub.feedback)}</span>` : ''}${sub.grade !== '' && sub.grade != null ? `<span>Grade: ${esc(sub.grade)}</span>` : ''}` : ''}<input type="file" data-file="${a.id}" accept=".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg" aria-label="Upload work for ${esc(a.title)}"/><button class="btn-primary" data-submit="${a.id}">${sub ? 'Resubmit assignment' : 'Submit assignment'}</button></div></article>`;
    }).join('');
    $$('[data-submit]', mount).forEach(button => button.onclick = () => submitWork(button.dataset.submit, button));
  }
  async function submitWork(assignmentId, button) {
    const input = $(`[data-file="${assignmentId}"]`); const file = input?.files[0]; const user = session();
    if (submissionBusy) return;
    if (!file) return alert('Choose a file before submitting.');
    if (file.size > MAX_FILE_BYTES) return alert('Files must be 900 KB or smaller.');
    const allowedTypes = ['application/pdf','text/plain','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','image/png','image/jpeg'];
    const allowedExtensions = /\.(pdf|doc|docx|txt|png|jpe?g)$/i;
    if (!allowedTypes.includes(file.type) && !allowedExtensions.test(file.name)) return alert('Use a PDF, DOC, DOCX, TXT, PNG, or JPG file.');
    const previousLabel = button?.textContent;
    submissionBusy = true; if (button) { button.disabled = true; button.textContent = 'Uploading…'; }
    let uploaded = false;
    try { const form = new FormData(); form.append('file', file); await api(`/assignments/${encodeURIComponent(assignmentId)}/submissions`, { method: 'POST', body: form }); uploaded = true; }
    catch (error) { alert(error.message || 'Upload failed. Please try again.'); }
    if (uploaded) { try { await loadStudentAssignments(); } catch (error) { alert(`Your file was uploaded, but the assignment list could not refresh: ${error.message}`); } }
    submissionBusy = false; if (button?.isConnected) { button.disabled = false; button.textContent = previousLabel || 'Submit assignment'; }
  }

  function teacherStats(db) {
    const published = db.assignments.filter(a => a.status !== 'draft'); const submissions = db.submissions;
    const dueAssignments = published.filter(a => a.dueDate && a.dueDate < today());
    const uniqueSubmissionCount = (assignmentId) => new Set(submissions.filter(x => x.assignmentId === assignmentId).map(x => x.studentId)).size;
    const pending = published.reduce((sum, a) => sum + Math.max(0, assignedStudents(db, a).length - uniqueSubmissionCount(a.id)), 0);
    const totalPossible = published.reduce((n, a) => n + assignedStudents(db, a).length, 0);
    const uniqueReceived = published.reduce((n, a) => n + uniqueSubmissionCount(a.id), 0);
    return { assignments:db.assignments.length, students:db.students.length, submissions:submissions.length, pending, overdue:dueAssignments.length, completion:totalPossible ? Math.min(100, Math.round(uniqueReceived / totalPossible * 100)) : 0 };
  }
  function navActive(view) { $$('.teacher-nav [data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === view)); }
  async function renderTeacher(view) {
    const user = session(); if (!user || user.role !== 'TEACHER') return showAuth(); navActive(view); const root = $('#teacher-content');
    root.innerHTML = '<div class="teacher-empty">Loading workspace…</div>';
    let db; try { db = await loadWorkspace(); } catch (error) { root.innerHTML = `<div class="teacher-empty">${esc(error.message || 'Could not load workspace. Please retry.')}</div><button class="btn-primary" id="retry-workspace">Retry</button>`; $('#retry-workspace').onclick = () => renderTeacher(view); return; }
    if (!root.isConnected || !session() || session().role !== 'TEACHER') return;
    const heading = (title, subtitle, action = '') => `<div class="teacher-top"><div><p class="teacher-eyebrow">ACADEMIC WORKSPACE</p><h1>${title}</h1><p>${subtitle || `Welcome back, ${esc(user.name)}.`}</p></div><div class="teacher-top-actions">${action}<div class="teacher-top-user"><span class="teacher-avatar">${esc(user.name.charAt(0).toUpperCase())}</span><div><strong>${esc(user.name)}</strong><small>Teacher</small></div></div></div></div>`;
    if (view === 'dashboard') {
      const s = teacherStats(db);
      const recent = [...db.submissions].sort((a,b)=>String(b.submittedAt||'').localeCompare(String(a.submittedAt||''))).slice(0,5);
      const upcoming = db.assignments.filter(a=>a.status==='active'&&a.dueDate&&a.dueDate>=today()).sort((a,b)=>a.dueDate.localeCompare(b.dueDate)).slice(0,5);
      root.innerHTML = heading('Good to see you, ' + esc(user.name), 'Here is today\'s classroom overview.', '<button class="btn-primary" id="start-assignment"><span>ï¼‹</span> Create assignment</button>') +
        `<div class="teacher-grid">
          <article class="teacher-stat teacher-stat-blue glass"><div class="teacher-stat-icon">♙</div><div><span>Total students</span><strong>${s.students}</strong><small>Registered in this workspace</small></div></article>
          <article class="teacher-stat teacher-stat-purple glass"><div class="teacher-stat-icon">▣</div><div><span>Assignments</span><strong>${s.assignments}</strong><small>${db.assignments.filter(a=>a.status==='active').length} currently active</small></div></article>
          <article class="teacher-stat teacher-stat-green glass"><div class="teacher-stat-icon">✓</div><div><span>Submissions</span><strong>${s.submissions}</strong><small>Received across assignments</small></div></article>
          <article class="teacher-stat teacher-stat-orange glass"><div class="teacher-stat-icon">◷</div><div><span>Pending</span><strong>${s.pending}</strong><small>${s.overdue} overdue assignments</small></div></article>
        </div>
        <div class="teacher-dashboard-grid">
          <section class="teacher-panel teacher-overview-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">PERFORMANCE</p><h2>Assignment completion</h2></div><strong class="teacher-completion-value">${s.completion}%</strong></div><div class="teacher-progress-ring" style="--progress:${s.completion * 3.6}deg"><div><strong>${s.completion}%</strong><span>Complete</span></div></div><div class="teacher-progress-copy"><span>${Math.max(0,s.submissions)} submissions received</span><span>${s.pending} still pending</span></div></section>
          <section class="teacher-panel teacher-recent-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">ACTIVITY</p><h2>Recent submissions</h2></div><button class="link-btn" id="view-all-submissions">View all →</button></div>${recent.length?`<div class="teacher-recent-list">${recent.map(su=>{const a=db.assignments.find(x=>x.id===su.assignmentId);const student=db.students.find(x=>x.id===su.studentId);return `<article><span class="teacher-mini-avatar">${esc((su.studentName||student?.name||'S').charAt(0).toUpperCase())}</span><div><strong>${esc(su.studentName||student?.name||'Student')}</strong><small>${esc(a?.title||'Deleted assignment')}</small></div><time>${su.submittedAt?new Date(su.submittedAt).toLocaleDateString('en-IN',{day:'numeric',month:'short'}):''}</time></article>`}).join('')}</div>`:`<div class="teacher-empty"><span>✓</span><p>No submissions received yet</p><small>Student submissions will appear here.</small></div>`}</section>
          <section class="teacher-panel teacher-deadlines-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">SCHEDULE</p><h2>Upcoming deadlines</h2></div><button class="link-btn" id="view-all-deadlines">Manage →</button></div>${upcoming.length?`<div class="teacher-deadline-list">${upcoming.map(a=>{const count=new Set(db.submissions.filter(x=>x.assignmentId===a.id).map(x=>x.studentId)).size;return `<article><div class="teacher-date-box"><strong>${new Date(`${a.dueDate}T00:00:00`).getDate()}</strong><small>${new Date(`${a.dueDate}T00:00:00`).toLocaleDateString('en-IN',{month:'short'})}</small></div><div><strong>${esc(a.title)}</strong><small>${esc(a.subject||'General')} · ${count} submitted</small></div></article>`}).join('')}</div>`:`<div class="teacher-empty"><span>◷</span><p>No upcoming deadlines</p><small>Publish an assignment with a due date.</small></div>`}</section>
        </div>`;
      $('#start-assignment').onclick = () => renderTeacher('assignments');
      $('#view-all-submissions').onclick = () => renderTeacher('submissions');
      $('#view-all-deadlines').onclick = () => renderTeacher('assignments');
    } else if (view === 'assignments') renderAssignments(root, db, heading);
    else if (view === 'study-tasks') await renderStudyTasks(root, db, heading);
    else if (view === 'submissions') renderSubmissions(root, db, heading);
    else if (view === 'students') renderStudents(root, db, heading);
    else if (view === 'analytics') renderAnalytics(root, db, heading);
    else if (view === 'plagiarism') await renderPlagiarism(root, db, heading);
    else root.innerHTML = heading('Profile & Settings','Manage your teacher account.') + `<section class="teacher-settings-grid"><article class="teacher-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">ACCOUNT</p><h2>Teacher profile</h2></div></div><div class="teacher-profile-card"><span class="teacher-avatar">${esc(user.name.charAt(0).toUpperCase())}</span><div><strong>${esc(user.name)}</strong><small>${esc(user.email)}</small><span class="status complete">Teacher</span></div></div></article><article class="teacher-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">WORKSPACE</p><h2>Server session</h2></div></div><dl class="teacher-settings-list"><div><dt>Data storage</dt><dd>SQLite database</dd></div><div><dt>Session type</dt><dd>Secure server session</dd></div><div><dt>Sync</dt><dd>Shared across devices</dd></div></dl><button class="btn-danger" id="settings-logout">Logout</button></article></section>` , $('#settings-logout').onclick = logout;
  }
  async function renderPlagiarism(root, db, heading) {
    const available = db.assignments.filter(assignment => assignment.submissions?.length);
    root.innerHTML = heading('Plagiarism Detection', 'Compare current student submissions within the same assignment.') +
      `<section class="teacher-panel glass teacher-plagiarism-panel"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">INTERNAL SIMILARITY REVIEW</p><h2>Analyze submissions</h2></div><span class="teacher-panel-badge">TF-IDF · Cosine similarity</span></div><p class="teacher-plagiarism-note">Similarity scores are review indicators only. They do not establish plagiarism; inspect the files and use your judgment.</p>${available.length ? `<div class="teacher-plagiarism-controls"><label class="form-label" for="plagiarism-assignment">Assignment</label><select id="plagiarism-assignment" class="form-input">${available.map(a => `<option value="${esc(a.id)}">${esc(a.title)} (${a.submissions.length} submissions)</option>`).join('')}</select><button id="plagiarism-analyze" class="btn-primary">Analyze Submissions</button></div><p id="plagiarism-message" role="status" aria-live="polite"></p><div id="plagiarism-results"></div>` : `<div class="teacher-empty"><p>No submissions are available to analyze.</p><small>Published assignment submissions will appear here.</small></div>`}</section>`;
    if (!available.length) return;
    const select = $('#plagiarism-assignment');
    const message = $('#plagiarism-message');
    const output = $('#plagiarism-results');
    const analyze = $('#plagiarism-analyze');
    async function loadResults() {
      output.innerHTML = '<div class="teacher-empty">Loading saved analysis…</div>';
      try { const data = await api(`/assignments/${encodeURIComponent(select.value)}/plagiarism/results`); renderPlagiarismResults(output, data); message.textContent = ''; }
      catch (error) { output.innerHTML = `<div class="teacher-empty" role="alert">${esc(error.message || 'Could not load similarity results.')}</div>`; }
    }
    select.onchange = loadResults;
    analyze.onclick = async () => {
      if (analyze.disabled) return;
      analyze.disabled = true; analyze.textContent = 'Analyzing submissions…';
      message.className = 'teacher-plagiarism-message'; message.textContent = 'Extracting documents and calculating pairwise similarity…';
      output.innerHTML = '';
      try {
        const data = await api(`/assignments/${encodeURIComponent(select.value)}/plagiarism/analyze`, { method: 'POST' });
        renderPlagiarismResults(output, data);
        message.textContent = data.message || `Analysis completed at ${new Date(data.analysis.analyzedAt).toLocaleString()}.`;
        message.className = data.analysis.status === 'COMPLETED' ? 'teacher-plagiarism-message success' : 'teacher-plagiarism-message';
      } catch (error) {
        message.className = 'teacher-plagiarism-message error'; message.textContent = error.message || 'Analysis failed. Check the backend and Python dependencies, then try again.';
      } finally { analyze.disabled = false; analyze.textContent = 'Analyze Submissions'; }
    };
    await loadResults();
  }

  function renderPlagiarismResults(output, data) {
    const analysis = data.analysis;
    const excluded = data.excluded || [];
    const results = data.results || [];
    const exclusions = excluded.length ? `<section class="teacher-plagiarism-excluded"><h3>Files excluded from analysis (${excluded.length})</h3><ul>${excluded.map(item => `<li><strong>${esc(item.fileName)}</strong> · ${esc(item.studentName)} — <span>${esc(item.status.replaceAll('_', ' '))}</span>: ${esc(item.reason)}</li>`).join('')}</ul></section>` : '<p class="teacher-plagiarism-included">All submitted files were analyzed.</p>';
    const cards = results.length ? results.map(result => `<article class="teacher-plagiarism-result ${result.stale ? 'is-stale' : ''}" data-similarity-result="${esc(result.id)}"><div class="teacher-plagiarism-result-head"><div><strong>${esc(result.firstStudent.name)}</strong><span> compared with </span><strong>${esc(result.secondStudent.name)}</strong><div class="teacher-plagiarism-files">${esc(result.firstSubmission?.fileName || 'Submission unavailable')} · ${esc(result.secondSubmission?.fileName || 'Submission unavailable')}</div></div><div class="teacher-plagiarism-score">${Number(result.percentage).toFixed(2)}%</div></div><div class="teacher-plagiarism-result-meta"><span>Analyzed ${new Date(result.analyzedAt).toLocaleString()}</span><span class="status ${result.reviewStatus === 'REVIEWED' ? 'complete' : result.reviewStatus === 'DISMISSED' ? 'dismissed' : ''}">${esc(result.reviewStatus.replaceAll('_', ' '))}</span>${result.stale ? '<span class="status overdue">Submission changed · reanalyze</span>' : ''}</div><div class="teacher-plagiarism-actions"><button class="btn-outline" data-inspect-result="${esc(result.id)}" ${result.stale ? 'disabled' : ''}>Inspect comparison</button><button class="btn-outline" data-review-result="${esc(result.id)}" data-review-status="REVIEWED">Mark Reviewed</button><button class="btn-outline" data-review-result="${esc(result.id)}" data-review-status="DISMISSED">Dismiss</button></div><div class="teacher-plagiarism-detail" id="similarity-detail-${esc(result.id)}"></div></article>`).join('') : `<div class="teacher-empty">${analysis?.eligibleSubmissionCount < 2 ? 'There are not enough submissions with extractable text for a student-to-student comparison.' : 'No pairwise results are available yet.'}</div>`;
    output.innerHTML = `<p class="teacher-plagiarism-run"><strong>${esc(data.assignment?.title || 'Selected assignment')}</strong>${analysis ? ` · ${Number(analysis.eligibleSubmissionCount)} eligible documents · Analysis ${new Date(analysis.analyzedAt).toLocaleString()}` : ' · No saved analysis yet'}</p>${exclusions}<div class="teacher-plagiarism-result-list">${cards}</div>`;
    output.querySelectorAll('[data-inspect-result]').forEach(button => {
      const detail = $(`#similarity-detail-${button.dataset.inspectResult}`, output);
      button.onclick = async () => {
        if (button.disabled) return;
        if (button.dataset.open === 'true') { detail.innerHTML = ''; button.dataset.open = 'false'; button.textContent = 'Inspect comparison'; return; }
        button.disabled = true; button.textContent = 'Loading comparison…';
        try {
          const data = await api(`/plagiarism/results/${encodeURIComponent(button.dataset.inspectResult)}`);
          detail.innerHTML = `<div class="teacher-plagiarism-evidence"><h4>Shared terms</h4>${data.sharedTerms?.length ? `<ul>${data.sharedTerms.map(term => `<li>${esc(term)}</li>`).join('')}</ul>` : '<p>No reliable shared word terms were extracted; the score also includes character n-gram similarity.</p>'}</div><div class="teacher-plagiarism-documents"><section><h4>${esc(data.firstDocument.studentName)} · ${esc(data.firstDocument.fileName)}</h4><pre>${esc(data.firstDocument.text)}</pre></section><section><h4>${esc(data.secondDocument.studentName)} · ${esc(data.secondDocument.fileName)}</h4><pre>${esc(data.secondDocument.text)}</pre></section></div>`;
          button.dataset.open = 'true'; button.textContent = 'Hide comparison';
        } catch (error) { detail.innerHTML = `<p class="teacher-plagiarism-message error" role="alert">${esc(error.message || 'Could not open these submissions.')}</p>`; button.textContent = 'Retry comparison'; }
        finally { button.disabled = false; }
      };
    });
    output.querySelectorAll('[data-review-result]').forEach(button => button.onclick = async () => {
      if (button.disabled) return;
      button.disabled = true; const old = button.textContent; button.textContent = 'Saving…';
      try {
        await api(`/plagiarism/results/${encodeURIComponent(button.dataset.reviewResult)}/review`, { method: 'PATCH', body: JSON.stringify({ reviewStatus: button.dataset.reviewStatus }) });
        const data = await api(`/assignments/${encodeURIComponent($('#plagiarism-assignment').value)}/plagiarism/results`);
        renderPlagiarismResults(output, data);
      } catch (error) { button.disabled = false; button.textContent = old; window.showToast?.(error.message || 'Could not update review status.', 'error'); }
    });
  }
  function renderAssignments(root, db, heading) {
    const rows = db.assignments.map(a => {
      const assigned = assignedStudents(db, a).length;
      const count = new Set(db.submissions.filter(x => x.assignmentId === a.id).map(x => x.studentId)).size;
      return `<tr><td><strong>${esc(a.title)}</strong><br><small>${esc(a.subject || 'General')} · ${assignmentAudience(a) === 'all' ? 'All students' : 'Selected students'}</small></td><td>${dateLabel(String(a.createdAt || '').slice(0,10))}</td><td>${dateLabel(a.dueDate)}</td><td><span class="status ${assignmentStatus(a) === 'Overdue' ? 'overdue' : ''}">${assignmentStatus(a)}</span></td><td>${assigned}</td><td>${count}</td><td><button class="link-btn" data-edit="${a.id}">Edit</button> <button class="link-btn" data-delete="${a.id}">Delete</button></td></tr>`;
    }).join('');
    root.innerHTML = heading('Manage Assignments', 'Create, publish and review classroom work.') +
      `<section class="teacher-panel teacher-form-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">ASSIGNMENT DETAILS</p><h2 id="assignment-form-title">Create assignment</h2></div><span class="teacher-panel-badge">Backend connected</span></div><form id="assignment-form" class="assignment-form"><input type="hidden" id="assignment-id"><input type="hidden" id="assignment-original-due-at"><div><label class="form-label" for="assignment-title">Title</label><input class="form-input" id="assignment-title" required maxlength="100" placeholder="e.g. Algebra practice set"></div><div><label class="form-label" for="assignment-subject">Subject</label><input class="form-input" id="assignment-subject" required maxlength="60" placeholder="e.g. Mathematics"></div><div><label class="form-label" for="assignment-due">Due date</label><input class="form-input" id="assignment-due" type="date" required></div><div><label class="form-label" for="assignment-time">Due time</label><input class="form-input" id="assignment-time" type="time" required></div><div><label class="form-label" for="assignment-status">Status</label><select class="form-input" id="assignment-status"><option value="active">Active</option><option value="draft">Draft</option></select></div><div class="wide"><label class="form-label" for="assignment-description">Description</label><textarea class="form-input" id="assignment-description" required maxlength="1000" placeholder="Briefly describe the assignment"></textarea></div><div class="wide"><label class="form-label" for="assignment-instructions">Instructions (optional)</label><textarea class="form-input" id="assignment-instructions" maxlength="1500" placeholder="Add steps, resources or submission requirements"></textarea></div><div class="wide"><label class="form-label">Attachment</label><input class="form-input" id="assignment-attachment" type="file" disabled><small class="teacher-field-note">Metadata only in this prototype; secure attachment storage requires a backend.</small></div><div class="assignment-form-actions"><button class="btn-primary" type="submit">Save assignment</button><button class="btn-ghost" type="button" id="cancel-assignment" hidden>Cancel edit</button></div></form></section>` +
      `<section class="teacher-panel teacher-table-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">ASSIGNMENT LIBRARY</p><h2>All assignments</h2></div><span class="teacher-count-badge">${db.assignments.length} total</span></div><div class="teacher-toolbar"><div class="teacher-search-field"><span>⌕</span><input id="assignment-search" class="form-input" placeholder="Search assignments"></div><select class="form-input" id="assignment-filter"><option value="all">All statuses</option><option value="active">Active</option><option value="overdue">Overdue</option><option value="draft">Draft</option></select></div><div class="teacher-table-wrap"><table class="teacher-table"><thead><tr><th>Assignment</th><th>Created</th><th>Deadline</th><th>Status</th><th>Assigned</th><th>Received</th><th>Actions</th></tr></thead><tbody id="assignment-rows">${rows || '<tr><td colspan="7"><div class="teacher-empty"><p>No assignments created yet</p><small>Use the form above to publish your first assignment.</small></div></td></tr>'}</tbody></table></div></section>`;
    $('#assignment-status').closest('div').insertAdjacentHTML('afterend', `<div><label class="form-label" for="assignment-audience">Audience</label><select class="form-input" id="assignment-audience"><option value="all">All Students</option><option value="selected">Selected Students</option></select></div><div class="wide" id="assignment-targets" hidden><label class="form-label">Selected students</label>${studentPickerMarkup('assignment-students', db.students)}</div>`);
    bindStudentPicker('assignment-students');
    $('#assignment-audience').onchange = event => { $('#assignment-targets').hidden = event.target.value !== 'selected'; };
    $('#assignment-form').onsubmit = async event => {
      event.preventDefault();
      if (!$('#assignment-form').reportValidity()) return;
      const id = $('#assignment-id').value;
      const audience = $('#assignment-audience').value;
      const studentIds = audience === 'selected' ? selectedStudentIds('assignment-students') : db.students.map(student => student.id);
      if (!studentIds.length) return alert(audience === 'selected' ? 'Select at least one student.' : 'Create student accounts before assigning this work.');
      const dueDate = $('#assignment-due').value; const dueTime = $('#assignment-time').value;
      const originalDueAt = $('#assignment-original-due-at').value; const originalParts = localDateTimeParts(originalDueAt);
      const dueAt = originalDueAt && dueDate === originalParts.date && dueTime === originalParts.time ? originalDueAt : pickerDateTimeToISO(dueDate, dueTime);
      if (!dueAt) return alert('Choose a valid deadline date and time.');
      const submit = $('#assignment-form button[type="submit"]'); submit.disabled = true; submit.textContent = 'Saving…';
      try {
        const payload = { title:$('#assignment-title').value.trim(), subject:$('#assignment-subject').value.trim(), description:$('#assignment-description').value.trim(), instructions:$('#assignment-instructions').value.trim(), dueAt, published:$('#assignment-status').value === 'active', studentIds };
        if (!payload.title || !payload.subject || !payload.description) throw new Error('Complete the required assignment fields.');
        if (id) {
          await api(`/assignments/${encodeURIComponent(id)}`, { method:'PATCH', body:JSON.stringify(payload) });
          await api(`/assignments/${encodeURIComponent(id)}/recipients`, { method:'PUT', body:JSON.stringify({ studentIds }) });
        } else await api('/assignments', { method:'POST', body:JSON.stringify(payload) });
        await renderTeacher('assignments');
      } catch (error) { alert(error.message || 'Could not save assignment.'); submit.disabled = false; submit.textContent = 'Save assignment'; }
    };
    $$('[data-delete]').forEach(button => button.onclick = async () => {
      if (!confirm('Delete this assignment and its submissions?')) return;
      button.disabled = true;
      try { await api(`/assignments/${encodeURIComponent(button.dataset.delete)}`, { method:'DELETE' }); await renderTeacher('assignments'); }
      catch (error) { button.disabled = false; alert(error.message || 'Could not delete assignment.'); }
    });
    $$('[data-edit]').forEach(button => button.onclick = () => {
      const assignment = db.assignments.find(item => item.id === button.dataset.edit); if (!assignment) return;
      const parts = localDateTimeParts(assignment.dueAt);
      $('#assignment-id').value = assignment.id; $('#assignment-original-due-at').value = assignment.dueAt || '';
      $('#assignment-title').value = assignment.title; $('#assignment-subject').value = assignment.subject;
      $('#assignment-due').value = parts.date; $('#assignment-time').value = parts.time;
      $('#assignment-status').value = assignment.status; $('#assignment-description').value = assignment.description;
      $('#assignment-instructions').value = assignment.instructions || ''; $('#assignment-audience').value = assignmentAudience(assignment);
      $('#assignment-targets').hidden = assignmentAudience(assignment) !== 'selected'; setSelectedStudentIds('assignment-students', assignment.studentIds || []);
      $('#assignment-form-title').textContent = 'Edit assignment'; $('#cancel-assignment').hidden = false; window.scrollTo(0,0);
    });
    $('#cancel-assignment').onclick = () => renderTeacher('assignments');
    const filterRows = () => { const query = $('#assignment-search').value.toLowerCase(); const filter = $('#assignment-filter').value; $$('#assignment-rows tr').forEach((row, index) => { const assignment = db.assignments[index]; if (!assignment) return; row.hidden = !(assignment.title.toLowerCase().includes(query) || (assignment.subject || '').toLowerCase().includes(query)) || (filter !== 'all' && assignmentStatus(assignment).toLowerCase() !== filter); }); };
    $('#assignment-search').oninput = filterRows; $('#assignment-filter').onchange = filterRows;
  }

  function renderSubmissions(root, db, heading) {
    const submissions = [...db.submissions].sort((a,b) => String(b.submittedAt || '').localeCompare(String(a.submittedAt || '')));
    root.innerHTML = heading('Student Submissions', 'Review work, record marks and provide feedback.') +
      `<section class="teacher-panel teacher-submissions-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">SUBMISSION QUEUE</p><h2>All submissions</h2></div><span class="teacher-count-badge">${submissions.length} received</span></div><div class="teacher-toolbar"><div class="teacher-search-field"><span>⌕</span><input id="submission-search" class="form-input" placeholder="Search student or assignment"></div><select id="submission-assignment" class="form-input"><option value="">All assignments</option>${db.assignments.map(assignment => `<option value="${assignment.id}">${esc(assignment.title)}</option>`).join('')}</select></div><div id="submission-list">${submissions.length ? submissions.map(submission => submissionCard(submission, db)).join('') : '<div class="teacher-empty"><p>No student submissions have been received yet</p></div>'}</div></section>`;
    const filter = () => { const query = $('#submission-search').value.toLowerCase(); const assignmentId = $('#submission-assignment').value; $$('.review-card', $('#submission-list')).forEach(card => { card.hidden = (!!assignmentId && card.dataset.assignment !== assignmentId) || !card.textContent.toLowerCase().includes(query); }); };
    $('#submission-assignment').onchange = filter; $('#submission-search').oninput = filter; bindReviewButtons(db);
  }
  function submissionCard(submission, db) {
    const assignment = db.assignments.find(item => item.id === submission.assignmentId);
    const late = assignment?.dueDate && submission.submittedAt?.slice(0,10) > assignment.dueDate;
    const review = submission.reviewStatus || 'Not Reviewed';
    const reviewClass = review === 'Reviewed' ? 'complete' : review === 'Under Review' ? 'reviewing' : '';
    return `<article class="review-card teacher-review-card" data-assignment="${submission.assignmentId}"><div class="submission-card-header"><div class="submission-student"><span class="teacher-mini-avatar">${esc((submission.studentName || 'S').charAt(0).toUpperCase())}</span><div><strong>${esc(submission.studentName)}</strong><small>${esc(assignment?.title || 'Deleted assignment')}</small></div></div><div class="submission-badges"><span class="status ${late ? 'overdue' : ''}">${late ? 'Late' : 'Submitted'}</span><span class="status ${reviewClass}">${esc(review)}</span></div></div><div class="review-meta"><span>Submitted ${submission.submittedAt ? new Date(submission.submittedAt).toLocaleString('en-IN') : ''}</span><span>${esc(submission.fileName)} · Version ${submission.version}</span></div><div class="review-form"><div><label class="form-label">Review status</label><select class="form-input" data-review-status="${submission.id}"><option ${review === 'Not Reviewed' ? 'selected' : ''}>Not Reviewed</option><option ${review === 'Under Review' ? 'selected' : ''}>Under Review</option><option ${review === 'Reviewed' ? 'selected' : ''}>Reviewed</option></select></div><div><label class="form-label">Grade / marks</label><input class="form-input" data-grade="${submission.id}" value="${esc(submission.grade)}" maxlength="20" placeholder="e.g. 18"></div><div><label class="form-label">Feedback</label><input class="form-input" data-feedback="${submission.id}" value="${esc(submission.feedback)}" maxlength="500" placeholder="Write student feedback"></div><div class="review-actions"><button class="btn-outline" data-download="${submission.id}">↓ Download</button><button class="btn-primary" data-save-review="${submission.id}">Save review</button></div></div></article>`;
  }
  function bindReviewButtons(db) {
    $$('[data-download]').forEach(button => button.onclick = async () => {
      button.disabled = true;
      try {
        const response = await fetch(`/api/submissions/${encodeURIComponent(button.dataset.download)}/download`, { credentials:'same-origin' });
        if (!response.ok) throw new Error('Could not download this submission.');
        const blob = await response.blob(); const anchor = document.createElement('a'); anchor.href = URL.createObjectURL(blob);
        anchor.download = db.submissions.find(item => item.id === button.dataset.download)?.fileName || 'submission'; anchor.click(); URL.revokeObjectURL(anchor.href);
      } catch (error) { alert(error.message); } finally { button.disabled = false; }
    });
    $$('[data-save-review]').forEach(button => button.onclick = async () => {
      const submission = db.submissions.find(item => item.id === button.dataset.saveReview); if (!submission) return;
      const raw = $(`[data-grade="${submission.id}"]`).value.trim(); const marks = raw === '' ? null : Number(raw);
      const feedback = $(`[data-feedback="${submission.id}"]`).value.trim(); const status = $(`[data-review-status="${submission.id}"]`).value;
      if (marks !== null && (!Number.isFinite(marks) || marks < 0 || marks > 1000)) return alert('Marks must be a number between 0 and 1000.');
      if (marks === null && !feedback && status === 'Not Reviewed') return alert('Enter marks or feedback before saving.');
      button.disabled = true; button.textContent = 'Saving…';
      try {
        if (marks !== null || feedback) await api(`/submissions/${encodeURIComponent(submission.id)}/grade`, { method:'PUT', body:JSON.stringify({ marks, feedback }) });
        await api(`/submissions/${encodeURIComponent(submission.id)}/review-status`, { method:'PATCH', body:JSON.stringify({ reviewStatus:status === 'Reviewed' ? 'REVIEWED' : status === 'Under Review' ? 'IN_REVIEW' : 'NOT_REVIEWED' }) });
        await renderTeacher('submissions');
      } catch (error) { button.disabled = false; button.textContent = 'Save review'; alert(error.message || 'Could not save feedback.'); }
    });
  }

  function renderStudents(root, db, heading) {
    root.innerHTML = heading('Students', 'Monitor enrollment and individual assignment progress.') +
      `<section class="teacher-panel teacher-students-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">STUDENT DIRECTORY</p><h2>All students</h2></div><span class="teacher-count-badge">${db.students.length} enrolled</span></div><div class="teacher-toolbar"><div class="teacher-search-field"><span>⌕</span><input class="form-input" id="student-search" placeholder="Search name or email"></div></div><div id="student-list" class="teacher-student-grid">${db.students.length ? db.students.map(student => { const assigned = studentAssignments(db, student.id); const complete = assigned.filter(assignment => getSubmission(db, assignment.id, student.id)).length; const pending = Math.max(0, assigned.length - complete); const overdue = assigned.filter(assignment => assignment.dueDate < today() && !getSubmission(db, assignment.id, student.id)).length; const pct = assigned.length ? Math.round(complete / assigned.length * 100) : 0; return `<article class="student-card teacher-student-card"><div class="student-card-header"><span class="teacher-avatar">${esc(student.name.charAt(0).toUpperCase())}</span><div><strong>${esc(student.name)}</strong><small>${esc(student.email)}</small></div></div><div class="student-progress-head"><span>Overall progress</span><strong>${pct}%</strong></div><div class="bar"><i style="width:${pct}%"></i></div><div class="student-metrics"><span><strong>${assigned.length}</strong><small>Assigned</small></span><span><strong>${complete}</strong><small>Submitted</small></span><span><strong>${pending}</strong><small>Pending</small></span><span><strong>${overdue}</strong><small>Overdue</small></span></div></article>`; }).join('') : '<div class="teacher-empty"><p>No students have signed in yet</p><small>Registered student accounts will appear here.</small></div>'}</div></section>`;
    $('#student-search').oninput = event => $$('.student-card').forEach(card => { card.hidden = !card.textContent.toLowerCase().includes(event.target.value.toLowerCase()); });
  }

  async function renderStudyTasks(root, db, heading) {
    let tasks;
    try { tasks = await api('/study-tasks'); }
    catch (error) { root.innerHTML = heading('Study Tasks', 'Create, publish and monitor student study work.') + `<section class="teacher-panel glass"><p class="teacher-empty" role="alert">${esc(error.message || 'Could not load study tasks.')}</p><button class="btn-outline" id="retry-study-tasks">Retry</button></section>`; $('#retry-study-tasks').onclick = () => renderTeacher('study-tasks'); return; }
    const taskCards = tasks.length ? tasks.map(task => {
      const completed = task.assignments.filter(row => row.status === 'COMPLETED').length;
      const rows = task.assignments.map(row => {
        const status = row.status || (row.completed ? 'COMPLETED' : 'NOT_STARTED');
        const overdue = task.deadline && new Date(task.deadline) < new Date() && status !== 'COMPLETED';
        const detailId = `study-task-sessions-${task.id}-${row.studentId}`;
        return `<tr data-study-progress="${status}" data-study-overdue="${overdue}"><td><strong>${esc(row.student.name)}</strong><small>${esc(row.student.email)}</small></td><td><span class="teacher-task-status ${status.toLowerCase()}">${status.replace('_',' ')}</span>${overdue ? '<span class="status overdue">Overdue</span>' : ''}</td><td>${formatDateTime(row.startedAt)}</td><td>${formatSeconds(row.totalSeconds)}</td><td>${task.durationMinutes > 0 ? `${task.durationMinutes} min` : '—'}</td><td>${formatDateTime(task.deadline)}</td><td>${formatDateTime(row.completedAt)}</td><td><button class="btn-outline" data-study-sessions="${task.id}" data-student-id="${row.studentId}" data-detail-id="${detailId}">View sessions (${row.sessions.length})</button><div class="teacher-task-session-detail" id="${detailId}" hidden></div></td></tr>`;
      }).join('');
      return `<article class="teacher-study-task-monitor glass"><div class="teacher-study-task-monitor-head"><div><span class="teacher-task-status ${task.published ? 'published' : 'draft'}">${task.published ? 'Published' : 'Draft'}</span><h3>${esc(task.title)}</h3><p>${esc(task.description || 'No description provided.')}</p><div class="teacher-study-task-meta"><span>Due ${formatDateTime(task.deadline)}</span><span>${task.durationMinutes > 0 ? `Expected ${task.durationMinutes} min` : 'No expected duration'}</span><span>${completed} / ${task.assignments.length} completed</span></div></div><div class="teacher-study-task-actions"><button class="btn-outline" data-study-edit="${task.id}">Edit</button>${task.published ? '' : `<button class="btn-primary" data-study-publish="${task.id}">Publish</button>`}<button class="btn-danger" data-study-delete="${task.id}">Delete</button></div></div><div class="teacher-table-wrap"><table class="teacher-table teacher-study-task-table"><thead><tr><th>Student</th><th>Status</th><th>First started</th><th>Recorded time</th><th>Expected</th><th>Deadline</th><th>Completed</th><th>Sessions</th></tr></thead><tbody>${rows || '<tr><td colspan="8">No students are assigned.</td></tr>'}</tbody></table></div></article>`;
    }).join('') : '<div class="teacher-empty"><p>No study tasks yet</p><small>Create a task and assign it to registered students.</small></div>';
    root.innerHTML = heading('Study Tasks', 'Create, publish and monitor student study work.') +
      `<section class="teacher-panel teacher-study-task-form-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">TASK DETAILS</p><h2 id="study-task-form-title">Create study task</h2></div><span class="teacher-panel-badge">Server-timed sessions</span></div><form id="study-task-form" class="teacher-study-task-form"><input type="hidden" id="study-task-id"><input type="hidden" id="study-task-original-due-at"><div class="wide"><label class="form-label" for="study-task-title">Task title</label><input id="study-task-title" class="form-input" required maxlength="200" placeholder="e.g. Revise Mathematics"></div><div class="wide"><label class="form-label" for="study-task-description">Description</label><textarea id="study-task-description" class="form-input" maxlength="5000" rows="3" placeholder="What should students study or complete?"></textarea></div><div><label class="form-label" for="study-task-date">Deadline date</label><input id="study-task-date" class="form-input" type="date"></div><div><label class="form-label" for="study-task-time">Deadline time</label><input id="study-task-time" class="form-input" type="time"></div><div><label class="form-label" for="study-task-duration">Expected duration (minutes, optional)</label><input id="study-task-duration" class="form-input" type="number" min="1" max="480" placeholder="e.g. 45"></div><div><label class="form-label" for="study-task-audience">Assign to</label><select id="study-task-audience" class="form-input"><option value="ALL">All registered students</option><option value="SELECTED">Selected students</option></select></div><div id="study-task-student-wrap" class="wide" hidden><label class="form-label">Selected students</label>${studentPickerMarkup('study-task-students', db.students)}</div><label class="teacher-study-task-publish"><input id="study-task-publish-now" type="checkbox" checked> Publish immediately</label><div class="wide teacher-study-task-form-actions"><button class="btn-primary" type="submit">Create study task</button><button class="btn-outline" id="study-task-cancel-edit" type="button" hidden>Cancel edit</button><span id="study-task-error" role="alert"></span></div></form></section><section class="teacher-study-task-monitoring"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">STUDENT PROGRESS</p><h2>Assigned task monitoring</h2></div><select id="study-task-filter" class="form-input" aria-label="Filter task progress"><option value="ALL">All students</option><option value="NOT_STARTED">Not started</option><option value="RUNNING">In progress</option><option value="PAUSED">Paused</option><option value="COMPLETED">Completed</option><option value="OVERDUE">Overdue</option></select></div>${taskCards}</section>`;
    const audience = $('#study-task-audience'); const studentWrap = $('#study-task-student-wrap');
    bindStudentPicker('study-task-students');
    audience.onchange = () => { studentWrap.hidden = audience.value !== 'SELECTED'; };
    $('#study-task-cancel-edit').onclick = () => renderTeacher('study-tasks');
    $('#study-task-form').onsubmit = async event => {
      event.preventDefault();
      const id = $('#study-task-id').value; const selected = selectedStudentIds('study-task-students');
      const rawDuration = $('#study-task-duration').value.trim(); const durationMinutes = rawDuration ? Number(rawDuration) : 0;
      if (rawDuration && (!Number.isInteger(durationMinutes) || durationMinutes < 1 || durationMinutes > 480)) { $('#study-task-error').textContent = 'Expected duration must be between 1 and 480 minutes.'; return; }
      if (audience.value === 'SELECTED' && !selected.length) { $('#study-task-error').textContent = 'Select at least one student.'; return; }
      const dueDate = $('#study-task-date').value; const dueTime = $('#study-task-time').value;
      const originalDueAt = $('#study-task-original-due-at').value; const originalParts = localDateTimeParts(originalDueAt);
      const dueAt = originalDueAt && dueDate === originalParts.date && dueTime === originalParts.time ? originalDueAt : pickerDateTimeToISO(dueDate, dueTime);
      if ((dueDate || dueTime) && !dueAt) { $('#study-task-error').textContent = 'Choose a valid deadline date and time, or clear both fields.'; return; }
      const submit = $('#study-task-form button[type="submit"]'); const oldText = submit.textContent; submit.disabled = true; submit.textContent = 'Saving…'; $('#study-task-error').textContent = '';
      const payload = { title:$('#study-task-title').value.trim(), description:$('#study-task-description').value.trim(), dueAt:dueAt || null, durationMinutes, audience:audience.value, studentIds:selected, published:id ? undefined : $('#study-task-publish-now').checked };
      try { await api(id ? `/study-tasks/${encodeURIComponent(id)}` : '/study-tasks', { method:id ? 'PATCH' : 'POST', body:JSON.stringify(payload) }); await renderTeacher('study-tasks'); }
      catch (error) { $('#study-task-error').textContent = error.message || 'Could not save the study task.'; submit.disabled = false; submit.textContent = oldText; }
    };
    audience.onchange();
    $$('[data-study-edit]').forEach(button => button.onclick = () => {
      const task = tasks.find(item => item.id === button.dataset.studyEdit); if (!task) return;
      $('#study-task-id').value = task.id; $('#study-task-original-due-at').value = task.deadline || '';
      $('#study-task-title').value = task.title; $('#study-task-description').value = task.description || '';
      const deadline = localDateTimeParts(task.deadline); $('#study-task-date').value = deadline.date; $('#study-task-time').value = deadline.time;
      $('#study-task-duration').value = task.durationMinutes > 0 ? task.durationMinutes : '';
      const selectedIds = task.assignments.map(row => row.studentId); const allSelected = db.students.length > 0 && db.students.every(student => selectedIds.includes(student.id));
      audience.value = allSelected ? 'ALL' : 'SELECTED'; setSelectedStudentIds('study-task-students', selectedIds); audience.onchange();
      $('#study-task-publish-now').checked = task.published; $('#study-task-publish-now').disabled = true;
      $('#study-task-form-title').textContent = 'Edit study task'; $('#study-task-form button[type="submit"]').textContent = 'Save changes'; $('#study-task-cancel-edit').hidden = false;
      $('#study-task-form').scrollIntoView({ behavior:'smooth', block:'start' });
    });
    $('#study-task-filter').onchange = event => $$('[data-study-progress]').forEach(row => { const filter = event.target.value; row.hidden = filter === 'OVERDUE' ? row.dataset.studyOverdue !== 'true' : filter !== 'ALL' && row.dataset.studyProgress !== filter; });
    $$('[data-study-delete]').forEach(button => button.onclick = async () => {
      if (!confirm('Delete this study task and its recorded student progress?')) return;
      button.disabled = true; try { await api(`/study-tasks/${encodeURIComponent(button.dataset.studyDelete)}`, { method:'DELETE' }); await renderTeacher('study-tasks'); }
      catch (error) { button.disabled = false; alert(error.message || 'Could not delete the study task.'); }
    });
    $$('[data-study-publish]').forEach(button => button.onclick = async () => {
      button.disabled = true; try { await api(`/study-tasks/${encodeURIComponent(button.dataset.studyPublish)}/publish`, { method:'POST' }); await renderTeacher('study-tasks'); }
      catch (error) { button.disabled = false; alert(error.message || 'Could not publish the study task.'); }
    });
    $$('[data-study-sessions]').forEach(button => button.onclick = async () => {
      const target = document.getElementById(button.dataset.detailId); if (!target) return;
      target.hidden = false; target.innerHTML = '<p>Loading study sessions…</p>'; button.disabled = true;
      try {
        const report = await api(`/study-tasks/${encodeURIComponent(button.dataset.studySessions)}/students/${encodeURIComponent(button.dataset.studentId)}/sessions`);
        target.innerHTML = report.sessions.length ? `<p><strong>${esc(report.student.name)}</strong> · ${esc(report.task.title)} · ${formatSeconds(report.totalSeconds)} total</p><ul>${report.sessions.map(row => `<li>${formatDateTime(row.startedAt)} – ${row.endedAt ? formatDateTime(row.endedAt) : 'Running'} · ${formatSeconds(row.duration + (!row.endedAt ? Math.max(0, Math.floor((Date.now()-new Date(row.startedAt).getTime())/1000)) : 0))}</li>`).join('')}</ul>` : '<p>No study sessions recorded yet.</p>';
      } catch (error) { target.innerHTML = `<p role="alert">${esc(error.message || 'Could not load sessions.')}</p>`; }
      finally { button.disabled = false; }
    });
  }
  function renderAnalytics(root, db, heading) {
    const published=db.assignments.filter(a=>a.status==='active'); const s=teacherStats(db);
    root.innerHTML=heading('Progress & Analytics','Classroom performance and submission trends.')+`<div class="teacher-grid teacher-analytics-summary"><article class="teacher-stat teacher-stat-blue glass"><div class="teacher-stat-icon">♙</div><div><span>Students</span><strong>${db.students.length}</strong></div></article><article class="teacher-stat teacher-stat-purple glass"><div class="teacher-stat-icon">▣</div><div><span>Active assignments</span><strong>${published.length}</strong></div></article><article class="teacher-stat teacher-stat-green glass"><div class="teacher-stat-icon">✓</div><div><span>Unique submissions</span><strong>${Math.max(0,s.submissions)}</strong></div></article><article class="teacher-stat teacher-stat-orange glass"><div class="teacher-stat-icon">◷</div><div><span>Completion</span><strong>${s.completion}%</strong></div></article></div><section class="teacher-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">ASSIGNMENT REPORT</p><h2>Submission rate by assignment</h2></div></div>${published.length?published.map(a=>{const count=new Set(db.submissions.filter(s=>s.assignmentId===a.id).map(s=>s.studentId)).size;const assigned=assignedStudents(db,a).length;const pct=assigned?Math.round(count/assigned*100):0;return `<div class="analytics-bar-row"><div><strong>${esc(a.title)}</strong><small>${count} of ${assigned} submitted</small></div><div class="bar"><i style="width:${pct}%"></i></div><strong>${pct}%</strong></div>`}).join(''):'<div class="teacher-empty"><span>▥</span><p>Analytics will appear after assignments are created</p><small>Submission rates are calculated from shared Study Tracker records.</small></div>'}</section><section class="teacher-panel glass"><div class="teacher-panel-heading"><div><p class="teacher-section-kicker">STUDENT REPORT</p><h2>Student progress overview</h2></div></div>${db.students.length?db.students.map(s=>{const as=studentAssignments(db,s.id);const done=as.filter(a=>getSubmission(db,a.id,s.id)).length;const pct=as.length?Math.round(done/as.length*100):0;return `<div class="analytics-bar-row"><div><strong>${esc(s.name)}</strong><small>${done} of ${as.length} submitted</small></div><div class="bar"><i style="width:${pct}%"></i></div><strong>${pct}%</strong></div>`}).join(''):'<div class="teacher-empty"><span>♙</span><p>No students are registered yet</p><small>Progress appears after students sign in.</small></div>'}</section>`;
  }

  async function confirmDeleteTask(id) {
    if (!confirm('Delete this task from your routine?')) return;
    try {
      if (window.studyTrackerApi) await window.studyTrackerApi(`/tasks/${encodeURIComponent(id)}`, { method: 'DELETE' });
      window.deleteTaskFromTracker?.(id); window.renderRoutineFromTracker?.();
    } catch (error) { alert(error.message || 'Could not delete task.'); }
  }

  document.addEventListener('DOMContentLoaded', async () => {
    $$('.role-choice').forEach(button => button.onclick = () => { chosenRole=button.dataset.role; authMode='register'; $('#login-form').hidden=false; $('.role-choices').hidden=true; setAuthMode(); $('#login-name').focus(); });
    function setAuthMode(){const registering=authMode==='register';$('#login-title').textContent=`${chosenRole==='teacher'?'Teacher':'Student'} ${registering?'create account':'sign in'}`;$('#login-name').hidden=!registering;$('label[for="login-name"]').hidden=!registering;$('#login-name').required=registering;$('#login-name').disabled=!registering;$('#login-email').autocomplete=registering?'email':'username';$('#login-password').autocomplete=registering?'new-password':'current-password';$('#login-form button[type="submit"]').textContent=registering?'Create account':'Sign in';$('#toggle-auth-mode').textContent=registering?'Already registered? Sign in':'New here? Create an account';}
    $('#toggle-auth-mode').onclick=()=>{authMode=authMode==='register'?'login':'register';setAuthMode();};
    $('#back-to-roles').onclick=()=>{ $('#login-form').hidden=true; $('.role-choices').hidden=false; }; $('#login-form').onsubmit=e=>{e.preventDefault();login(chosenRole);};
    try { const {user}=await api('/auth/me'); currentUser=user; await activate(user); } catch (error) { currentUser=null; showAuth(error instanceof TypeError ? 'Cannot connect to the Study Tracker server. Start the backend and try again.' : ''); }
  });
})();
