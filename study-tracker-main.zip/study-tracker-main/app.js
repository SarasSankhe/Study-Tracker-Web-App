/* ============================================================
   StudyTracker — Main App Logic
   ============================================================ */
const STATE = {
  tasks: [], teacherTasks: [], teacherTaskStats: [], playlists: [], log: {}, streak: 0, bestStreak: 0,
  editingTaskId: null, timerSessions: {}, currentTimerTaskId: null,
  goalNote: "", goalNoteMinimized: false
};
let activeTrackerStorageKey = 'sf_state';
const TODAY = todayKey();

// ── Storage ──────────────────────────────────────────────────
function trackerDefaults() {
  return { tasks: [], teacherTasks: [], teacherTaskStats: [], playlists: [], log: {}, streak: 0, bestStreak: 0, editingTaskId: null, timerSessions: {}, currentTimerTaskId: null, goalNote: "", goalNoteMinimized: false };
}
function resetTrackerState() { Object.assign(STATE, trackerDefaults()); }
function save() {
  const { teacherTasks, teacherTaskStats, ...personalState } = STATE;
  localStorage.setItem(activeTrackerStorageKey, JSON.stringify(personalState));
}
function load() {
  const raw = localStorage.getItem(activeTrackerStorageKey);
  resetTrackerState();
  if (raw) { try { Object.assign(STATE, JSON.parse(raw)); } catch (e) { resetTrackerState(); } }
  ensureTodayLog();
  STATE.playlists.forEach(assignTodayVideo);
  recalcStreak();
  renderGoalNote();
}
async function activateStudentTracker(studentId, email) {
  activeTrackerStorageKey = `sf_state_${encodeURIComponent(studentId)}`;
  load();
  STATE.teacherTasks = [];
  STATE.teacherTaskStats = [];
  const api = window.studyTrackerApi;
  if (api) {
    try {
      let rows = await api('/tasks?type=PERSONAL');
      let legacy = null;
      try {
        const previous = JSON.parse(localStorage.getItem('sf_session') || 'null');
        if (previous && previous.role === 'student' && String(previous.email || '').toLowerCase() === String(email || '').toLowerCase()) legacy = JSON.parse(localStorage.getItem(`sf_state_${encodeURIComponent(previous.id)}`) || 'null');
      } catch (_) {}
      if (!rows.length) {
        const tasksToImport = legacy?.tasks || [];
        for (const task of tasksToImport) await api('/tasks', { method: 'POST', body: JSON.stringify({ id: task.id, title: task.name, description: task.notes || '', category: task.category || 'Study', priority: task.priority || 'medium', scheduledTime: task.time || '', durationMinutes: Number(task.duration) || 60, notes: task.notes || '', type: 'PERSONAL' }) });
        if (tasksToImport.length) rows = await api('/tasks?type=PERSONAL');
      }
      if (legacy?.timerSessions) {
        for (const [date, sessions] of Object.entries(legacy.timerSessions)) {
          for (const [index, old] of (sessions || []).entries()) {
            const endedAt = new Date(`${date}T23:59:00`).toISOString();
            const taskId = old.taskId && rows.some(row => row.task.id === old.taskId) ? old.taskId : null;
            await api('/study-sessions', { method: 'POST', body: JSON.stringify({ id: `legacy-${studentId}-${date}-${index}`, taskId, startedAt: new Date(Date.parse(endedAt) - (Number(old.duration) || 0) * 60000).toISOString(), endedAt, duration: (Number(old.duration) || 0) * 60 }) });
          }
        }
      }
      STATE.tasks = rows.map(row => ({ id: row.task.id, name: row.task.title, category: row.task.category || 'Study', priority: row.task.priority || 'medium', time: row.task.scheduledTime || '', duration: row.task.durationMinutes || 60, notes: row.task.notes || row.task.description || '' }));
      const sessions = await api('/study-sessions');
      STATE.timerSessions = {};
      for (const row of sessions) {
        const at = new Date(row.startedAt); const key = `${at.getFullYear()}-${pad(at.getMonth()+1)}-${pad(at.getDate())}`;
        if (!STATE.timerSessions[key]) STATE.timerSessions[key] = [];
        STATE.timerSessions[key].push({ duration: Math.round((row.duration || 0) / 60), time: new Date(row.endedAt || row.startedAt).toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' }), taskId: row.taskId, taskName: row.task?.title || '' });
      }
      ensureTodayLog(); recalcStreak(); save();
    } catch (error) { showToast(error.message || 'Could not sync personal tasks.', 'error'); }
    try { await refreshTeacherStudyTasks(); }
    catch (error) { showToast(error.message || 'Could not load teacher-assigned study tasks.', 'error'); }
  }
  goToPage('dashboard');
}
function ensureTodayLog() {
  if (!STATE.log[TODAY]) STATE.log[TODAY] = { tasks: {}, videos: {} };
  if (!STATE.timerSessions) STATE.timerSessions = {};
  if (!STATE.timerSessions[TODAY]) STATE.timerSessions[TODAY] = [];
}

// ── Date Helpers ─────────────────────────────────────────────
function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function pad(n) { return String(n).padStart(2, '0'); }
function formatDate(key) {
  const d = new Date(key + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}
function daysBetween(k1, k2) {
  return Math.floor((new Date(k2 + 'T00:00:00') - new Date(k1 + 'T00:00:00')) / (864e5));
}
function prevDay(key) {
  const d = new Date(key + 'T00:00:00'); d.setDate(d.getDate() - 1);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function addDays(key, n) {
  const d = new Date(key + 'T00:00:00'); d.setDate(d.getDate() + n);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

// ── Streak Logic ─────────────────────────────────────────────
function dayCompleted(key) {
  const dayLog = STATE.log[key];
  if (!dayLog) return false;
  const tasksDone = STATE.tasks.length === 0 || STATE.tasks.every(t => dayLog.tasks[t.id]);
  const vidsTotal = STATE.playlists.reduce((a, pl) => a + (pl.todayVideoMap?.[key] ? 1 : 0), 0);
  const vidsDone = STATE.playlists.filter(pl => {
    const vid = pl.todayVideoMap?.[key]; return vid && dayLog.videos[vid];
  }).length;
  return tasksDone && (vidsTotal === 0 || vidsDone === vidsTotal);
}
function recalcStreak() {
  let s = 0, cur = TODAY;
  while (dayCompleted(cur)) { s++; cur = prevDay(cur); }
  STATE.streak = s;
  if (s > STATE.bestStreak) STATE.bestStreak = s;
  save();
}

// ── YouTube Helpers ──────────────────────────────────────────
function ytVideoId(url) { const m = url.match(/[?&]v=([^&#]+)/) || url.match(/youtu\.be\/([^?]+)/); return m ? m[1] : null; }
function ytPlaylistId(url) { const m = url.match(/[?&]list=([^&#]+)/); return m ? m[1] : null; }
function ytThumb(vid) { return `https://img.youtube.com/vi/${vid}/mqdefault.jpg`; }
function ytWatchUrl(vid) { return `https://www.youtube.com/watch?v=${vid}`; }

function parseManualUrls(text) {
  return text.split('\n').map(l => l.trim()).filter(Boolean).map((url, i) => {
    const vid = ytVideoId(url);
    return { id: vid || `manual-${Date.now()}-${i}`, url, title: `Video ${i + 1}`, thumb: vid ? ytThumb(vid) : null };
  });
}
function assignTodayVideo(pl) {
  if (!pl.todayVideoMap) pl.todayVideoMap = {};
  if (pl.todayVideoMap[TODAY]) return;
  if (!pl.videos || pl.videos.length === 0) return;
  const startDate = pl.startDate || TODAY; pl.startDate = startDate;
  // Find next unwatched video
  const watchedIds = new Set();
  Object.values(STATE.log).forEach(dl => {
    Object.keys(dl.videos || {}).forEach(v => { if (dl.videos[v]) watchedIds.add(v); });
  });
  let vidIdx = -1;
  for (let i = 0; i < pl.videos.length; i++) {
    if (!watchedIds.has(pl.videos[i].id)) { vidIdx = i; break; }
  }
  // If all videos are watched, playlist is complete — don't assign
  if (vidIdx === -1) return;
  pl.todayVideoMap[TODAY] = pl.videos[vidIdx].id;
  save();
}

// ── Task CRUD ────────────────────────────────────────────────
function addTask(task) { STATE.tasks.push(task); ensureTodayLog(); save(); }
function updateTask(id, data) { const i = STATE.tasks.findIndex(t => t.id === id); if (i !== -1) Object.assign(STATE.tasks[i], data); save(); }
function deleteTask(id) {
  STATE.tasks = STATE.tasks.filter(t => t.id !== id);
  if (STATE.currentTimerTaskId === id) STATE.currentTimerTaskId = null;
  save();
}
function toggleTaskToday(id) {
  const log = STATE.log[TODAY]; log.tasks[id] = !log.tasks[id];
  recalcStreak(); save(); checkAllDone();
  window.studyTrackerApi?.(`/tasks/${encodeURIComponent(id)}/status`, { method: 'PATCH', body: JSON.stringify({ completed: !!log.tasks[id] }) }).catch(error => showToast(error.message || 'Could not sync task status.', 'error'));
}

// ── Playlist CRUD ────────────────────────────────────────────
function addPlaylist(pl) { STATE.playlists.push(pl); assignTodayVideo(pl); ensureTodayLog(); save(); }
function deletePlaylist(id) { STATE.playlists = STATE.playlists.filter(p => p.id !== id); save(); }
function toggleVideoToday(videoId) {
  const log = STATE.log[TODAY]; log.videos[videoId] = !log.videos[videoId];
  recalcStreak(); save(); checkAllDone();
}
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2); }

// ── Check all done → celebration ─────────────────────────────
function checkAllDone() {
  if (dayCompleted(TODAY)) {
    showToast('🎉 All tasks completed! Amazing work!', 'success');
    launchConfetti();
  }
}

// ── Navigation ───────────────────────────────────────────────
function goToPage(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`page-${page}`).classList.add('active');
  document.getElementById(`nav-${page}`)?.classList.add('active');

  // Update background class for 4K motivational images
  document.body.className = `bg-${page}`;

  document.getElementById('sidebar').classList.remove('open');
  document.querySelector('.sidebar-overlay')?.classList.remove('show');
  renderPage(page);
  if (page === 'planner' && window.studyTrackerApi) refreshTeacherStudyTasks().catch(() => {});
  window.scrollTo(0, 0);
}
function renderPage(page) {
  if (page === 'dashboard') renderDashboard();
  if (page === 'routine') renderRoutine();
  if (page === 'planner') renderPlanner();
  if (page === 'playlists') renderPlaylists();
  if (page === 'timer') renderTimer();
}

// ── Motivational Quotes ──────────────────────────────────────
const QUOTES = [
  ["Success is the sum of small efforts, repeated day in and day out.", "Robert Collier"],
  ["The secret of getting ahead is getting started.", "Mark Twain"],
  ["It does not matter how slowly you go as long as you do not stop.", "Confucius"],
  ["Believe you can and you're halfway there.", "Theodore Roosevelt"],
  ["The only way to do great work is to love what you do.", "Steve Jobs"],
  ["Education is the most powerful weapon which you can use to change the world.", "Nelson Mandela"],
  ["Don't watch the clock; do what it does. Keep going.", "Sam Levenson"],
  ["The future belongs to those who believe in the beauty of their dreams.", "Eleanor Roosevelt"],
  ["Start where you are. Use what you have. Do what you can.", "Arthur Ashe"],
  ["You don't have to be great to start, but you have to start to be great.", "Zig Ziglar"],
  ["The harder you work for something, the greater you'll feel when you achieve it.", "Unknown"],
  ["Push yourself, because no one else is going to do it for you.", "Unknown"],
  ["Great things never come from comfort zones.", "Unknown"],
  ["Dream it. Wish it. Do it.", "Adlof Hitler"],
  ["Success doesn't just find you. You have to go out and get it.", "Unknown"],
  ["Wake up with determination. Go to bed with satisfaction.", "Unknown"],
  ["Do something today that your future self will thank you for.", "Sean Patrick Flanery"],
  ["Little things make big days.", "Ezio Auditore"],
  ["It's going to be hard, but hard does not mean impossible.", "Bond 007"],
  ["Don't stop when you're tired. Stop when you're done.", "Charlie Kirk"],
  ["The expert in anything was once a beginner.", "Helen Hayes"],
  ["Discipline is the bridge between goals and accomplishment.", "Jim Rohn"],
  ["Aaj ka kaam aaj karo, kal ki kal sochna.", "Hindi Proverb"],
  ["Mehnat itni khamoshi se karo ki success shor macha de.", "Unknown"],
  ["Padhai ka koi shortcut nahi hota, bas consistency chahiye.", "Unknown"],
];
function getDailyQuote() {
  const dayOfYear = Math.floor((new Date() - new Date(new Date().getFullYear(), 0, 0)) / (864e5));
  return QUOTES[dayOfYear % QUOTES.length];
}

// ── Dashboard ────────────────────────────────────────────────
function renderDashboard() {
  const h = new Date().getHours();
  const g = h < 12 ? 'Morning' : h < 17 ? 'Afternoon' : 'Evening';
  document.getElementById('greeting-time').textContent = g;
  document.getElementById('today-date').textContent = formatDate(TODAY);

  // Quote
  const q = getDailyQuote();
  document.getElementById('quote-text').textContent = `"${q[0]}"`;
  document.getElementById('quote-author').textContent = `— ${q[1]}`;

  // Streak
  const s = STATE.streak;
  document.getElementById('sidebar-streak').textContent = s;
  document.getElementById('mobile-streak-num').textContent = s;
  document.getElementById('dash-streak').textContent = s;

  // Stats
  const log = STATE.log[TODAY] || {};
  const taskStats = dashboardTaskStats(STATE.tasks, log, STATE.teacherTaskStats || []);
  const doneTasks = taskStats.done;
  const totalTasks = taskStats.total;
  const todayVids = getTodayVideos();
  const doneVids = todayVids.filter(v => log.videos?.[v.videoId]).length;
  const pct = taskStats.completion;

  document.getElementById('done-tasks').textContent = doneTasks;
  document.getElementById('total-tasks').textContent = totalTasks;
  document.getElementById('done-videos').textContent = doneVids;
  document.getElementById('completion-pct').textContent = pct + '%';

  // Routine list
  const routineList = document.getElementById('today-routine-list');
  const routineEmpty = document.getElementById('today-routine-empty');
  const personalTasks = STATE.tasks.filter(task => !log.tasks?.[task.id]);
  if (personalTasks.length === 0) { routineList.innerHTML = ''; routineEmpty.style.display = 'block'; }
  else {
    routineEmpty.style.display = 'none';
    routineList.innerHTML = personalTasks.map(t => {
      const d = false;
      const inProgress = isTaskInProgress(t.id);
      return `<div class="task-item ${d ? 'completed' : ''} ${inProgress ? 'in-progress' : ''}" onclick="toggleTaskToday('${t.id}');renderDashboard()">
        <div class="priority-dot ${t.priority || 'medium'}"></div>
        <div class="task-checkbox ${d ? 'checked' : ''}">${d ? '✓' : ''}</div>
        <div class="task-info">
          <span class="planner-source-badge personal">Personal</span>
          <div class="task-name">${esc(t.name)}</div>
          ${inProgress ? '<div class="task-status">In progress</div>' : ''}
          <div class="task-meta">${t.time ? '⏰ ' + t.time : ''}${t.duration ? ' · ' + t.duration + 'min' : ''}${t.notes ? ' · ' + esc(t.notes) : ''}</div>
        </div>
        <span class="task-cat-badge">${inProgress ? 'In progress' : catEmoji(t.category) + ' ' + esc(t.category)}</span>
      </div>`;
    }).join('');
  }

  // Videos list
  const videosList = document.getElementById('today-videos-list');
  const videosEmpty = document.getElementById('today-videos-empty');
  if (todayVids.length === 0) { videosList.innerHTML = ''; videosEmpty.style.display = 'block'; }
  else { videosEmpty.style.display = 'none'; videosList.innerHTML = todayVids.map(renderVideoItem).join(''); }
}

function dashboardTaskStats(personalTasks, dayLog, assignedTasks) {
  const total = personalTasks.length + assignedTasks.length;
  const done = personalTasks.filter(task => dayLog.tasks?.[task.id]).length + assignedTasks.filter(task => task.completed).length;
  return { total, done, completion: total ? Math.round(done / total * 100) : 0 };
}

function getTodayVideos() {
  return STATE.playlists.map(pl => {
    const videoId = pl.todayVideoMap?.[TODAY]; if (!videoId) return null;
    const video = pl.videos?.find(v => v.id === videoId); if (!video) return null;
    const videoIdx = pl.videos.findIndex(v => v.id === videoId);
    return {
      ...video, videoId: video.id, playlistId: pl.id, playlistName: pl.name,
      lectureNum: videoIdx + 1, totalLectures: pl.videos.length, subject: pl.subject
    };
  }).filter(Boolean);
}

function renderVideoItem(v) {
  const done = STATE.log[TODAY]?.videos?.[v.videoId];
  const watchUrl = v.url || (v.videoId ? ytWatchUrl(v.videoId) : '#');
  const thumb = v.thumb || (v.videoId ? ytThumb(v.videoId) : null);
  return `<div class="video-item ${done ? 'completed' : ''}" onclick="window.open('${watchUrl}','_blank')" style="cursor:pointer">
    <div class="video-thumb">${thumb ? `<img src="${thumb}" alt="thumb" onerror="this.parentElement.innerHTML='▶️'">` : '▶️'}</div>
    <div class="video-info">
      <div class="video-lecture-badge">📺 Lecture ${v.lectureNum} of ${v.totalLectures}</div>
      <div class="video-title">${esc(v.title)}</div>
      <div class="video-playlist-name">📂 ${esc(v.playlistName || '')}${v.subject ? ' · 📌 ' + esc(v.subject) : ''}</div>
      <div class="video-meta">${done ? '✅ Watched today' : '⏳ Click to watch this lecture'}</div>
    </div>
    <div class="video-actions" onclick="event.stopPropagation()">
      <a class="btn-watch" href="${watchUrl}" target="_blank">▶ Watch</a>
      <button class="btn-done ${done ? 'active' : ''}" onclick="event.stopPropagation();toggleVideoToday('${v.videoId}');renderDashboard()">
        ${done ? '✅ Done' : '☐ Done'}
      </button>
    </div>
  </div>`;
}

function catEmoji(cat) {
  const m = { Study: '📖', Revision: '🔁', Practice: '✏️', Reading: '📚', Exercise: '🏃', Coding: '💻', Other: '⚡' };
  return m[cat] || '📌';
}
function esc(s = '') { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function isTaskInProgress(id) { return STATE.currentTimerTaskId === id && !STATE.log[TODAY]?.tasks?.[id]; }

// ── Routine Page ─────────────────────────────────────────────
function renderRoutine() {
  const grid = document.getElementById("routine-list");
  const empty = document.getElementById("routine-empty");

  if (!grid) return;
  if (STATE.tasks.length === 0) {
    grid.innerHTML = "";
    if (empty) empty.style.display = "block";
    return;
  }
  if (empty) empty.style.display = "none";

  grid.innerHTML = STATE.tasks.map(t => {
    const inProgress = isTaskInProgress(t.id);
    return `
    <div class="routine-card priority-${t.priority || 'medium'} ${inProgress ? 'in-progress' : ''}">

      <div class="routine-card-header">
        <div>
          <div class="routine-card-title">
            ${t.name}
          </div>
          ${inProgress ? '<div class="task-status">In progress</div>' : ''}
          <div class="routine-card-meta">
            ⏱ ${t.duration || 60} min · ${t.priority || 'medium'}
          </div>
        </div>

        <div class="routine-card-actions">
          <button class="icon-btn" onclick="setTimerForTask('${t.id}')" title="Set timer for this task">Start</button>
          <button class="icon-btn" onclick="openEditTask('${t.id}')">✏️</button>
          <button class="icon-btn" onclick="recommendVideos('${t.name}')">▶️</button>
          <button class="icon-btn danger" onclick="confirmDeleteTask('${t.id}')">🗑️</button>
        </div>
      </div>

    </div>
  `;
  }).join("");
}

function openAddTask() {
  STATE.editingTaskId = null;
  document.getElementById('modal-title').textContent = 'Add Task';
  document.getElementById('task-name-input').value = '';
  document.getElementById('task-category-input').value = 'Study';
  document.getElementById('task-priority-input').value = 'medium';
  document.getElementById('task-time-input').value = '';
  document.getElementById('task-duration-input').value = '';
  document.getElementById('task-notes-input').value = '';
  document.getElementById('task-modal').style.display = 'flex';
}
function openEditTask(id) {
  const t = STATE.tasks.find(t => t.id === id); if (!t) return;
  STATE.editingTaskId = id;
  document.getElementById('modal-title').textContent = 'Edit Task';
  document.getElementById('task-name-input').value = t.name;
  document.getElementById('task-category-input').value = t.category;
  document.getElementById('task-priority-input').value = t.priority || 'medium';
  document.getElementById('task-time-input').value = t.time || '';
  document.getElementById('task-duration-input').value = t.duration || '';
  document.getElementById('task-notes-input').value = t.notes || '';
  document.getElementById('task-modal').style.display = 'flex';
}
function closeTaskModal() { document.getElementById('task-modal').style.display = 'none'; }
async function saveTask() {
  const name = document.getElementById('task-name-input').value.trim();
  if (!name) { showToast('Task name required!', 'error'); return; }
  const duration = parseInt(document.getElementById('task-duration-input').value, 10) || 60;
  if (duration < 1 || duration > 480) { showToast('Duration must be 1-480 minutes', 'error'); return; }
  const data = {
    name,
    category: document.getElementById('task-category-input').value,
    priority: document.getElementById('task-priority-input').value,
    time: document.getElementById('task-time-input').value,
    duration,
    notes: document.getElementById('task-notes-input').value.trim(),
  };
  const api = window.studyTrackerApi;
  const creating = !STATE.editingTaskId;
  const taskId = STATE.editingTaskId || uid();
  try {
    if (api) await api(creating ? '/tasks' : `/tasks/${encodeURIComponent(taskId)}`, { method: creating ? 'POST' : 'PATCH', body: JSON.stringify({ ...(creating ? { id: taskId } : {}), title: data.name, description: data.notes, category: data.category, priority: data.priority, scheduledTime: data.time, durationMinutes: data.duration, notes: data.notes, type: 'PERSONAL' }) });
  } catch (error) { showToast(error.message || 'Could not save task. Please retry.', 'error'); return; }
  if (STATE.editingTaskId) { updateTask(STATE.editingTaskId, data); showToast('✏️ Task updated!', 'success'); }
  else { addTask({ id: uid(), ...data }); showToast('✅ Task added!', 'success'); }
  if (creating && api) STATE.tasks[STATE.tasks.length - 1].id = taskId;
  closeTaskModal(); renderRoutine(); renderDashboard();
}
function confirmDeleteTask(id) {
  if (confirm('Delete this task from your routine?')) { deleteTask(id); renderRoutine(); showToast('🗑️ Task deleted', 'info'); }
}

// ── Playlists Page ───────────────────────────────────────────
// Planner Page
function parseClock(value, fallback = '07:00') {
  const [h, m] = (value || fallback).split(':').map(Number);
  return ((Number.isFinite(h) ? h : 7) * 60) + (Number.isFinite(m) ? m : 0);
}

function formatClock(totalMinutes) {
  const mins = ((totalMinutes % 1440) + 1440) % 1440;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  const suffix = h >= 12 ? 'PM' : 'AM';
  const hour = h % 12 || 12;
  return `${hour}:${pad(m)} ${suffix}`;
}

function plannerTaskOrder(task) {
  const order = { high: 0, medium: 1, low: 2 };
  return order[task.priority] ?? 1;
}

function renderPlanner() {
  const list = document.getElementById('planner-list');
  const empty = document.getElementById('planner-empty');
  const totalLabel = document.getElementById('planner-total-time');
  if (!list || !empty || !totalLabel) return;

  const teacherTasks = (STATE.teacherTasks || []).filter(task => task.status !== 'COMPLETED');
  const scheduledTasks = [
    ...STATE.tasks.map(task => ({ ...task, source: 'PERSONAL', plannerDuration: taskDuration(task) })),
    ...teacherTasks.filter(task => Number(task.duration) > 0).map(task => ({ ...task, source: 'TEACHER_ASSIGNED', plannerDuration: Number(task.duration) }))
  ];
  const unscheduledTasks = teacherTasks.filter(task => !(Number(task.duration) > 0));
  if (scheduledTasks.length === 0 && unscheduledTasks.length === 0) {
    list.innerHTML = '';
    empty.style.display = 'block';
    totalLabel.textContent = '0h 0m';
    return;
  }

  const startInput = document.getElementById('planner-start-input');
  const breakInput = document.getElementById('planner-break-input');
  let cursor = parseClock(startInput?.value);
  const breakMinutes = Math.max(0, Math.min(60, parseInt(breakInput?.value, 10) || 0));
  const done = STATE.log[TODAY]?.tasks || {};

  const tasks = scheduledTasks.sort((a, b) => plannerTaskOrder(a) - plannerTaskOrder(b));
  let totalTaskMinutes = 0;
  list.innerHTML = tasks.map((task, index) => {
    const duration = task.plannerDuration;
    const start = cursor;
    const end = cursor + duration;
    cursor = end + (index < tasks.length - 1 ? breakMinutes : 0);
    totalTaskMinutes += duration;
    const isTeacherTask = task.source === 'TEACHER_ASSIGNED';
    const inProgress = isTeacherTask ? task.status === 'RUNNING' : isTaskInProgress(task.id);
    const isDone = !isTeacherTask && !!done[task.id];
    const status = isTeacherTask ? task.status.replace('_', ' ') : isDone ? 'Done' : inProgress ? 'In progress' : 'Planned';
    const dueAt = task.deadline ? new Date(task.deadline) : null;
    const overdue = dueAt && dueAt < new Date() && !isDone;
    const action = task.status === 'RUNNING' ? 'pause' : task.status === 'PAUSED' ? 'resume' : 'start';
    const actionLabel = action === 'pause' ? 'Pause' : action === 'resume' ? 'Resume' : 'Start';
    return `
      <div class="planner-item ${isDone ? 'done' : ''} ${inProgress ? 'in-progress' : ''}">
        <div class="planner-time">
          <span>${formatClock(start)}</span>
          <span>${formatClock(end)}</span>
        </div>
        <div class="planner-task">
          <div class="planner-task-name">${esc(task.name)} <span class="planner-source-badge ${isTeacherTask ? 'teacher' : 'personal'}">${isTeacherTask ? 'Teacher Assigned' : 'Personal'}</span></div>
          <div class="planner-task-meta">${duration} min · ${esc(task.priority || 'medium')}${dueAt ? ` · Due ${esc(dueAt.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }))}` : ''}${overdue ? ' · <span class="planner-overdue">Overdue</span>' : ''}${isTeacherTask ? ` · Recorded <span data-study-elapsed data-total-seconds="${task.totalSeconds || 0}" data-running-since="${task.activeSession?.startedAt || ''}">${formatAssignedTime(task)}</span>` : ''}</div>
        </div>
        <div class="planner-actions">
          <span class="planner-status">${status}</span>
          <button class="icon-btn" ${isTeacherTask ? `onclick="controlAssignedStudyTask('${task.id}','${action}')"` : `onclick="setTimerForTask('${task.id}')"`}>${isTeacherTask ? actionLabel : 'Start'}</button>
        </div>
      </div>
    `;
  }).join('') + (unscheduledTasks.length ? `<section class="planner-unscheduled" aria-label="Unscheduled teacher-assigned tasks"><h3>Unscheduled teacher-assigned tasks</h3><p>These tasks need an expected duration before they can be placed in the timetable.</p>${unscheduledTasks.map(task => {
    const dueAt = task.deadline ? new Date(task.deadline) : null;
    const overdue = dueAt && dueAt < new Date();
    const action = task.status === 'RUNNING' ? 'pause' : task.status === 'PAUSED' ? 'resume' : 'start';
    const label = action === 'pause' ? 'Pause' : action === 'resume' ? 'Resume' : 'Start';
    return `<article class="planner-item"><div class="planner-task"><div class="planner-task-name">${esc(task.name)} <span class="planner-source-badge teacher">Teacher Assigned</span></div><div class="planner-task-meta">No expected duration${dueAt ? ` · Due ${esc(dueAt.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }))}` : ''}${overdue ? ' · <span class="planner-overdue">Overdue</span>' : ''} · ${esc(task.status.replace('_', ' '))} · Recorded <span data-study-elapsed data-total-seconds="${task.totalSeconds || 0}" data-running-since="${task.activeSession?.startedAt || ''}">${formatAssignedTime(task)}</span></div></div><div class="planner-actions"><button class="icon-btn" onclick="controlAssignedStudyTask('${task.id}','${action}')">${label}</button></div></article>`;
  }).join('')}</section>` : '');

  empty.style.display = 'none';
  const totalWithBreaks = totalTaskMinutes + Math.max(0, tasks.length - 1) * breakMinutes;
  totalLabel.textContent = `${Math.floor(totalWithBreaks / 60)}h ${totalWithBreaks % 60}m`;
}

function formatAssignedTime(task) {
  const seconds = Math.max(0, Number(task.totalSeconds) || 0) + (task.status === 'RUNNING' && task.activeSession?.startedAt ? Math.max(0, Math.floor((Date.now() - new Date(task.activeSession.startedAt).getTime()) / 1000)) : 0);
  const hours = Math.floor(seconds / 3600), minutes = Math.floor((seconds % 3600) / 60), remainder = seconds % 60;
  return hours ? `${hours}h ${minutes}m` : minutes ? `${minutes}m ${remainder}s` : `${remainder}s`;
}

async function refreshTeacherStudyTasks() {
  if (!window.studyTrackerApi) return [];
  const rows = await window.studyTrackerApi('/study-tasks');
  const assigned = [...new Map(rows.filter(row => row.task?.published).map(row => {
    const status = row.status || (row.completed ? 'COMPLETED' : 'NOT_STARTED');
    return [row.taskId, { id: row.taskId, status, completed: status === 'COMPLETED' }];
  }))];
  STATE.teacherTaskStats = assigned.map(([, task]) => task);
  STATE.teacherTasks = [...new Map(rows.filter(row => row.status !== 'COMPLETED' && !row.completed && row.task?.published).map(row => [row.taskId, {
    id: row.taskId, name: row.task.title, category: row.task.category || 'Study', priority: 'medium',
    duration: Number(row.task.durationMinutes) > 0 ? Number(row.task.durationMinutes) : null,
    deadline: row.task.deadline || null, status: row.status || 'NOT_STARTED',
    totalSeconds: Number(row.totalSeconds) || 0, activeSession: row.activeSession || null,
    completedAt: row.completedAt || null
  }])).values()];
  if (document.getElementById('page-planner')?.classList.contains('active')) renderPlanner();
  if (document.getElementById('page-dashboard')?.classList.contains('active')) renderDashboard();
  return STATE.teacherTasks;
}

async function controlAssignedStudyTask(taskId, action) {
  const button = [...document.querySelectorAll('.planner-actions button')].find(node => node.getAttribute('onclick')?.includes(`'${taskId}','${action}'`));
  if (button?.disabled) return;
  if (button) { button.disabled = true; button.textContent = 'Updating…'; }
  try {
    await window.studyTrackerApi(`/study-tasks/${encodeURIComponent(taskId)}/${action}`, { method: 'POST' });
    await refreshTeacherStudyTasks();
    window.refreshStudentStudyTaskPanel?.();
  } catch (error) {
    if (button) { button.disabled = false; button.textContent = action === 'pause' ? 'Pause' : action === 'resume' ? 'Resume' : 'Start'; }
    showToast(error.message || 'Could not update teacher-assigned task timer.', 'error');
  }
}

function renderPlaylists() {
  const grid = document.getElementById('playlists-list');
  const empty = document.getElementById('playlists-empty');
  if (STATE.playlists.length === 0) { grid.innerHTML = ''; empty.style.display = 'block'; return; }
  empty.style.display = 'none';
  grid.innerHTML = STATE.playlists.map(pl => {
    const total = pl.videos?.length || 0;
    const watchedIds = new Set();
    Object.values(STATE.log).forEach(dl => {
      Object.keys(dl.videos || {}).forEach(v => { if (dl.videos[v] && pl.videos?.find(x => x.id === v)) watchedIds.add(v); });
    });
    const watched = watchedIds.size;
    const pct = total > 0 ? Math.round((watched / total) * 100) : 0;
    const todayVid = pl.todayVideoMap?.[TODAY];
    const todayVideo = pl.videos?.find(v => v.id === todayVid);
    return `<div class="playlist-card">
      <div class="playlist-card-header">
        <div class="playlist-icon">🎬</div>
        <div class="playlist-title">${esc(pl.name)}</div>
        <div class="playlist-subject">${pl.subject ? '📌 ' + esc(pl.subject) : ''}</div>
      </div>
      <div class="playlist-card-body">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-size:13px;color:var(--text-muted)">Progress</span>
          <span style="font-size:13px;font-weight:700;color:var(--blue)">${watched}/${total} videos</span>
        </div>
        <div class="playlist-progress-bar"><div class="playlist-progress-fill" style="width:${pct}%"></div></div>
        <div class="playlist-stats">
          <div>Today:<br><span class="playlist-stat-val">${todayVideo ? esc(todayVideo.title) : 'None'}</span></div>
          <div style="text-align:right">Complete:<br><span class="playlist-stat-val text-green">${pct}%</span></div>
        </div>
      </div>
      <div class="playlist-card-footer">
        <button class="btn-outline" onclick="openPlaylistJourney('${pl.id}')">🗺 Journey</button>
        <button class="icon-btn danger" onclick="confirmDeletePlaylist('${pl.id}')">🗑️</button>
      </div>
    </div>`;
  }).join('');
}
function confirmDeletePlaylist(id) {
  if (confirm('Delete this playlist?')) { deletePlaylist(id); renderPlaylists(); showToast('🗑️ Playlist deleted', 'info'); }
}
function openAddPlaylist() {
  ['playlist-name-input', 'playlist-url-input', 'playlist-manual-input', 'playlist-subject-input'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('playlist-modal').style.display = 'flex';
}
function closePlaylistModal() { document.getElementById('playlist-modal').style.display = 'none'; }

async function savePlaylist() {
  const name = document.getElementById('playlist-name-input').value.trim();
  if (!name) { showToast('Playlist name required!', 'error'); return; }
  const urlInput = document.getElementById('playlist-url-input').value.trim();
  const manualInput = document.getElementById('playlist-manual-input').value.trim();
  const subject = document.getElementById('playlist-subject-input').value.trim();
  const saveBtn = document.getElementById('save-playlist-text');
  const loader = document.getElementById('save-playlist-loader');
  saveBtn.style.display = 'none'; loader.style.display = 'inline';

  let videos = [];
  if (manualInput) {
    // Parse individual video URLs - each becomes a numbered lecture
    videos = manualInput.split('\n').map(l => l.trim()).filter(Boolean).map((url, i) => {
      const vid = ytVideoId(url);
      return {
        id: vid || `manual-${Date.now()}-${i}`, url,
        title: `${name} - Lecture ${i + 1}`,
        thumb: vid ? ytThumb(vid) : null
      };
    });
  } else if (urlInput) {
    const listId = ytPlaylistId(urlInput), videoId = ytVideoId(urlInput);
    if (videoId) {
      // Single video URL
      videos = [{ id: videoId, url: urlInput, title: `${name} - Lecture 1`, thumb: ytThumb(videoId) }];
    } else if (listId) {
      // Playlist URL - create a single entry with the playlist link
      // User should ideally paste individual video URLs for best experience
      try {
        const r = await fetch(`https://noembed.com/embed?url=${encodeURIComponent(urlInput)}`);
        const d = await r.json();
        if (d.title) videos = [{ id: listId, url: urlInput, title: d.title, thumb: d.thumbnail_url || null }];
      } catch (e) { }
      if (videos.length === 0) videos = [{ id: listId + '_0', url: urlInput, title: `${name} - Lecture 1`, thumb: null }];
      showToast('💡 Tip: Individual video URLs daalo for best tracking!', 'info');
    } else {
      videos = [{ id: uid(), url: urlInput, title: `${name} - Lecture 1`, thumb: null }];
    }
  }
  if (videos.length === 0) videos = [{ id: uid(), url: urlInput || '#', title: `${name} - Lecture 1`, thumb: null }];

  addPlaylist({ id: uid(), name, subject, videos, startDate: TODAY, todayVideoMap: {} });
  closePlaylistModal(); renderPlaylists();
  saveBtn.style.display = 'inline'; loader.style.display = 'none';
  showToast(`▶️ ${name} added with ${videos.length} lecture(s)!`, 'success');
}

function openPlaylistJourney(plId) {
  const pl = STATE.playlists.find(p => p.id === plId); if (!pl) return;
  const watchedIds = new Set();
  Object.values(STATE.log).forEach(dl => { Object.keys(dl.videos || {}).forEach(v => { if (dl.videos[v]) watchedIds.add(v); }); });
  const modal = document.createElement('div');
  modal.className = 'modal-overlay'; modal.id = 'journey-modal';
  const pct = pl.videos.length > 0 ? Math.round((watchedIds.size / pl.videos.length) * 100) : 0;
  modal.innerHTML = `<div class="modal glass" style="max-width:600px;max-height:90vh;overflow:hidden;display:flex;flex-direction:column">
    <div class="modal-header"><h3>🗺 ${esc(pl.name)} — Journey</h3>
      <button class="modal-close" onclick="document.getElementById('journey-modal').remove()">✕</button></div>
    <div style="padding:16px 24px;border-bottom:1px solid var(--border)">
      <div style="display:flex;gap:16px;flex-wrap:wrap">
        <span style="font-size:13px;color:var(--text-muted)">Total: <b style="color:var(--text)">${pl.videos.length}</b></span>
        <span style="font-size:13px;color:var(--text-muted)">Watched: <b style="color:var(--green)">${watchedIds.size}</b></span>
        <span style="font-size:13px;color:var(--text-muted)">Remaining: <b style="color:var(--yellow)">${pl.videos.length - watchedIds.size}</b></span>
      </div>
      <div class="playlist-progress-bar" style="margin-top:10px"><div class="playlist-progress-fill" style="width:${pct}%"></div></div>
    </div>
    <div style="overflow-y:auto;padding:16px 24px;flex:1">${pl.videos.map((v, i) => {
    const done = watchedIds.has(v.id), isToday = pl.todayVideoMap?.[TODAY] === v.id;
    return `<div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border)">
        <div style="width:28px;height:28px;border-radius:50%;background:${done ? 'var(--green)' : isToday ? 'var(--blue)' : 'var(--bg3)'};
          color:${done || isToday ? '#0d0f1a' : 'var(--text-dim)'};display:flex;align-items:center;justify-content:center;
          font-size:12px;font-weight:700;flex-shrink:0">${done ? '✓' : i + 1}</div>
        <div style="flex:1"><div style="font-size:14px;font-weight:500;${done ? 'text-decoration:line-through;opacity:0.6' : ''}">
          ${isToday ? '<span style="background:rgba(79,142,247,0.2);color:var(--blue);padding:2px 8px;border-radius:100px;font-size:11px;margin-right:6px">TODAY</span>' : ''}
          ${esc(v.title)}</div></div>
        <a href="${v.url || ytWatchUrl(v.id)}" target="_blank" style="font-size:12px;color:var(--blue);text-decoration:none">▶ Watch</a>
      </div>`;
  }).join('')}</div></div>`;
  modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
  document.body.appendChild(modal);
}

// ── Timer ────────────────────────────────────────────────────
let timerInterval = null, timerRemaining = 25 * 60, timerTotal = 25 * 60, timerRunning = false;

function taskDuration(task) {
  const minutes = parseInt(task?.duration, 10);
  return minutes > 0 ? minutes : 60;
}

function activeTimerTask() {
  return STATE.tasks.find(t => t.id === STATE.currentTimerTaskId) || null;
}

function renderTimer() {
  renderTimerTaskPicker();
  updateActiveTimerTaskDisplay();
  updateTimerDisplay();
  renderSessionsLog();
  const sessions = STATE.timerSessions?.[TODAY] || [];
  document.getElementById('timer-session-count').textContent = `Sessions today: ${sessions.length}`;
}

function renderTimerTaskPicker() {
  const list = document.getElementById('timer-task-list');
  const empty = document.getElementById('timer-task-empty');
  if (!list || !empty) return;

  if (STATE.tasks.length === 0) {
    list.innerHTML = '';
    empty.style.display = 'block';
    return;
  }

  const done = STATE.log[TODAY]?.tasks || {};
  empty.style.display = 'none';
  list.innerHTML = STATE.tasks.map(task => {
    const isActive = task.id === STATE.currentTimerTaskId;
    const isDone = !!done[task.id];
    return `
      <div class="timer-task-item ${isActive ? 'active in-progress' : ''} ${isDone ? 'done' : ''}" role="button" tabindex="0" onclick="setTimerForTask('${task.id}')">
        <span class="timer-task-main">
          <span class="timer-task-name">${esc(task.name)}</span>
          <span class="timer-task-meta">${taskDuration(task)} min · ${esc(task.priority || 'medium')}</span>
        </span>
        <span class="timer-task-action">${isDone ? 'Done' : isActive ? 'In progress' : 'Set'}</span>
      </div>
    `;
  }).join('');
}

function updateActiveTimerTaskDisplay() {
  const label = document.getElementById('active-timer-task');
  if (!label) return;
  const task = activeTimerTask();
  label.textContent = task ? `In progress: ${task.name} (${taskDuration(task)} min)` : 'No routine task selected';
}

function updateTimerDisplay() {
  const m = Math.floor(timerRemaining / 60), s = timerRemaining % 60;
  document.getElementById('timer-display').textContent = `${pad(m)}:${pad(s)}`;
  const arc = document.getElementById('timer-arc');
  const pct = timerTotal > 0 ? (timerRemaining / timerTotal) : 1;
  arc.style.strokeDashoffset = 552.9 * (1 - pct);
}

function startTimer() {
  if (timerRunning) return;
  timerRunning = true;
  document.getElementById('timer-toggle').innerHTML = '⏸ Pause';
  timerInterval = setInterval(() => {
    timerRemaining--;
    updateTimerDisplay();
    if (timerRemaining <= 0) {
      clearInterval(timerInterval); timerRunning = false;
      document.getElementById('timer-toggle').innerHTML = '▶ Start';
      logTimerSession();
      showToast('⏱️ Session complete! Great work!', 'success');
      // Play sound
      try {
        const a = new AudioContext(), o = a.createOscillator(), g = a.createGain();
        o.connect(g); g.connect(a.destination); o.frequency.value = 800; o.type = 'sine';
        g.gain.setValueAtTime(0.3, a.currentTime); g.gain.exponentialRampToValueAtTime(0.001, a.currentTime + 1);
        o.start(); o.stop(a.currentTime + 1);
      } catch (e) { }
    }
  }, 1000);
}

function pauseTimer() {
  if (!timerRunning) return;
  clearInterval(timerInterval); timerRunning = false;
  document.getElementById('timer-toggle').innerHTML = '▶ Start';
}

function resetTimer() {
  pauseTimer(); timerRemaining = timerTotal; updateTimerDisplay();
}

function setTimerMode(minutes, keepTask = false) {
  pauseTimer();
  if (!keepTask) STATE.currentTimerTaskId = null;
  timerTotal = minutes * 60; timerRemaining = timerTotal;
  updateTimerDisplay(); updateActiveTimerTaskDisplay(); renderTimerTaskPicker(); save();
}

function setTimerForTask(id) {
  const task = STATE.tasks.find(t => t.id === id);
  if (!task) return;
  STATE.currentTimerTaskId = id;
  document.querySelectorAll('.timer-tab').forEach(t => t.classList.remove('active'));
  setTimerMode(taskDuration(task), true);
  renderPlanner();
  goToPage('timer');
  showToast(`Timer set for ${task.name}`, 'success');
}

function logTimerSession() {
  ensureTodayLog();
  if (!STATE.timerSessions) STATE.timerSessions = {};
  if (!STATE.timerSessions[TODAY]) STATE.timerSessions[TODAY] = [];
  const task = activeTimerTask();
  STATE.timerSessions[TODAY].push({
    duration: Math.round(timerTotal / 60),
    time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    taskId: task?.id || null,
    taskName: task?.name || '',
  });
  if (window.studyTrackerApi) {
    const duration = Math.round(timerTotal);
    window.studyTrackerApi('/study-sessions', { method: 'POST', body: JSON.stringify({ taskId: task?.id || null, startedAt: new Date(Date.now() - duration * 1000).toISOString(), endedAt: new Date().toISOString(), duration }) }).catch(error => showToast(error.message || 'Could not sync study session.', 'error'));
  }
  if (task) {
    STATE.log[TODAY].tasks[task.id] = true;
    recalcStreak();
    window.studyTrackerApi?.(`/tasks/${encodeURIComponent(task.id)}/status`, { method: 'PATCH', body: JSON.stringify({ completed: true }) }).catch(error => showToast(error.message || 'Could not sync task status.', 'error'));
  }
  save(); renderSessionsLog();
  renderTimerTaskPicker(); updateActiveTimerTaskDisplay();
  document.getElementById('timer-session-count').textContent = `Sessions today: ${STATE.timerSessions[TODAY].length}`;
  timerRemaining = timerTotal; updateTimerDisplay();
}

function renderSessionsLog() {
  const sessions = STATE.timerSessions?.[TODAY] || [];
  const log = document.getElementById('sessions-log');
  const empty = document.getElementById('sessions-empty');
  if (!log || !empty) return;
  if (sessions.length === 0) { log.innerHTML = ''; empty.style.display = 'block'; return; }
  empty.style.display = 'none';
  log.innerHTML = sessions.map((s, i) => `
    <div class="session-item">
      <div class="session-icon">🎯</div>
      <div class="session-info">Session ${i + 1} — ${s.duration} min</div>
      ${s.taskName ? `<div class="session-task">${esc(s.taskName)}</div>` : ''}
      <div class="session-time">${s.time}</div>
    </div>
  `).join('');
}

// ── Progress / Analytics Page ────────────────────────────────
function showToast(msg, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`; toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => { toast.classList.add('toast-exit'); setTimeout(() => toast.remove(), 300); }, 3000);
}

// ── Confetti ─────────────────────────────────────────────────
function launchConfetti() {
  const canvas = document.getElementById('confetti-canvas');
  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth; canvas.height = window.innerHeight;
  const particles = [];
  const colors = ['#4f8ef7', '#9b6ef7', '#f76eb6', '#4fffa0', '#ffd166', '#00f2fe'];
  for (let i = 0; i < 100; i++) {
    particles.push({
      x: canvas.width / 2, y: canvas.height / 2,
      vx: (Math.random() - 0.5) * 16, vy: (Math.random() - 0.5) * 16 - 4,
      size: Math.random() * 6 + 3, color: colors[Math.floor(Math.random() * colors.length)],
      alpha: 1, decay: 0.015 + Math.random() * 0.01,
    });
  }
  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    let alive = false;
    particles.forEach(p => {
      p.x += p.vx; p.y += p.vy; p.vy += 0.3; p.alpha -= p.decay;
      if (p.alpha > 0) {
        alive = true; ctx.globalAlpha = p.alpha; ctx.fillStyle = p.color;
        ctx.fillRect(p.x, p.y, p.size, p.size);
      }
    });
    if (alive) requestAnimationFrame(animate);
    else ctx.clearRect(0, 0, canvas.width, canvas.height);
  }
  animate();
}

// ── Particles Background — Calming Floating Orbs ─────────────
function initParticles() {
  const canvas = document.getElementById('particles-canvas');
  const ctx = canvas.getContext('2d');
  let w, h;
  function resize() { w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; }
  resize(); window.addEventListener('resize', resize);

  // Calming color palette for orbs
  const orbColors = [
    { r: 102, g: 126, b: 234 }, // indigo
    { r: 167, g: 139, b: 250 }, // violet
    { r: 45, g: 212, b: 191 },  // teal
    { r: 244, g: 114, b: 182 }, // rose
    { r: 56, g: 189, b: 248 },  // sky
    { r: 52, g: 211, b: 153 },  // emerald
  ];

  const orbs = [];
  for (let i = 0; i < 20; i++) {
    const color = orbColors[Math.floor(Math.random() * orbColors.length)];
    orbs.push({
      x: Math.random() * w, y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.15, vy: (Math.random() - 0.5) * 0.15,
      r: Math.random() * 3 + 1.5,
      color,
      alpha: Math.random() * 0.12 + 0.04,
      pulse: Math.random() * Math.PI * 2,
      pulseSpeed: 0.005 + Math.random() * 0.01,
    });
  }

  function draw() {
    ctx.clearRect(0, 0, w, h);
    orbs.forEach(o => {
      o.x += o.vx; o.y += o.vy;
      o.pulse += o.pulseSpeed;
      if (o.x < -20) o.x = w + 20; if (o.x > w + 20) o.x = -20;
      if (o.y < -20) o.y = h + 20; if (o.y > h + 20) o.y = -20;

      const pulseR = o.r + Math.sin(o.pulse) * 0.5;
      const glowR = pulseR * 8;

      // Soft glow
      const grad = ctx.createRadialGradient(o.x, o.y, 0, o.x, o.y, glowR);
      grad.addColorStop(0, `rgba(${o.color.r},${o.color.g},${o.color.b},${o.alpha * 1.5})`);
      grad.addColorStop(0.3, `rgba(${o.color.r},${o.color.g},${o.color.b},${o.alpha * 0.5})`);
      grad.addColorStop(1, `rgba(${o.color.r},${o.color.g},${o.color.b},0)`);
      ctx.beginPath(); ctx.arc(o.x, o.y, glowR, 0, Math.PI * 2);
      ctx.fillStyle = grad; ctx.fill();

      // Core dot
      ctx.beginPath(); ctx.arc(o.x, o.y, pulseR, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${o.color.r},${o.color.g},${o.color.b},${o.alpha * 3})`;
      ctx.fill();
    });

    // Subtle connection lines (fewer, softer)
    for (let i = 0; i < orbs.length; i++) {
      for (let j = i + 1; j < orbs.length; j++) {
        const dx = orbs[i].x - orbs[j].x, dy = orbs[i].y - orbs[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 200) {
          const alpha = 0.03 * (1 - dist / 200);
          ctx.beginPath(); ctx.moveTo(orbs[i].x, orbs[i].y); ctx.lineTo(orbs[j].x, orbs[j].y);
          ctx.strokeStyle = `rgba(102,126,234,${alpha})`; ctx.lineWidth = 0.5; ctx.stroke();
        }
      }
    }
    requestAnimationFrame(draw);
  }
  draw();
}

// ── Export / Import ──────────────────────────────────────────
function exportData() {
  const data = JSON.stringify(STATE, null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `studytracker_backup_${TODAY}.json`; a.click();
  URL.revokeObjectURL(url);
  showToast('📤 Data exported!', 'success');
}

function importData(file) {
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      Object.assign(STATE, data); ensureTodayLog(); save();
      showToast('📥 Data imported!', 'success');
      goToPage('dashboard');
    } catch (err) { showToast('❌ Invalid file', 'error'); }
  };
  reader.readAsText(file);
}

// ── Event Listeners ──────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  load(); initParticles();

  // Navigation
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => goToPage(btn.dataset.page));
  });

  // Hamburger
  document.getElementById('hamburger')?.addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
    document.querySelector('.sidebar-overlay')?.classList.toggle('show');
  });

  // Sidebar overlay
  const overlay = document.createElement('div');
  overlay.className = 'sidebar-overlay';
  overlay.addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('open'); overlay.classList.remove('show');
  });
  document.body.appendChild(overlay);

  // Task modal
  document.getElementById('add-task-btn').addEventListener('click', openAddTask);
  document.getElementById('close-task-modal').addEventListener('click', closeTaskModal);
  document.getElementById('cancel-task-modal').addEventListener('click', closeTaskModal);
  document.getElementById('save-task-btn').addEventListener('click', saveTask);
  document.getElementById('task-name-input').addEventListener('keydown', e => { if (e.key === 'Enter') saveTask(); });

  document.getElementById('planner-generate-btn')?.addEventListener('click', renderPlanner);
  document.getElementById('planner-start-input')?.addEventListener('change', renderPlanner);
  document.getElementById('planner-break-input')?.addEventListener('input', renderPlanner);

  // Playlist modal
  document.getElementById('add-playlist-btn').addEventListener('click', openAddPlaylist);
  document.getElementById('close-playlist-modal').addEventListener('click', closePlaylistModal);
  document.getElementById('cancel-playlist-modal').addEventListener('click', closePlaylistModal);
  document.getElementById('save-playlist-btn').addEventListener('click', savePlaylist);

  // Timer
  document.getElementById('timer-toggle').addEventListener('click', () => {
    if (timerRunning) pauseTimer(); else startTimer();
  });
  document.getElementById('timer-reset').addEventListener('click', resetTimer);
  document.getElementById('timer-skip').addEventListener('click', () => {
    if (timerRunning) { pauseTimer(); logTimerSession(); }
  });
  document.querySelectorAll('.timer-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.timer-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      setTimerMode(parseInt(tab.dataset.minutes));
    });
  });
  document.getElementById('custom-timer-btn').addEventListener('click', () => {
    const v = parseInt(document.getElementById('custom-timer-input').value);
    if (v && v > 0 && v <= 180) { setTimerMode(v); showToast(`⏱️ Timer set to ${v} min`, 'info'); }
    else showToast('Enter 1-180 minutes', 'error');
  });

  // Export / Import
  document.getElementById('export-btn').addEventListener('click', exportData);
  document.getElementById('import-btn').addEventListener('click', () => document.getElementById('import-file').click());
  document.getElementById('import-file').addEventListener('change', e => {
    if (e.target.files[0]) importData(e.target.files[0]);
  });

  // Reset
  document.getElementById('reset-all-btn').addEventListener('click', async () => {
    if (confirm('Are you sure? All data will be deleted permanently.')) {
      try {
        if (window.studyTrackerApi) { await window.studyTrackerApi('/personal-tasks', { method: 'DELETE' }); await window.studyTrackerApi('/study-sessions', { method: 'DELETE' }); }
      } catch (error) { showToast(error.message || 'Could not reset synced data.', 'error'); return; }
      localStorage.removeItem(activeTrackerStorageKey);
      resetTrackerState();
      ensureTodayLog(); renderDashboard(); showToast('🗑️ All data reset!', 'info');
    }
  });

  // Goal Note Logic
  const goalInput = document.getElementById('goal-note-input');
  const goalToggle = document.getElementById('goal-note-toggle');

  if (goalInput && goalToggle) {
    goalInput.addEventListener('input', () => {
      STATE.goalNote = goalInput.value;
      save();
    });

    goalToggle.addEventListener('click', () => {
      STATE.goalNoteMinimized = !STATE.goalNoteMinimized;
      renderGoalNote();
      save();
    });
  }

  // Initial render
  goToPage('dashboard');
  renderGoalNote();
});

function renderGoalNote() {
  const goalInput = document.getElementById('goal-note-input');
  const goalToggle = document.getElementById('goal-note-toggle');
  const goalContainer = document.getElementById('goal-note-container');
  if (!goalInput || !goalToggle || !goalContainer) return;

  goalInput.value = STATE.goalNote || "";
  if (STATE.goalNoteMinimized) {
    goalContainer.classList.add('minimized');
    goalToggle.textContent = '➕';
  } else {
    goalContainer.classList.remove('minimized');
    goalToggle.textContent = '➖';
  }
}

// Global helpers for inline onclick
window.goToPage = goToPage; window.toggleTaskToday = toggleTaskToday; window.toggleVideoToday = toggleVideoToday;
window.openEditTask = openEditTask; window.confirmDeleteTask = async id => {
  if (!confirm('Delete this task from your routine?')) return;
  try { if (window.studyTrackerApi) await window.studyTrackerApi(`/tasks/${encodeURIComponent(id)}`, { method: 'DELETE' }); deleteTask(id); renderRoutine(); renderDashboard(); showToast('Task deleted', 'info'); }
  catch (error) { showToast(error.message || 'Could not delete task.', 'error'); }
}; window.setTimerForTask = setTimerForTask;
window.deleteTaskFromTracker = deleteTask; window.renderRoutineFromTracker = renderRoutine;
window.confirmDeletePlaylist = confirmDeletePlaylist; window.openPlaylistJourney = openPlaylistJourney;
window.renderGoalNote = renderGoalNote;
window.activateStudentTracker = activateStudentTracker;
window.refreshStudentTaskStats = refreshTeacherStudyTasks;
window.controlAssignedStudyTask = controlAssignedStudyTask;
window.addEventListener('student-study-tasks-updated', () => refreshTeacherStudyTasks().catch(() => {}));

//AI

async function recommendVideos(taskName) {
  const container = document.getElementById("yt-results");
  const query = encodeURIComponent(`${taskName} full lecture concepts explained`);
  container.innerHTML = `<p style="color:#c7cbe0;line-height:1.6">Video recommendations need a server-side API integration. To keep API credentials out of this browser app, search YouTube directly instead.</p><a class="btn-primary" style="display:inline-block;margin-top:16px" target="_blank" rel="noopener" href="https://www.youtube.com/results?search_query=${query}">Search YouTube</a>`;
  document.getElementById("yt-modal").style.display = "flex";
  return;

  /* Legacy API implementation intentionally disabled: browser code must not contain API credentials.

  // STEP 1: show loading
  container.innerHTML = "🤖 Analyzing your task...";

  // 🔴 FORCE visible delay BEFORE fetch
  await new Promise(res => setTimeout(res, 800));

  const legacyQuery = encodeURIComponent(taskName + " full lecture concepts explained");
  const url = `https://www.youtube.com/results?search_query=${legacyQuery}`;

  try {
    const res = await fetch(url);
    const data = await res.json();

    if (!data.items) {
      container.innerHTML = "❌ API error";
      return;
    }

    const videos = data.items
      .filter(v => v.id.videoId)
      .slice(0, 3)
      .map(v => ({
        title: v.snippet.title,
        id: v.id.videoId,
        thumb: v.snippet.thumbnails.medium.url
      }));

    renderYT(videos, taskName);

  } catch (err) {
    container.innerHTML = "❌ Failed to fetch videos";
  }
  */
}

function renderYT(videos, taskName) {
  const container = document.getElementById("yt-results");

  container.innerHTML = `
    <div style="margin-bottom:10px;color:#aaa;">
      🤖 Based on your task "<b>${taskName}</b>", here are the best lectures:
    </div>
  `;

  container.innerHTML += videos.map(v => `
    <div class="video-item" onclick="window.open('https://youtube.com/watch?v=${v.id}', '_blank')">
      <div class="video-thumb">
        <img src="${v.thumb}" />
      </div>
      <div class="video-info">
        <div class="video-title">${v.title}</div>
      </div>
    </div>
  `).join("");

  document.getElementById("yt-modal").style.display = "flex";
}

function closeYT() {
  document.getElementById("yt-modal").style.display = "none";
}
